
-- store-logos
CREATE POLICY "storelogos_read" ON storage.objects FOR SELECT TO authenticated, anon USING (bucket_id = 'store-logos');
CREATE POLICY "storelogos_owner_write" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'store-logos' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "storelogos_owner_update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'store-logos' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "storelogos_owner_delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'store-logos' AND auth.uid()::text = (storage.foldername(name))[1]);

-- product-media
CREATE POLICY "productmedia_read" ON storage.objects FOR SELECT TO authenticated, anon USING (bucket_id = 'product-media');
CREATE POLICY "productmedia_owner_write" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'product-media' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "productmedia_owner_update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'product-media' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "productmedia_owner_delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'product-media' AND auth.uid()::text = (storage.foldername(name))[1]);

-- site-assets (super_admin write, everyone read)
CREATE POLICY "siteassets_read" ON storage.objects FOR SELECT TO authenticated, anon USING (bucket_id = 'site-assets');
CREATE POLICY "siteassets_admin_write" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'site-assets' AND public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "siteassets_admin_update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'site-assets' AND public.has_role(auth.uid(),'super_admin'));
CREATE POLICY "siteassets_admin_delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'site-assets' AND public.has_role(auth.uid(),'super_admin'));

-- payment-proofs (private)
CREATE POLICY "paymentproofs_owner_read" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'payment-proofs' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "paymentproofs_admin_read" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'payment-proofs' AND (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'super_admin')));
CREATE POLICY "paymentproofs_owner_write" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'payment-proofs' AND auth.uid()::text = (storage.foldername(name))[1]);
