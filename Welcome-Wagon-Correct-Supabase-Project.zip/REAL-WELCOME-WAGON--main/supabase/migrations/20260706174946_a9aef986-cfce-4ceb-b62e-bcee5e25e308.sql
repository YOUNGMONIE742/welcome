
-- Create private schema not exposed to PostgREST API
CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC, anon, authenticated;
GRANT USAGE ON SCHEMA private TO postgres, service_role;

-- Move SECURITY DEFINER helpers out of the exposed public schema.
-- OIDs are preserved, so existing RLS policies and the auth trigger keep working.
ALTER FUNCTION public.has_role(uuid, app_role) SET SCHEMA private;
ALTER FUNCTION public.current_user_role() SET SCHEMA private;

REVOKE ALL ON FUNCTION private.has_role(uuid, app_role) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION private.current_user_role() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION private.has_role(uuid, app_role) TO postgres, service_role;
GRANT EXECUTE ON FUNCTION private.current_user_role() TO postgres, service_role;

-- Replace get_public_vendors RPC with a plain view (respects invoker but reads via view owner rights on safe columns only).
DROP FUNCTION IF EXISTS public.get_public_vendors(integer);

CREATE OR REPLACE VIEW public.public_vendors
WITH (security_invoker = false) AS
SELECT v.id, v.store_name, v.slug, v.description, v.logo_url,
       v.rating, v.total_sold, v.joined_at
FROM public.vendors v
WHERE v.is_active = true
  AND EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = v.user_id AND ur.role = 'vendor'::app_role
  );

GRANT SELECT ON public.public_vendors TO anon, authenticated;
