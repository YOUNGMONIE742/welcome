
-- 1. Vendors: drop public policy exposing contact_email/contact_phone.
--    Public listing already goes through public.get_public_vendors (safe columns only).
DROP POLICY IF EXISTS vendors_public_view_active ON public.vendors;

-- 2. Feedback: replace unconditional true with_check with input-length validation.
DROP POLICY IF EXISTS feedback_insert_anyone ON public.feedback;
CREATE POLICY feedback_insert_anyone ON public.feedback
  FOR INSERT TO anon, authenticated
  WITH CHECK (
    length(name) BETWEEN 1 AND 200
    AND length(email) BETWEEN 3 AND 200
    AND length(message) BETWEEN 1 AND 5000
    AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
  );

-- 3. Storage read policies: scope to owner, admins, or files linked to active/approved resources.
DROP POLICY IF EXISTS storelogos_read ON storage.objects;
CREATE POLICY storelogos_read ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (
    bucket_id = 'store-logos'
    AND (
      (auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text)
      OR public.has_role(auth.uid(), 'admin'::app_role)
      OR public.has_role(auth.uid(), 'super_admin'::app_role)
      OR EXISTS (
        SELECT 1 FROM public.vendors v
        WHERE v.logo_url = storage.objects.name AND v.is_active = true
      )
    )
  );

DROP POLICY IF EXISTS productmedia_read ON storage.objects;
CREATE POLICY productmedia_read ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (
    bucket_id = 'product-media'
    AND (
      (auth.uid() IS NOT NULL AND (storage.foldername(name))[1] = auth.uid()::text)
      OR public.has_role(auth.uid(), 'admin'::app_role)
      OR public.has_role(auth.uid(), 'super_admin'::app_role)
      OR EXISTS (
        SELECT 1 FROM public.products p
        WHERE p.status = 'approved'
          AND (
            p.primary_image_url = storage.objects.name
            OR p.video_url = storage.objects.name
            OR storage.objects.name = ANY(p.images)
          )
      )
    )
  );

-- 4. Lock down SECURITY DEFINER function EXECUTE grants.
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.current_user_role() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.current_user_role() TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO service_role;

-- get_public_vendors is intentionally callable by anon (landing page + verified vendors page)
REVOKE ALL ON FUNCTION public.get_public_vendors(integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_vendors(integer) TO anon, authenticated, service_role;
