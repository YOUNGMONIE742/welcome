-- Welcome Wagon marketplace repair migration (schema compatibility, finance and role security).
ALTER TABLE public.vendors
  ADD COLUMN IF NOT EXISTS business_address text,
  ADD COLUMN IF NOT EXISTS business_hours text,
  ADD COLUMN IF NOT EXISTS return_policy text,
  ADD COLUMN IF NOT EXISTS exchange_policy text,
  ADD COLUMN IF NOT EXISTS delivery_policy text,
  ADD COLUMN IF NOT EXISTS social_links jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS status_reason text;
ALTER TABLE public.withdrawals
  ADD COLUMN IF NOT EXISTS paid_ngn numeric(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS note text,
  ADD COLUMN IF NOT EXISTS decision_reason text,
  ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE public.withdrawal_payments
  ADD COLUMN IF NOT EXISTS vendor_id uuid REFERENCES public.vendors(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS amount_ngn numeric(12,2),
  ADD COLUMN IF NOT EXISTS amount numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE public.vendor_ledger
  ADD COLUMN IF NOT EXISTS order_item_id uuid REFERENCES public.order_items(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS withdrawal_id uuid REFERENCES public.withdrawals(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS gross_ngn numeric(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS commission_ngn numeric(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS amount_ngn numeric(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS commission_percent numeric(5,2),
  ADD COLUMN IF NOT EXISTS available_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS amount numeric(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS reference text NOT NULL DEFAULT ('TX-' || upper(substr(md5(random()::text),1,10)));
ALTER TABLE public.financial_audit_log
  ADD COLUMN IF NOT EXISTS vendor_id uuid REFERENCES public.vendors(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS amount numeric(12,2),
  ADD COLUMN IF NOT EXISTS details jsonb;

UPDATE public.withdrawals SET note=COALESCE(note,reason),decision_reason=COALESCE(decision_reason,reason);
UPDATE public.withdrawal_payments wp
 SET amount_ngn=COALESCE(NULLIF(wp.amount_ngn,0),wp.amount),
     amount=COALESCE(NULLIF(wp.amount,0),wp.amount_ngn),
     vendor_id=COALESCE(wp.vendor_id,w.vendor_id)
 FROM public.withdrawals w WHERE w.id=wp.withdrawal_id;
UPDATE public.vendor_ledger SET amount_ngn=COALESCE(NULLIF(amount_ngn,0),amount),amount=COALESCE(NULLIF(amount,0),amount_ngn,0);
UPDATE public.financial_audit_log a SET vendor_id=w.vendor_id
 FROM public.withdrawals w WHERE a.entity_type='withdrawal' AND a.entity_id=w.id AND a.vendor_id IS NULL;
UPDATE public.withdrawals w
 SET paid_ngn=COALESCE(p.total_paid,0),
     status=CASE WHEN COALESCE(p.total_paid,0)>=w.amount_ngn THEN 'paid'
                 WHEN COALESCE(p.total_paid,0)>0 THEN 'partially_paid'
                 WHEN w.status='paid' AND COALESCE(p.total_paid,0)=0 THEN 'approved'
                 ELSE w.status END,
     updated_at=now()
 FROM (SELECT w2.id,COALESCE(sum(wp.amount_ngn),sum(wp.amount),0)::numeric AS total_paid
       FROM public.withdrawals w2 LEFT JOIN public.withdrawal_payments wp ON wp.withdrawal_id=w2.id GROUP BY w2.id) p
 WHERE p.id=w.id;
UPDATE public.settings SET is_public=true,updated_at=now()
 WHERE key IN ('bank_details','vendor_applications_enabled','vendor_setup_fee_ngn');

CREATE OR REPLACE FUNCTION private.sync_withdrawal_payment_amounts()
RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
BEGIN
 NEW.amount_ngn:=COALESCE(NULLIF(NEW.amount_ngn,0),NEW.amount);
 NEW.amount:=COALESCE(NULLIF(NEW.amount,0),NEW.amount_ngn);
 IF NEW.vendor_id IS NULL THEN SELECT vendor_id INTO NEW.vendor_id FROM public.withdrawals WHERE id=NEW.withdrawal_id; END IF;
 RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS sync_withdrawal_payment_amounts ON public.withdrawal_payments;
CREATE TRIGGER sync_withdrawal_payment_amounts BEFORE INSERT OR UPDATE ON public.withdrawal_payments
 FOR EACH ROW EXECUTE FUNCTION private.sync_withdrawal_payment_amounts();

CREATE OR REPLACE FUNCTION public.set_user_role(p_user_id uuid,p_role public.app_role,p_grant boolean)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE target_email text;
BEGIN
 IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(),'super_admin') THEN RAISE EXCEPTION 'Only a super admin can manage user roles'; END IF;
 SELECT lower(email) INTO target_email FROM public.profiles WHERE id=p_user_id;
 IF target_email IS NULL THEN RAISE EXCEPTION 'User profile not found'; END IF;
 IF p_role='super_admin' THEN
  IF p_grant THEN
   IF target_email NOT IN ('bhabeeb742@gmail.com','trimond742@gmail.com','welcomewagonkidsandmore1@gmail.com') THEN RAISE EXCEPTION 'Super admin role is restricted to allowlisted accounts'; END IF;
  ELSE RAISE EXCEPTION 'Super admin roles cannot be revoked here'; END IF;
 END IF;
 IF p_grant THEN INSERT INTO public.user_roles(user_id,role) VALUES(p_user_id,p_role) ON CONFLICT(user_id,role) DO NOTHING;
 ELSE DELETE FROM public.user_roles WHERE user_id=p_user_id AND role=p_role; END IF;
END; $$;
REVOKE ALL ON FUNCTION public.set_user_role(uuid,public.app_role,boolean) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.set_user_role(uuid,public.app_role,boolean) TO authenticated;

CREATE OR REPLACE FUNCTION public.record_withdrawal_payment(p_id uuid,p_amount numeric,p_proof_url text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE w public.withdrawals%ROWTYPE; payment_id uuid; new_paid numeric; new_status text;
BEGIN
 IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(),'super_admin') THEN RAISE EXCEPTION 'Only a super admin can record withdrawal payments'; END IF;
 IF p_amount IS NULL OR p_amount<=0 THEN RAISE EXCEPTION 'Payment amount must be positive'; END IF;
 IF NULLIF(trim(p_proof_url),'') IS NULL THEN RAISE EXCEPTION 'Upload a payment proof'; END IF;
 SELECT * INTO w FROM public.withdrawals WHERE id=p_id FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Withdrawal not found'; END IF;
 IF w.status NOT IN ('approved','partially_paid') THEN RAISE EXCEPTION 'Withdrawal must be approved before payment'; END IF;
 IF p_amount>(w.amount_ngn-COALESCE(w.paid_ngn,0)) THEN RAISE EXCEPTION 'Payment exceeds the outstanding amount'; END IF;
 INSERT INTO public.withdrawal_payments(withdrawal_id,vendor_id,amount,amount_ngn,proof_url,paid_by)
 VALUES(p_id,w.vendor_id,p_amount,p_amount,trim(p_proof_url),auth.uid()) RETURNING id INTO payment_id;
 new_paid:=COALESCE(w.paid_ngn,0)+p_amount;
 new_status:=CASE WHEN new_paid>=w.amount_ngn THEN 'paid' ELSE 'partially_paid' END;
 UPDATE public.withdrawals SET paid_ngn=new_paid,status=new_status,updated_at=now(),reviewed_by=auth.uid(),reviewed_at=COALESCE(reviewed_at,now()) WHERE id=p_id;
 INSERT INTO public.vendor_ledger(vendor_id,withdrawal_id,entry_type,description,amount,amount_ngn,available_at)
 VALUES(w.vendor_id,p_id,'payout','Payout · '||w.reference,-p_amount,-p_amount,now());
 INSERT INTO public.financial_audit_log(actor_id,vendor_id,action,entity_type,entity_id,amount,details)
 VALUES(auth.uid(),w.vendor_id,'withdrawal_payment','withdrawal',p_id,p_amount,jsonb_build_object('paid_total',new_paid,'status',new_status,'proof_url',trim(p_proof_url)));
 RETURN payment_id;
END; $$;
REVOKE ALL ON FUNCTION public.record_withdrawal_payment(uuid,numeric,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.record_withdrawal_payment(uuid,numeric,text) TO authenticated;

CREATE OR REPLACE FUNCTION public.review_withdrawal(p_id uuid,p_approve boolean,p_reason text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
 IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(),'super_admin') THEN RAISE EXCEPTION 'Only a super admin can review withdrawals'; END IF;
 UPDATE public.withdrawals SET status=CASE WHEN p_approve THEN 'approved' ELSE 'rejected' END,
  reason=COALESCE(p_reason,reason),note=COALESCE(p_reason,note),decision_reason=COALESCE(p_reason,decision_reason),
  reviewed_by=auth.uid(),reviewed_at=now(),updated_at=now() WHERE id=p_id AND status='pending';
 IF NOT FOUND THEN RAISE EXCEPTION 'Pending withdrawal not found'; END IF;
 INSERT INTO public.financial_audit_log(actor_id,vendor_id,action,entity_type,entity_id,details)
 SELECT auth.uid(),w.vendor_id,CASE WHEN p_approve THEN 'withdrawal_approved' ELSE 'withdrawal_rejected' END,'withdrawal',w.id,jsonb_build_object('reason',p_reason)
 FROM public.withdrawals w WHERE w.id=p_id;
END; $$;
REVOKE ALL ON FUNCTION public.review_withdrawal(uuid,boolean,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.review_withdrawal(uuid,boolean,text) TO authenticated;

DROP FUNCTION IF EXISTS public.vendor_wallets();
CREATE FUNCTION public.vendor_wallets()
RETURNS TABLE(vendor_id uuid,store_name text,is_active boolean,commission_percent numeric,gross_sales numeric,commission_total numeric,refunds_total numeric,paid_out numeric,withdrawals_requested numeric,pending_withdrawals numeric,wallet_balance numeric,available_balance numeric,pending_balance numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public AS $$
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
 RETURN QUERY
 WITH rates AS (SELECT v.id,COALESCE(v.commission_percent,(SELECT CASE WHEN jsonb_typeof(value)='number' THEN (value#>>'{}')::numeric ELSE 10 END FROM public.settings WHERE key='default_commission_percent'),10)::numeric AS pct FROM public.vendors v),
 sales AS (SELECT oi.vendor_id,
  COALESCE(sum(oi.subtotal_ngn) FILTER(WHERE o.status::text IN ('paid','processing','packed','shipped','out_for_delivery','delivered')),0)::numeric AS gross,
  COALESCE(sum(oi.subtotal_ngn) FILTER(WHERE o.status::text IN ('payment_review','pending_payment')),0)::numeric AS pending,
  COALESCE(sum(oi.subtotal_ngn) FILTER(WHERE o.status::text IN ('refunded','returned')),0)::numeric AS refund_gross
  FROM public.order_items oi JOIN public.orders o ON o.id=oi.order_id WHERE oi.vendor_id IS NOT NULL GROUP BY oi.vendor_id),
 payouts AS (SELECT w.vendor_id,COALESCE(sum(w.paid_ngn),0)::numeric AS paid,
  COALESCE(sum(w.amount_ngn) FILTER(WHERE w.status IN ('pending','approved','partially_paid')),0)::numeric AS pending_w,
  COALESCE(sum(w.amount_ngn),0)::numeric AS requested FROM public.withdrawals w GROUP BY w.vendor_id),
 totals AS (SELECT v.id,v.store_name::text AS store_name,v.is_active,r.pct,COALESCE(s.gross,0)::numeric AS gross,
  (COALESCE(s.gross,0)*r.pct/100)::numeric AS commission,(COALESCE(s.refund_gross,0)*(1-r.pct/100))::numeric AS refunds,
  COALESCE(p.paid,0)::numeric AS paid,COALESCE(p.requested,0)::numeric AS requested,COALESCE(p.pending_w,0)::numeric AS pending_w,COALESCE(s.pending,0)::numeric AS pending_sales
  FROM public.vendors v JOIN rates r ON r.id=v.id LEFT JOIN sales s ON s.vendor_id=v.id LEFT JOIN payouts p ON p.vendor_id=v.id)
 SELECT t.id,t.store_name,t.is_active,t.pct,t.gross,t.commission,t.refunds,t.paid,t.requested,t.pending_w,
  (t.gross-t.commission-t.refunds-t.paid)::numeric,GREATEST(0,t.gross-t.commission-t.refunds-t.paid-t.pending_w)::numeric,t.pending_sales
 FROM totals t WHERE public.has_role(auth.uid(),'super_admin') OR EXISTS(SELECT 1 FROM public.vendors v WHERE v.id=t.id AND v.user_id=auth.uid());
END; $$;
REVOKE ALL ON FUNCTION public.vendor_wallets() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.vendor_wallets() TO authenticated;

CREATE OR REPLACE FUNCTION public.get_vendor_sales_report()
RETURNS TABLE(vendor_id uuid,vendor_name text,product_id uuid,product_title text,units_sold bigint,sales_amount_ngn numeric,orders_count bigint)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=public AS $$
BEGIN
 IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
 IF NOT public.has_role(auth.uid(),'super_admin') AND NOT EXISTS(SELECT 1 FROM public.user_roles ur WHERE ur.user_id=auth.uid() AND ur.role='vendor') THEN RAISE EXCEPTION 'Only vendors and super admins can view vendor sales'; END IF;
 RETURN QUERY SELECT v.id,v.store_name::text,p.id,p.title::text,COALESCE(sum(oi.quantity),0)::bigint,COALESCE(sum(oi.subtotal_ngn),0)::numeric,count(DISTINCT o.id)::bigint
 FROM public.order_items oi JOIN public.orders o ON o.id=oi.order_id JOIN public.products p ON p.id=oi.product_id JOIN public.vendors v ON v.id=oi.vendor_id
 WHERE oi.vendor_id IS NOT NULL AND o.status::text IN ('paid','processing','packed','shipped','out_for_delivery','delivered')
 AND (public.has_role(auth.uid(),'super_admin') OR v.user_id=auth.uid()) GROUP BY v.id,v.store_name,p.id,p.title;
END; $$;
REVOKE ALL ON FUNCTION public.get_vendor_sales_report() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.get_vendor_sales_report() TO authenticated;

CREATE OR REPLACE FUNCTION private.orders_vendor_ledger_status()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE it record; pct numeric; comm numeric;
BEGIN
 IF NEW.status::text IN ('paid','processing','packed','shipped','out_for_delivery','delivered') AND (TG_OP='INSERT' OR OLD.status::text IS DISTINCT FROM NEW.status::text) THEN
  FOR it IN SELECT oi.id,oi.vendor_id,oi.title,oi.subtotal_ngn FROM public.order_items oi WHERE oi.order_id=NEW.id AND oi.vendor_id IS NOT NULL
   AND NOT EXISTS(SELECT 1 FROM public.vendor_ledger l WHERE l.order_item_id=oi.id AND l.entry_type='sale') LOOP
   SELECT COALESCE(v.commission_percent,(SELECT CASE WHEN jsonb_typeof(value)='number' THEN (value#>>'{}')::numeric ELSE 10 END FROM public.settings WHERE key='default_commission_percent'),10) INTO pct FROM public.vendors v WHERE v.id=it.vendor_id;
   comm:=round(it.subtotal_ngn*COALESCE(pct,10)/100,2);
   INSERT INTO public.vendor_ledger(vendor_id,order_id,order_item_id,entry_type,description,amount,amount_ngn,gross_ngn,commission_ngn,commission_percent,available_at)
   VALUES(it.vendor_id,NEW.id,it.id,'sale','Sale · '||NEW.order_number||' · '||it.title,it.subtotal_ngn-comm,it.subtotal_ngn-comm,it.subtotal_ngn,comm,COALESCE(pct,10),now());
  END LOOP;
 END IF;
 IF NEW.status::text IN ('refunded','returned','cancelled') AND (TG_OP='INSERT' OR OLD.status::text IS DISTINCT FROM NEW.status::text) THEN
  FOR it IN SELECT l.* FROM public.vendor_ledger l WHERE l.order_id=NEW.id AND l.entry_type='sale'
   AND NOT EXISTS(SELECT 1 FROM public.vendor_ledger r WHERE r.order_item_id=l.order_item_id AND r.entry_type='refund') LOOP
   INSERT INTO public.vendor_ledger(vendor_id,order_id,order_item_id,entry_type,description,amount,amount_ngn,gross_ngn,commission_ngn,commission_percent,available_at)
   VALUES(it.vendor_id,NEW.id,it.order_item_id,'refund','Refund reversal · '||NEW.order_number,-COALESCE(it.amount_ngn,it.amount),-COALESCE(it.amount_ngn,it.amount),-it.gross_ngn,-it.commission_ngn,it.commission_percent,now());
  END LOOP;
 END IF;
 RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS orders_vendor_ledger_status ON public.orders;
CREATE TRIGGER orders_vendor_ledger_status AFTER INSERT OR UPDATE OF status ON public.orders FOR EACH ROW EXECUTE FUNCTION private.orders_vendor_ledger_status();

INSERT INTO public.vendor_ledger(vendor_id,order_id,order_item_id,entry_type,description,amount,amount_ngn,gross_ngn,commission_ngn,commission_percent,available_at)
SELECT oi.vendor_id,o.id,oi.id,'sale','Sale · '||o.order_number||' · '||oi.title,
 oi.subtotal_ngn-ROUND(oi.subtotal_ngn*COALESCE(v.commission_percent,10)/100,2),oi.subtotal_ngn-ROUND(oi.subtotal_ngn*COALESCE(v.commission_percent,10)/100,2),oi.subtotal_ngn,
 ROUND(oi.subtotal_ngn*COALESCE(v.commission_percent,10)/100,2),COALESCE(v.commission_percent,10),o.updated_at
FROM public.orders o JOIN public.order_items oi ON oi.order_id=o.id JOIN public.vendors v ON v.id=oi.vendor_id
WHERE o.status::text IN ('paid','processing','packed','shipped','out_for_delivery','delivered') AND oi.vendor_id IS NOT NULL
 AND NOT EXISTS(SELECT 1 FROM public.vendor_ledger l WHERE l.order_item_id=oi.id AND l.entry_type='sale');
INSERT INTO public.vendor_ledger(vendor_id,order_id,order_item_id,entry_type,description,amount,amount_ngn,gross_ngn,commission_ngn,commission_percent,available_at)
SELECT l.vendor_id,l.order_id,l.order_item_id,'refund','Refund reversal · '||o.order_number,-l.amount_ngn,-l.amount_ngn,-l.gross_ngn,-l.commission_ngn,l.commission_percent,now()
FROM public.vendor_ledger l JOIN public.orders o ON o.id=l.order_id WHERE l.entry_type='sale' AND o.status::text IN ('refunded','returned','cancelled')
 AND NOT EXISTS(SELECT 1 FROM public.vendor_ledger r WHERE r.order_item_id=l.order_item_id AND r.entry_type='refund');

CREATE OR REPLACE FUNCTION public.set_vendor_status(p_vendor uuid,p_status text,p_reason text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
 IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(),'super_admin') THEN RAISE EXCEPTION 'Only a super admin can change vendor status'; END IF;
 IF p_status NOT IN ('active','suspended','terminated') THEN RAISE EXCEPTION 'Invalid vendor status'; END IF;
 UPDATE public.vendors SET status=p_status,is_active=(p_status='active'),status_reason=p_reason,updated_at=now() WHERE id=p_vendor;
 IF NOT FOUND THEN RAISE EXCEPTION 'Vendor not found'; END IF;
 INSERT INTO public.financial_audit_log(actor_id,vendor_id,action,entity_type,entity_id,details)
 VALUES(auth.uid(),p_vendor,'vendor_status_changed','vendor',p_vendor,jsonb_build_object('status',p_status,'reason',p_reason));
END; $$;
REVOKE ALL ON FUNCTION public.set_vendor_status(uuid,text,text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.set_vendor_status(uuid,text,text) TO authenticated;

DROP VIEW IF EXISTS public.public_vendors;
CREATE VIEW public.public_vendors WITH (security_invoker=true) AS
SELECT v.id,v.store_name,v.slug,v.description,v.logo_url,v.banner_url,v.rating,v.total_sold,v.joined_at FROM public.vendors v
WHERE v.status='active' AND v.is_active=true;
GRANT SELECT ON public.public_vendors TO anon,authenticated;
CREATE OR REPLACE FUNCTION public.products_availability(p_ids uuid[])
RETURNS TABLE(product_id uuid,available boolean,stock integer)
LANGUAGE sql STABLE SECURITY INVOKER SET search_path=public AS $$
 SELECT p.id,(p.status='approved' AND greatest(p.stock-p.reserved_stock,0)>0 AND
  (p.vendor_id IS NULL OR EXISTS(SELECT 1 FROM public.vendors v WHERE v.id=p.vendor_id AND v.is_active AND v.status='active'))),
  greatest(p.stock-p.reserved_stock,0) FROM public.products p WHERE p.id=ANY(p_ids)
$$;
REVOKE ALL ON FUNCTION public.products_availability(uuid[]) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.products_availability(uuid[]) TO anon,authenticated;
CREATE INDEX IF NOT EXISTS idx_vendor_ledger_order_item_type ON public.vendor_ledger(order_item_id,entry_type);
CREATE INDEX IF NOT EXISTS idx_withdrawal_payments_vendor_id ON public.withdrawal_payments(vendor_id);
CREATE INDEX IF NOT EXISTS idx_financial_audit_vendor_created ON public.financial_audit_log(vendor_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admin_applications_reviewed_by ON public.admin_applications(reviewed_by);
CREATE INDEX IF NOT EXISTS idx_admin_applications_user_id ON public.admin_applications(user_id);
CREATE INDEX IF NOT EXISTS idx_announcements_created_by ON public.announcements(created_by);
CREATE INDEX IF NOT EXISTS idx_feedback_user_id ON public.feedback(user_id);
CREATE INDEX IF NOT EXISTS idx_financial_audit_actor_id ON public.financial_audit_log(actor_id);
CREATE INDEX IF NOT EXISTS idx_payments_verified_by ON public.payments(verified_by);
CREATE INDEX IF NOT EXISTS idx_product_images_product_id ON public.product_images(product_id);
CREATE INDEX IF NOT EXISTS idx_products_created_by ON public.products(created_by);
CREATE INDEX IF NOT EXISTS idx_vendor_applications_reviewed_by ON public.vendor_applications(reviewed_by);
CREATE INDEX IF NOT EXISTS idx_vendor_applications_user_id ON public.vendor_applications(user_id);
CREATE INDEX IF NOT EXISTS idx_vendor_ledger_order_id ON public.vendor_ledger(order_id);
CREATE INDEX IF NOT EXISTS idx_withdrawal_payments_paid_by ON public.withdrawal_payments(paid_by);
CREATE INDEX IF NOT EXISTS idx_withdrawal_payments_withdrawal_id ON public.withdrawal_payments(withdrawal_id);
CREATE INDEX IF NOT EXISTS idx_withdrawals_reviewed_by ON public.withdrawals(reviewed_by);
CREATE INDEX IF NOT EXISTS idx_vendor_ledger_withdrawal_id ON public.vendor_ledger(withdrawal_id);
-- Cache auth.uid() once per query in policies; this is semantics-preserving and avoids per-row initplans.
DO $$
DECLARE r record; q text; c text; stmt text;
BEGIN
 FOR r IN
  SELECT n.nspname AS schemaname,cl.relname AS tablename,p.polname,
         pg_get_expr(p.polqual,p.polrelid) AS qual,
         pg_get_expr(p.polwithcheck,p.polrelid) AS check_expr
  FROM pg_policy p JOIN pg_class cl ON cl.oid=p.polrelid JOIN pg_namespace n ON n.oid=cl.relnamespace
  WHERE n.nspname='public'
    AND (COALESCE(pg_get_expr(p.polqual,p.polrelid),'') LIKE '%auth.uid()%'
      OR COALESCE(pg_get_expr(p.polwithcheck,p.polrelid),'') LIKE '%auth.uid()%')
 LOOP
  q := CASE WHEN r.qual IS NULL THEN NULL ELSE replace(r.qual,'auth.uid()','(select auth.uid())') END;
  c := CASE WHEN r.check_expr IS NULL THEN NULL ELSE replace(r.check_expr,'auth.uid()','(select auth.uid())') END;
  stmt := format('ALTER POLICY %I ON %I.%I',r.polname,r.schemaname,r.tablename);
  IF q IS NOT NULL THEN stmt := stmt || format(' USING (%s)',q); END IF;
  IF c IS NOT NULL THEN stmt := stmt || format(' WITH CHECK (%s)',c); END IF;
  EXECUTE stmt;
 END LOOP;
END $$;
