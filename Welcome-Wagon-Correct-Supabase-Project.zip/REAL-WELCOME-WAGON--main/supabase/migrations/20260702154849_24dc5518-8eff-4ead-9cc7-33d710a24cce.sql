CREATE OR REPLACE FUNCTION public.get_public_vendors(_limit int DEFAULT 100)
RETURNS TABLE(id uuid, store_name text, slug text, description text, logo_url text, rating numeric, total_sold int, joined_at timestamptz)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT v.id, v.store_name, v.slug, v.description, v.logo_url, v.rating, v.total_sold, v.joined_at
  FROM public.vendors v
  WHERE v.is_active = true
    AND EXISTS (
      SELECT 1 FROM public.user_roles ur
      WHERE ur.user_id = v.user_id AND ur.role = 'vendor'::app_role
    )
  ORDER BY v.rating DESC NULLS LAST, v.total_sold DESC
  LIMIT _limit;
$$;
REVOKE ALL ON FUNCTION public.get_public_vendors(int) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_vendors(int) TO anon, authenticated;