-- Restore EXECUTE on SECURITY DEFINER role helpers; needed by RLS policies.
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.current_user_role() TO authenticated;