-- 1. Vendor lifecycle status ------------------------------------------------
DO $$ BEGIN
  CREATE TYPE public.vendor_status AS ENUM ('pending','active','suspended','terminated');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.vendors
  ADD COLUMN IF NOT EXISTS status public.vendor_status NOT NULL DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS status_reason text,
  ADD COLUMN IF NOT EXISTS status_changed_at timestamptz,
  ADD COLUMN IF NOT EXISTS banner_url text,
  ADD COLUMN IF NOT EXISTS business_address text,
  ADD COLUMN IF NOT EXISTS business_hours text,
  ADD COLUMN IF NOT EXISTS return_policy text,
  ADD COLUMN IF NOT EXISTS exchange_policy text,
  ADD COLUMN IF NOT EXISTS delivery_policy text,
  ADD COLUMN IF NOT EXISTS social_links jsonb NOT NULL DEFAULT '{}'::jsonb;

UPDATE public.vendors SET status = CASE WHEN is_active THEN 'active' ELSE 'suspended' END::public.vendor_status;

-- keep the legacy is_active flag in sync so existing code keeps working
CREATE OR REPLACE FUNCTION private.vendors_sync_active()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  NEW.is_active := (NEW.status = 'active');
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    NEW.status_changed_at := now();
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS vendors_sync_active ON public.vendors;
CREATE TRIGGER vendors_sync_active BEFORE UPDATE ON public.vendors
FOR EACH ROW EXECUTE FUNCTION private.vendors_sync_active();

-- 2. Hide suspended / terminated vendors' products from the public shop -----
DROP POLICY IF EXISTS products_public_view_approved ON public.products;
CREATE POLICY products_public_view_approved ON public.products
FOR SELECT TO anon, authenticated
USING (
  status = 'approved'::product_status
  AND (
    vendor_id IS NULL
    OR EXISTS (SELECT 1 FROM public.vendors v WHERE v.id = products.vendor_id AND v.status = 'active')
  )
);

-- 3. Block suspended vendors from creating / editing products ---------------
CREATE OR REPLACE FUNCTION private.products_block_suspended_vendor()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE st public.vendor_status;
BEGIN
  IF NEW.vendor_id IS NULL THEN RETURN NEW; END IF;
  IF private.has_role(auth.uid(),'admin') OR private.has_role(auth.uid(),'super_admin') THEN RETURN NEW; END IF;
  SELECT v.status INTO st FROM public.vendors v WHERE v.id = NEW.vendor_id;
  IF st IS DISTINCT FROM 'active' THEN
    RAISE EXCEPTION 'Your store is % — you cannot add or edit products right now.', COALESCE(st::text,'unavailable');
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS products_block_suspended_vendor ON public.products;
CREATE TRIGGER products_block_suspended_vendor BEFORE INSERT OR UPDATE ON public.products
FOR EACH ROW EXECUTE FUNCTION private.products_block_suspended_vendor();

-- 4. Super-admin-only vendor status control ---------------------------------
CREATE OR REPLACE FUNCTION public.set_vendor_status(p_vendor uuid, p_status text, p_reason text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v public.vendors%ROWTYPE; prev public.vendor_status; new_status public.vendor_status;
BEGIN
  IF NOT private.has_role(auth.uid(),'super_admin') THEN
    RAISE EXCEPTION 'Only a super admin can change vendor status';
  END IF;
  IF p_status NOT IN ('pending','active','suspended','terminated') THEN
    RAISE EXCEPTION 'Unsupported vendor status';
  END IF;
  SELECT * INTO v FROM public.vendors WHERE id = p_vendor;
  IF v.id IS NULL THEN RAISE EXCEPTION 'Vendor not found'; END IF;
  prev := v.status;
  new_status := p_status::public.vendor_status;
  IF prev = 'terminated' AND new_status <> 'terminated' THEN
    RAISE EXCEPTION 'A terminated vendor cannot be restored';
  END IF;

  UPDATE public.vendors SET status = new_status, status_reason = p_reason WHERE id = p_vendor;

  IF new_status = 'active' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (v.user_id, 'vendor') ON CONFLICT DO NOTHING;
    PERFORM private.notify_user(v.user_id, 'Store reactivated',
      'Your store ' || v.store_name || ' is active again. Your dashboard, products, wallet and history are fully restored.', '/dashboard');
  ELSE
    -- account falls back to a normal customer account; nothing is deleted
    DELETE FROM public.user_roles WHERE user_id = v.user_id AND role = 'vendor';
    INSERT INTO public.user_roles (user_id, role) VALUES (v.user_id, 'customer') ON CONFLICT DO NOTHING;
    IF new_status = 'suspended' THEN
      PERFORM private.notify_user(v.user_id, 'Store suspended',
        'Your store ' || v.store_name || ' has been suspended. ' || COALESCE(p_reason,'') ||
        ' Your products are hidden and withdrawals are paused. All your data is preserved.', '/dashboard');
    ELSIF new_status = 'terminated' THEN
      PERFORM private.notify_user(v.user_id, 'Store terminated',
        'Your store ' || v.store_name || ' has been permanently terminated. ' || COALESCE(p_reason,''), '/dashboard');
    END IF;
  END IF;

  PERFORM private.log_financial('vendor_status_changed','vendor',p_vendor,p_vendor,
    to_jsonb(prev::text), jsonb_build_object('status', new_status::text, 'reason', p_reason));
END $$;

REVOKE ALL ON FUNCTION public.set_vendor_status(uuid,text,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_vendor_status(uuid,text,text) TO authenticated;

-- 5. Public availability check used by the cart -----------------------------
CREATE OR REPLACE FUNCTION public.products_availability(p_ids uuid[])
RETURNS TABLE(product_id uuid, available boolean, stock integer)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT p.id,
         (p.status = 'approved'
          AND (p.vendor_id IS NULL OR EXISTS (SELECT 1 FROM public.vendors v WHERE v.id = p.vendor_id AND v.status = 'active'))),
         GREATEST(p.stock - p.reserved_stock, 0)
    FROM public.products p
   WHERE p.id = ANY(p_ids)
$$;

REVOKE ALL ON FUNCTION public.products_availability(uuid[]) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.products_availability(uuid[]) TO anon, authenticated;

-- 6. Announcements to specific users ----------------------------------------
ALTER TABLE public.announcements ADD COLUMN IF NOT EXISTS target_user_ids uuid[];

DROP POLICY IF EXISTS ann_customers ON public.announcements;
DROP POLICY IF EXISTS ann_vendors ON public.announcements;
DROP POLICY IF EXISTS ann_admins ON public.announcements;

CREATE POLICY ann_customers ON public.announcements FOR SELECT TO authenticated
USING (target_user_ids IS NULL AND audience = ANY (ARRAY['all','customers']::announcement_audience[]) AND private.has_role(auth.uid(),'customer'));
CREATE POLICY ann_vendors ON public.announcements FOR SELECT TO authenticated
USING (target_user_ids IS NULL AND audience = ANY (ARRAY['all','vendors']::announcement_audience[]) AND private.has_role(auth.uid(),'vendor'));
CREATE POLICY ann_admins ON public.announcements FOR SELECT TO authenticated
USING (target_user_ids IS NULL AND audience = ANY (ARRAY['all','admins']::announcement_audience[]) AND (private.has_role(auth.uid(),'admin') OR private.has_role(auth.uid(),'super_admin')));
CREATE POLICY ann_targeted ON public.announcements FOR SELECT TO authenticated
USING (target_user_ids IS NOT NULL AND auth.uid() = ANY (target_user_ids));

-- 7. Notification preferences ------------------------------------------------
CREATE TABLE IF NOT EXISTS public.notification_preferences (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  orders boolean NOT NULL DEFAULT true,
  payments boolean NOT NULL DEFAULT true,
  wallet boolean NOT NULL DEFAULT true,
  announcements boolean NOT NULL DEFAULT true,
  reviews boolean NOT NULL DEFAULT true,
  push_enabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.notification_preferences TO authenticated;
GRANT ALL ON public.notification_preferences TO service_role;
ALTER TABLE public.notification_preferences ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS np_own ON public.notification_preferences;
CREATE POLICY np_own ON public.notification_preferences FOR ALL TO authenticated
USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

DROP TRIGGER IF EXISTS np_updated_at ON public.notification_preferences;
CREATE TRIGGER np_updated_at BEFORE UPDATE ON public.notification_preferences
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 8. Allow deleting own notifications ---------------------------------------
DROP POLICY IF EXISTS notif_own_delete ON public.notifications;
CREATE POLICY notif_own_delete ON public.notifications FOR DELETE TO authenticated
USING (user_id = auth.uid());