
DROP POLICY IF EXISTS productmedia_read ON storage.objects;
DROP POLICY IF EXISTS storelogos_read ON storage.objects;
CREATE POLICY productmedia_read ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'product-media');
CREATE POLICY storelogos_read ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'store-logos');

REVOKE SELECT ON public.vendors FROM anon;
GRANT SELECT (id, user_id, store_name, slug, description, logo_url, rating, total_sold, is_active, joined_at, updated_at)
  ON public.vendors TO anon;

DROP POLICY IF EXISTS pay_self_insert ON public.payments;
CREATE POLICY pay_self_insert ON public.payments FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND o.user_id = auth.uid())
  );

REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.current_user_role() FROM PUBLIC, anon, authenticated;
