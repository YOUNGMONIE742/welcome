-- Secure checkout: price and product ownership/status are always read from PostgreSQL,
-- and order + line items + payment proof are committed atomically.
CREATE OR REPLACE FUNCTION public.create_checkout_order(
  p_items jsonb,
  p_customer_name text,
  p_customer_email text,
  p_contact_phone text,
  p_shipping_address jsonb,
  p_notes text,
  p_transaction_id text,
  p_proof_path text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public, auth
AS $function$
DECLARE
  v_user_id uuid := auth.uid();
  v_item jsonb;
  v_product public.products%ROWTYPE;
  v_product_id uuid;
  v_quantity integer;
  v_unit_price numeric(12,2);
  v_subtotal numeric(12,2) := 0;
  v_shipping numeric(12,2) := 0;
  v_total numeric(12,2);
  v_order public.orders%ROWTYPE;
  v_customer_email text;
BEGIN
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'You must be signed in to place an order.' USING ERRCODE = '28000';
  END IF;

  IF jsonb_typeof(p_items) IS DISTINCT FROM 'array'
     OR jsonb_array_length(p_items) < 1
     OR jsonb_array_length(p_items) > 50 THEN
    RAISE EXCEPTION 'Your cart must contain between 1 and 50 line items.' USING ERRCODE = '22023';
  END IF;

  IF nullif(btrim(p_customer_name), '') IS NULL
     OR nullif(btrim(p_contact_phone), '') IS NULL
     OR jsonb_typeof(p_shipping_address) IS DISTINCT FROM 'object' THEN
    RAISE EXCEPTION 'Please provide your name, phone number, and shipping address.' USING ERRCODE = '22023';
  END IF;

  IF nullif(btrim(p_proof_path), '') IS NULL
     OR p_proof_path NOT LIKE (v_user_id::text || '/%') THEN
    RAISE EXCEPTION 'Payment proof must be uploaded to your own account folder.' USING ERRCODE = '22023';
  END IF;

  -- Validate quantities before casting/aggregating them.
  FOR v_item IN SELECT value FROM jsonb_array_elements(p_items) AS t(value) LOOP
    IF jsonb_typeof(v_item) IS DISTINCT FROM 'object'
       OR nullif(v_item->>'product_id', '') IS NULL
       OR coalesce((v_item->>'quantity')::integer, 0) < 1
       OR coalesce((v_item->>'quantity')::integer, 0) > 99 THEN
      RAISE EXCEPTION 'One or more cart items are invalid.' USING ERRCODE = '22023';
    END IF;
    v_product_id := (v_item->>'product_id')::uuid;
  END LOOP;

  -- Lock product rows in stable order and validate combined quantities for duplicate variants.
  FOR v_product_id, v_quantity IN
    SELECT (value->>'product_id')::uuid, sum((value->>'quantity')::integer)::integer
    FROM jsonb_array_elements(p_items) AS t(value)
    GROUP BY (value->>'product_id')::uuid
    ORDER BY (value->>'product_id')::uuid
  LOOP
    SELECT * INTO v_product
    FROM public.products
    WHERE id = v_product_id
    FOR UPDATE;

    IF NOT FOUND OR v_product.status <> 'approved' THEN
      RAISE EXCEPTION 'A product in your cart is no longer available.' USING ERRCODE = '22023';
    END IF;

    IF (v_product.stock - v_product.reserved_stock) < v_quantity THEN
      RAISE EXCEPTION 'Insufficient stock for product: %', v_product.title USING ERRCODE = '22023';
    END IF;

    IF v_product.vendor_id IS NOT NULL AND NOT EXISTS (
      SELECT 1 FROM public.vendors v
      WHERE v.id = v_product.vendor_id AND v.is_active = true
    ) THEN
      RAISE EXCEPTION 'A vendor product in your cart is currently unavailable.' USING ERRCODE = '22023';
    END IF;
  END LOOP;

  -- Server-calculated pricing; never trust prices, titles, vendors, or subtotals from the browser.
  FOR v_item IN SELECT value FROM jsonb_array_elements(p_items) AS t(value) LOOP
    v_product_id := (v_item->>'product_id')::uuid;
    v_quantity := (v_item->>'quantity')::integer;
    SELECT * INTO STRICT v_product FROM public.products WHERE id = v_product_id;
    v_unit_price := CASE
      WHEN v_product.discount_price_ngn IS NOT NULL
       AND v_product.discount_price_ngn > 0
       AND v_product.discount_price_ngn < v_product.price_ngn
        THEN v_product.discount_price_ngn
      ELSE v_product.price_ngn
    END;
    v_subtotal := v_subtotal + (v_unit_price * v_quantity);
  END LOOP;

  v_subtotal := round(v_subtotal, 2);
  v_total := v_subtotal + v_shipping;
  SELECT coalesce(nullif(btrim(p_customer_email), ''), u.email)
    INTO v_customer_email
  FROM auth.users u WHERE u.id = v_user_id;

  INSERT INTO public.orders (
    user_id, status, subtotal_ngn, shipping_ngn, total_ngn,
    contact_phone, customer_name, customer_email, notes,
    shipping_address, payment_expires_at
  ) VALUES (
    v_user_id, 'payment_review', v_subtotal, v_shipping, v_total,
    btrim(p_contact_phone), btrim(p_customer_name), v_customer_email,
    nullif(btrim(p_notes), ''), p_shipping_address, now() + interval '48 hours'
  ) RETURNING * INTO v_order;

  FOR v_item IN SELECT value FROM jsonb_array_elements(p_items) AS t(value) LOOP
    v_product_id := (v_item->>'product_id')::uuid;
    v_quantity := (v_item->>'quantity')::integer;
    SELECT * INTO STRICT v_product FROM public.products WHERE id = v_product_id;
    v_unit_price := CASE
      WHEN v_product.discount_price_ngn IS NOT NULL
       AND v_product.discount_price_ngn > 0
       AND v_product.discount_price_ngn < v_product.price_ngn
        THEN v_product.discount_price_ngn
      ELSE v_product.price_ngn
    END;

    INSERT INTO public.order_items (
      order_id, product_id, vendor_id, sold_by_type, title,
      unit_price_ngn, quantity, subtotal_ngn
    ) VALUES (
      v_order.id, v_product.id, v_product.vendor_id, v_product.sold_by_type,
      v_product.title || CASE WHEN nullif(btrim(v_item->>'variant'), '') IS NOT NULL
        THEN ' (' || btrim(v_item->>'variant') || ')' ELSE '' END,
      v_unit_price, v_quantity, round(v_unit_price * v_quantity, 2)
    );
  END LOOP;

  INSERT INTO public.payments (
    order_id, user_id, amount_ngn, transaction_id, proof_url
  ) VALUES (
    v_order.id, v_user_id, v_total,
    nullif(btrim(p_transaction_id), ''), btrim(p_proof_path)
  );

  RETURN jsonb_build_object(
    'id', v_order.id,
    'order_number', v_order.order_number,
    'subtotal_ngn', v_subtotal,
    'shipping_ngn', v_shipping,
    'total_ngn', v_total
  );
END;
$function$;

REVOKE ALL ON FUNCTION public.create_checkout_order(jsonb, text, text, text, jsonb, text, text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_checkout_order(jsonb, text, text, text, jsonb, text, text, text) TO authenticated;

-- Customers create orders through the validated RPC only; prevent direct client writes
-- that could spoof order status, prices, vendors, totals, or payment verification.
DROP POLICY IF EXISTS orders_self_insert ON public.orders;
DROP POLICY IF EXISTS oi_self_insert ON public.order_items;
DROP POLICY IF EXISTS pay_self_insert ON public.payments;
