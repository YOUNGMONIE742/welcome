# 🚀 Netlify Deployment Checklist

## Pre-Deployment (Do This First)

### 1. Rotate Supabase Secret Key ⚠️

**CRITICAL:** You shared your secret key in this session.

- Go to: Supabase Dashboard → Settings → API
- Click "Rotate Secret Key"
- Confirm rotation
- Update any backend services using the old key

### 2. Verify Local Build Works

```bash
npm install
npm run build
```

✅ Should complete with no errors.

### 3. Test Locally

```bash
npm run dev
```

Then test:

- [ ] Visit http://localhost:3000/auth → No 404
- [ ] Login/register works
- [ ] Google sign-in works
- [ ] WW Assistant chatbot works
- [ ] Can upload images

---

## Deploy to Netlify

### Step 1: Connect Repository

1. Go to [Netlify Dashboard](https://app.netlify.com)
2. Click "Add new site" → "Import an existing project"
3. Select GitHub → Choose `YOUNGMONIE742/welcomewagonmarket`
4. Click "Deploy site"

### Step 2: Add Environment Variables

While Netlify builds (or after):

1. Go to **Site settings** → **Build & deploy** → **Environment**
2. Add these variables:

| Key                             | Value                                                      |
| ------------------------------- | ---------------------------------------------------------- |
| `GROQ_API_KEY`                  | `[REDACTED_SECRET_ROTATE_THIS_KEY]` |
| `VITE_SUPABASE_URL`             | `https://zmiqeloawaufmgeefhjx.supabase.co`                 |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | `sb_publishable_xyxjV5BhrvplYWQU7eHuKw_t4hvWa8S`           |

3. Click "Save"

### Step 3: Configure Build Settings

**Netlify should auto-detect these. If not, set manually:**

| Setting           | Value               |
| ----------------- | ------------------- |
| Build command     | `npm run build`     |
| Publish directory | `.output/public`    |
| Node version      | `18.17.0` or higher |

### Step 4: Deploy

1. Go to **Deployments** tab
2. Click **Trigger deploy** → **Deploy site**
3. Wait for "Published" status (takes 2-3 minutes)
4. Netlify gives you a URL: `https://xxxxx.netlify.app`

---

## Post-Deployment Testing

### ✅ Test Each Feature

**Authentication**

- [ ] Visit `/auth`
- [ ] No 404 error
- [ ] Email/password login works
- [ ] Email/password register works
- [ ] Google sign-in works
- [ ] After login → redirects to `/dashboard`

**AI Assistant (WW Assistant)**

- [ ] Click floating robot icon
- [ ] Chat window opens
- [ ] Send message: "Hello"
- [ ] Gets response from Groq (not error)
- [ ] Send message: "Who built this?"
- [ ] Shows developer contact info

**Database & Forms**

- [ ] Browse `/shop`
- [ ] View products (loads from Supabase)
- [ ] Add to cart
- [ ] Checkout flow works
- [ ] Forms submit successfully

**Images**

- [ ] Products display images correctly
- [ ] Image previews load
- [ ] Can upload new images (if you have admin access)

---

## Troubleshooting

### Build Failed on Netlify

**"Missing GROQ_API_KEY"**

- Go to **Site settings** → **Build & deploy** → **Environment**
- Verify all 3 variables are added
- Click "Trigger deploy" again

**"Cannot find module @lovable.dev"**

- Run `npm install` locally first
- Push to GitHub
- Netlify auto-rebuilds

**Build times out**

- Check: `npm run build` completes locally in < 2 minutes
- If local build is slow, check disk space and dependencies

### Website Works But Features Don't

**Login/Auth shows 404 or redirects oddly**

- Clear browser storage: DevTools → Application → Storage → Clear all
- Hard refresh: Ctrl+Shift+R (or Cmd+Shift+R on Mac)
- Try incognito window

**WW Assistant shows errors**

- Check Groq API key is correct in Netlify env vars
- Verify Groq account has available credits
- Check browser console for exact error

**Images don't load**

- Verify Supabase Storage buckets exist:
  - `product-media`
  - `store-logos`
  - `user-avatars` (if used)
- Check bucket permissions allow public read access

**Google sign-in not working**

- Go to Supabase → Settings → Authentication → Providers
- Verify Google OAuth is enabled
- Check Google Cloud Console has the correct redirect URI:
  ```
  https://zmiqeloawaufmgeefhjx.supabase.co/auth/v1/callback
  ```

---

## Environment Variables Reference

### What Each Does

**`GROQ_API_KEY`**

- Used by: WW Assistant chatbot
- Where: Server-side only (`src/lib/ai-assistant.functions.ts`)
- Exposed in frontend? NO ✅
- Cost: $0.27 per 1M input tokens (very cheap)

**`VITE_SUPABASE_URL`**

- Used by: All Supabase requests (auth, database, storage)
- Where: Client-side (frontend)
- Exposed in frontend? YES (safe—it's a public URL) ✅
- Can anyone abuse it? No—protected by RLS policies

**`VITE_SUPABASE_PUBLISHABLE_KEY`**

- Used by: Authenticating frontend requests to Supabase
- Where: Client-side (frontend)
- Exposed in frontend? YES (safe—it's a public key) ✅
- Can anyone abuse it? Only within RLS policy limits

---

## Custom Domain (Optional)

Once deployed and working:

1. Go to Netlify → **Site settings** → **Domain management**
2. Click **Add custom domain**
3. Enter your domain (e.g., `welcomewagon.com`)
4. Follow DNS setup instructions
5. SSL certificate auto-generated (free)

---

## Monitoring & Logs

### View Deployment Logs

1. Netlify Dashboard → **Deployments** tab
2. Click latest deployment
3. See full build output + any errors

### View Runtime Errors

1. Netlify Dashboard → **Functions** (if you added any)
2. Or use Netlify Analytics to see traffic

### Monitor Groq Usage

- Go to [Groq Console](https://console.groq.com)
- Check API usage and costs

### Monitor Supabase Usage

- Go to [Supabase Dashboard](https://app.supabase.com)
- Check database queries, storage usage, auth events

---

## Rollback (If Something Breaks)

**Quick Rollback**

1. Netlify → **Deployments**
2. Find last working deployment
3. Click **...** → **Publish deploy**
4. Site reverts instantly

**Or: Revert Git Commit**

```bash
git revert HEAD
git push origin main
# Netlify auto-rebuilds
```

---

## Performance Tips

### Reduce Build Time

- Delete `.env.local` before pushing (use Netlify env vars only)
- Ensure `node_modules` isn't committed
- Check `.gitignore` is correct

### Reduce Bundle Size

- Already removed: `@lovable.dev/cloud-auth-js` ✅
- Already using: TanStack Start (efficient SSR)
- Consider: Image optimization for product photos

### Improve Server Response

- Groq: ~500ms per response (normal)
- Supabase: ~100-200ms per query (good)
- CDN caching: Netlify edge caching enabled

---

## Next Steps

1. ✅ All code is committed to `main`
2. ✅ Environment variables are ready
3. **→ Push to GitHub** (if not already)
4. **→ Connect to Netlify**
5. **→ Add environment variables to Netlify**
6. **→ Test all features**
7. **→ Set up custom domain** (optional)
8. **→ Monitor performance**

---

## Support & Questions

**Before asking for help, check:**

- [ ] All 3 env vars are in Netlify
- [ ] Local `npm run build` works
- [ ] Browser storage cleared
- [ ] Groq API key is valid
- [ ] Supabase project is accessible

**Common Issues:**

- 404 on `/auth` → Fixed! Should work now
- "Missing API key" → Add to Netlify env vars
- Auth not working → Check Supabase OAuth settings
- Images not loading → Check Supabase Storage buckets

---

**Your website is now ready for production deployment! 🎉**
