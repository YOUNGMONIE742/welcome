# Welcome Wagon Kids & More — Repair Status

## Applied to the correct Supabase project

Project reference: `zmiqeloawaufmgeefhjx` (project URL: `https://zmiqeloawaufmgeefhjx.supabase.co`). The other Supabase project was not changed.

The repair migration is tracked at `supabase/migrations/20261010155000_repair_marketplace_finance_and_security.sql`. It is a consolidated reference/replay migration; because the remote project was repaired through multiple managed migrations, reconcile local and remote migration histories before using `supabase db push` on this existing project. It aligns vendor profile and withdrawal fields, makes the customer-facing bank details settings public as intended, adds server-validated role management, fixes partial payout accounting, aligns wallet/sales statuses, writes vendor ledger entries for eligible sales/refunds/payouts, and changes the public vendor view to invoker security. Existing payout and ledger records are backfilled where possible.

## Website fixes included

- Vendor store editor fields now match the database schema.
- Admin role changes use the guarded `set_user_role` RPC instead of direct table writes. Super-admin assignment is restricted to the configured allowlist.
- Checkout refreshes current product prices and delivery fees from Supabase and displays the full transfer total. Checkout is blocked if those prices cannot be verified.
- Cart contents are checked against current product availability and stock.
- Admin financial audit queries now have a `vendor_id` column available in the database.
- Admin bank settings now save the bank details as public, matching the stated purpose of displaying them to customers and vendor applicants.

## Verification status

- Database repair migrations were applied to the correct live project.
- Updated TypeScript/TSX files passed a syntax transpilation check.
- A full Vite/TypeScript build could not be completed in this environment because dependency installation timed out; it remains unverified.
- Live authenticated end-to-end tests (customer checkout, vendor account, super-admin role actions, and real payout workflow) still require testing while signed in with the respective accounts. Do not treat the site as production-verified until these tests pass.

## Deployment environment

Use the public browser variables `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`. Configure `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, and `GROQ_API_KEY` only in the server/hosting secret settings when those server-side features are used. Never expose the service-role key with a `VITE_` prefix.
