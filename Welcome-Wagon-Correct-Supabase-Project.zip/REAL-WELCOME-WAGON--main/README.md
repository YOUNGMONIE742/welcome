# WELCOME WAGON MARKETPLACE

Build a production-ready responsive web application called:

WELCOME WAGON KIDS & More

Project Type: Multi-vendor marketplace / e-commerce platform.

Target: Nigeria only (NGN).

Platform: Website only.

Tech: Frontend: modern responsive web app Backend: integrated database + auth + storage Authentication: Email/Password + Google Login Storage: file upload support Mobile-first design

DO NOT generate placeholder-only UI. Build real database architecture, permissions, forms, workflows and dashboards.

================================================== BRANDING
Brand: Welcome Wagon Kids & More

Design Style: Luxury Marketplace + Kids Friendly Modern

Color Palette:

Sky Blue
Cream
Royal Purple
White
Soft Pink
Homepage Inspiration: 50% Etsy 30% Amazon 20% Jumia

Responsive: Android-first Desktop optimized

================================================== PUBLIC WEBSITE
Pages:

Home
Shop
Categories
Verified Vendors
About Us
Contact
Support
Track Order
Login
Register
Hide: Become Admin page from public navigation.

Navbar: Logo Search Categories Cart Login Register Profile

Footer: Company Support Contact Terms Privacy Social Links

================================================== AUTHENTICATION
Methods:

Email + Password
Google Login
Registration fields:

Full Name
Username
Email
Phone
Password
Database: Automatically create profile after registration.

profiles: id email full_name username phone role created_at

Roles: customer vendor admin super_admin

Never leave loading states.

Login redirects:

customer → customer dashboard vendor → vendor dashboard admin → admin dashboard super_admin → super admin dashboard

If profile missing: Auto-create.

================================================== SUPER ADMIN SECURITY
Only these emails may access super admin dashboard:

bhabeeb742@gmail.com Welcomewagonkidsandmore1@gmail.com

Rules: Any other user attempting access receives:

Access Denied You do not have permission.

No redirect.

================================================== ADMIN SYSTEM
Customers may apply to become admin.

Admin application: pending approved declined

Super Admin controls:

Enable applications Disable applications Approve Decline Keep pending

Admin applications hidden from public menu.

No payment required.

================================================== VENDOR SYSTEM
Customer may apply to become vendor.

Vendor dashboard must remain LOCKED until approval.

Vendor flow:

Customer → Apply → Store details → Upload store logo → Submit

Store names must be unique.

Application statuses: pending approved declined

If declined: Allow edit and reapply.

Vendor profile: logo description joined date ratings total sold contact vendor

================================================== VENDOR PAYMENT FLOW
Vendor does NOT receive access immediately.

Flow:

Customer → Apply Vendor → Super Admin reviews → Show Welcome Wagon bank account → Applicant pays → Upload proof

Required:

payment screenshot transaction ID amount

Super Admin: verify payment approve vendor decline keep pending

Only after approval: unlock vendor dashboard.

No subscriptions.

No automatic expiry.

================================================== PRODUCT SYSTEM
Welcome Wagon and approved vendors may upload products.

Fields:

title description category images optional video price_ngn stock low_stock_threshold vendor_id sold_by_type status

Product statuses:

draft pending_review approved declined

Workflow:

Vendor uploads → Pending Review → Admin/Super Admin approves → Product goes live

Vendor permissions: create edit own delete own view own sales

Admin: approve decline review

Super Admin: full control

================================================== SHOP
Features:

search categories filters sorting pagination

Product card: grid mode compact mode

Display: Low Stock

Product page: images optional video related products

Display:

Sold by Welcome Wagon

OR

Sold by Vendor Name

================================================== CART + CHECKOUT
Support:

multi-vendor cart

Customer: add to cart update quantity remove

Checkout: manual bank transfer

Upload:

payment screenshot transaction ID amount

Statuses:

pending_payment payment_review paid processing shipped delivered cancelled

================================================== SHIPPING
Website manages shipping.

Super Admin: may allow vendor shipping under conditions.

Order tracking: timeline status updates

================================================== COMMISSION
Super Admin controls:

default commission

vendor-specific commission

Vendor receives:

sale amount minus commission

Super Admin may override payout.

================================================== ANNOUNCEMENTS
Super Admin can send announcements.

Targets: customers vendors admins

Visibility rules: vendors cannot see admin-only announcements customers cannot see admin-only announcements

Delivery: dashboard email

================================================== CUSTOMER DASHBOARD
orders wishlist addresses notifications support chat

================================================== VENDOR DASHBOARD
sales products orders notifications support chat

================================================== ADMIN DASHBOARD
moderation vendor approval product approval users

================================================== SUPER ADMIN DASHBOARD
full analytics commissions approvals announcements bank settings access management

================================================== GENERAL RULES
NGN only

Do not publish automatically.

Production-ready.

Create database schema.

Create access control.

Create responsive UI.

Create all routes.

Create storage.

Create forms.

Create real workflows.

No mock-only implementation. and also make it in 3 phase

**Live app**: https://welcomewagonmarket.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/fd7e9c29-a7f0-4ea9-b722-f99a09bafe53).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
