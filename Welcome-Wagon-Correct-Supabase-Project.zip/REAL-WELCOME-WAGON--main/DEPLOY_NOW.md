# Deploy to Netlify — 3 Step Guide

**Important:** Follow this guide only after the updated project builds successfully and the customer, vendor, and Super Admin workflows have been tested. The latest environment could not complete dependency installation, so the current ZIP is not yet build-verified. See [REPAIR_STATUS.md](./REPAIR_STATUS.md) first.

---

## Step 1: Connect Your GitHub Repo

1. Go to: https://app.netlify.com
2. Click **"Add new site"** button
3. Select **"Import an existing project"**
4. Click **"GitHub"**
5. Search for: `welcomewagonmarket`
6. Select: `YOUNGMONIE742/welcomewagonmarket`
7. Click **"Install"** (if prompted)
8. Click **"Deploy site"**

**Netlify will start building. While it builds, go to Step 2.**

---

## Step 2: Add Environment Variables

1. In Netlify, go to **Site settings** tab
2. Click **"Build & deploy"** → **"Environment"**
3. Click **"Edit variables"**
4. Copy-paste each line exactly:

```
GROQ_API_KEY
[REDACTED_SECRET_ROTATE_THIS_KEY]

VITE_SUPABASE_URL
https://zmiqeloawaufmgeefhjx.supabase.co

VITE_SUPABASE_PUBLISHABLE_KEY
sb_publishable_xyxjV5BhrvplYWQU7eHuKw_t4hvWa8S
```

5. Click **"Save"**

---

## Step 3: Redeploy

1. Go to **Deployments** tab
2. Click **"Trigger deploy"** button
3. Select **"Deploy site"**
4. **Wait 2-3 minutes**
5. When status shows **"Published"** ✅ → You're LIVE!

---

## 🎉 You're Done!

Your site is now live at: `https://xxxxx.netlify.app`

### Test These:

- ✅ Visit `/auth` → Should NOT show 404
- ✅ Click "Register" → Create account
- ✅ Try "Continue with Google"
- ✅ Click the floating robot → WW Assistant should chat

---

## ❌ If Something Doesn't Work

### Build Failed?

- Go to **Deployments** → Click latest deployment
- Scroll down to see error message
- Usually missing env var → Go to Step 2 and double-check

### Auth shows 404?

- Clear browser cache: `Ctrl+Shift+Del` (or `Cmd+Shift+Del` on Mac)
- Hard refresh: `Ctrl+Shift+R` (or `Cmd+Shift+R` on Mac)
- Try incognito window

### AI Assistant not responding?

- Check env vars in Netlify are correct
- Verify Groq API key is active: https://console.groq.com

### Still stuck?

- Read `NETLIFY_DEPLOYMENT.md` for full troubleshooting
- Check `MIGRATION_SUMMARY.md` for technical details

---

## ✅ All Done!

You don't need to download anything. Everything is already in GitHub.

Netlify will automatically:

- ✅ Pull latest code from `main` branch
- ✅ Install dependencies
- ✅ Build with `npm run build`
- ✅ Deploy to global CDN
- ✅ Set up SSL certificate
- ✅ Enable auto-deploys on future pushes

**Go to https://app.netlify.com and deploy it now!** 🚀
