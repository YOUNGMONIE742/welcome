/**
 * Supabase-only authentication integration.
 * Handles OAuth (Google) and email/password auth via Supabase.
 * No Lovable dependency.
 */

import { supabase } from "../supabase/client";

type SignInOptions = {
  redirect_uri?: string;
  extraParams?: Record<string, string>;
};

export const lovable = {
  auth: {
    signInWithOAuth: async (
      provider: "google" | "apple" | "microsoft" | "lovable",
      opts?: SignInOptions,
    ) => {
      try {
        // Map provider names to Supabase OAuth providers
        let supabaseProvider: "google" | "github" | "apple" | "microsoft" = "google";
        if (provider === "apple") supabaseProvider = "apple";
        if (provider === "microsoft") supabaseProvider = "microsoft";
        if (provider === "lovable") supabaseProvider = "google"; // fallback to Google

        const { data, error } = await supabase.auth.signInWithOAuth({
          provider: supabaseProvider,
          options: {
            redirectTo: opts?.redirect_uri || window.location.origin + "/auth",
            queryParams: opts?.extraParams,
          },
        });

        if (error) {
          return { error };
        }

        // OAuth will redirect the browser
        return { redirected: true, url: data.url };
      } catch (e) {
        return { error: e instanceof Error ? e : new Error(String(e)) };
      }
    },
  },
};
