/**
 * Supabase auth storage for Netlify deployment.
 * Uses localStorage for session persistence.
 * Lovable preview-specific logic has been removed.
 */

export function brokeredPreviewStorage() {
  if (typeof window === "undefined") return undefined;

  try {
    const testKey = "__ww_auth_test__";
    window.localStorage.setItem(testKey, "1");
    window.localStorage.removeItem(testKey);
    return window.localStorage;
  } catch (err) {
    console.warn("[Auth Storage] localStorage access restricted, using in-memory storage fallback:", err);
    const memory = new Map<string, string>();
    return {
      getItem: (key: string) => memory.get(key) ?? null,
      setItem: (key: string, value: string) => { memory.set(key, value); },
      removeItem: (key: string) => { memory.delete(key); },
      clear: () => { memory.clear(); },
      key: (i: number) => Array.from(memory.keys())[i] ?? null,
      get length() { return memory.size; },
    } as Storage;
  }
}
