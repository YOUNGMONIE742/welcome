export function ngn(n: number | string | null | undefined): string {
  const v = typeof n === "string" ? Number(n) : (n ?? 0);
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0,
  }).format(Number.isFinite(v as number) ? (v as number) : 0);
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

export function statusBadge(status: string): { label: string; tone: string } {
  const map: Record<string, { label: string; tone: string }> = {
    pending: { label: "Pending", tone: "bg-amber-100 text-amber-800" },
    pending_review: { label: "Pending review", tone: "bg-amber-100 text-amber-800" },
    approved: { label: "Approved", tone: "bg-emerald-100 text-emerald-800" },
    declined: { label: "Declined", tone: "bg-rose-100 text-rose-800" },
    draft: { label: "Draft", tone: "bg-zinc-100 text-zinc-700" },
    pending_payment: { label: "Awaiting payment", tone: "bg-amber-100 text-amber-800" },
    payment_review: { label: "Payment review", tone: "bg-amber-100 text-amber-800" },
    paid: { label: "Paid", tone: "bg-emerald-100 text-emerald-800" },
    processing: { label: "Processing", tone: "bg-sky-100 text-sky-800" },
    shipped: { label: "Shipped", tone: "bg-indigo-100 text-indigo-800" },
    delivered: { label: "Delivered", tone: "bg-emerald-100 text-emerald-800" },
    cancelled: { label: "Cancelled", tone: "bg-rose-100 text-rose-800" },
  };
  return map[status] ?? { label: status, tone: "bg-zinc-100 text-zinc-700" };
}
