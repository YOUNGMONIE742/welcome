import { supabase } from "@/integrations/supabase/client";

export type Wallet = {
  vendor_id: string;
  store_name: string;
  is_active: boolean;
  commission_percent: number;
  gross_sales: number;
  commission_total: number;
  refunds_total: number;
  pending_balance: number;
  available_balance: number;
  wallet_balance: number;
  paid_out: number;
  withdrawals_requested: number;
  pending_withdrawals: number;
};

export type WithdrawalStatus =
  "pending" | "approved" | "partially_paid" | "paid" | "rejected" | "cancelled";

export const WITHDRAWAL_TONE: Record<string, { label: string; tone: string }> = {
  pending: { label: "Pending", tone: "bg-amber-100 text-amber-800" },
  approved: { label: "Approved", tone: "bg-sky-100 text-sky-800" },
  partially_paid: { label: "Partially paid", tone: "bg-indigo-100 text-indigo-800" },
  paid: { label: "Paid", tone: "bg-emerald-100 text-emerald-800" },
  rejected: { label: "Rejected", tone: "bg-rose-100 text-rose-800" },
  cancelled: { label: "Cancelled", tone: "bg-zinc-100 text-zinc-700" },
};

export const LEDGER_LABEL: Record<string, string> = {
  sale: "Sale",
  refund: "Refund reversal",
  payout: "Withdrawal payment",
  adjustment: "Wallet adjustment",
};

export function num(v: unknown): number {
  const n = Number(v ?? 0);
  return Number.isFinite(n) ? n : 0;
}

export async function fetchWallets(): Promise<Wallet[]> {
  const { data, error } = await supabase.rpc("vendor_wallets");
  if (error) throw error;
  return ((data ?? []) as unknown as Wallet[]).map((w) => ({
    ...w,
    commission_percent: num(w.commission_percent),
    gross_sales: num(w.gross_sales),
    commission_total: num(w.commission_total),
    refunds_total: num(w.refunds_total),
    pending_balance: num(w.pending_balance),
    available_balance: num(w.available_balance),
    wallet_balance: num(w.wallet_balance),
    paid_out: num(w.paid_out),
    withdrawals_requested: num(w.withdrawals_requested),
    pending_withdrawals: num(w.pending_withdrawals),
  }));
}

/** Mandatory re-authentication before any Super Admin financial write. */
export async function confirmSuperAdminPassword(password: string): Promise<boolean> {
  const { data: userData } = await supabase.auth.getUser();
  const email = userData.user?.email;
  if (!email || !password) return false;
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  return !error;
}
