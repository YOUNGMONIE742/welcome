import React from "react";
import { Text } from "@react-email/components";
import type { TemplateEntry } from "./registry";
import {
  DetailRow,
  EmailLayout,
  amountStyle,
  ngnText,
  panel,
  paragraph,
  smallMuted,
} from "./shared";

export interface WithdrawalPaymentCompletedProps {
  storeName?: string;
  reference?: string;
  paidNgn?: number;
  totalNgn?: number;
  outstandingNgn?: number;
  isPartial?: boolean;
  bankName?: string;
  accountNumber?: string;
  paidAt?: string;
}

const Email = ({
  storeName,
  reference,
  paidNgn,
  totalNgn,
  outstandingNgn,
  isPartial,
  bankName,
  accountNumber,
  paidAt,
}: WithdrawalPaymentCompletedProps) => (
  <EmailLayout
    preview={
      isPartial ? `Part payment sent for ${reference ?? ""}` : `Payment sent for ${reference ?? ""}`
    }
    title={isPartial ? "Part payment sent" : "Payment completed"}
  >
    <Text style={paragraph}>Hi {storeName ?? "there"},</Text>
    <Text style={paragraph}>
      {isPartial
        ? "We have sent a part payment towards your withdrawal. The remaining balance will follow in a separate transfer."
        : "Your withdrawal has been paid in full. The transfer has been sent to your saved bank account."}
    </Text>
    <div style={panel}>
      <Text style={smallMuted}>Amount paid</Text>
      <Text style={amountStyle}>{ngnText(paidNgn)}</Text>
    </div>
    <DetailRow label="Reference" value={reference ?? "—"} />
    <DetailRow label="Withdrawal total" value={ngnText(totalNgn)} />
    <DetailRow label="Outstanding" value={ngnText(outstandingNgn)} />
    {bankName ? <DetailRow label="Bank" value={bankName} /> : null}
    {accountNumber ? <DetailRow label="Account" value={accountNumber} /> : null}
    <DetailRow label="Paid on" value={paidAt ?? new Date().toLocaleString("en-NG")} />
    <Text style={smallMuted}>
      Bank settlement can take a few hours. The payment receipt is available in your wallet history.
    </Text>
  </EmailLayout>
);

export const template = {
  component: Email,
  subject: "Payment sent for your withdrawal",
  displayName: "Withdrawal payment completed",
  previewData: {
    storeName: "Tiny Steps Store",
    reference: "WD-000123",
    paidNgn: 100000,
    totalNgn: 150000,
    outstandingNgn: 50000,
    isPartial: true,
    bankName: "GTBank",
    accountNumber: "0123456789",
    paidAt: "5 Aug 2026, 14:02",
  },
} satisfies TemplateEntry;
