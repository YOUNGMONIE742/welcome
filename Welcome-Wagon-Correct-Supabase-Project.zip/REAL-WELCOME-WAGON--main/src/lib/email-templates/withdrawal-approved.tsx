import React from "react";
import { Text } from "@react-email/components";
import type { TemplateEntry } from "./registry";
import {
  DetailRow,
  EmailLayout,
  amountStyle,
  ngnText,
  panel,
  paragraph,
  smallMuted,
} from "./shared";

export interface WithdrawalApprovedProps {
  storeName?: string;
  reference?: string;
  amountNgn?: number;
  note?: string;
  bankName?: string;
  accountNumber?: string;
}

const Email = ({
  storeName,
  reference,
  amountNgn,
  note,
  bankName,
  accountNumber,
}: WithdrawalApprovedProps) => (
  <EmailLayout
    preview={`Withdrawal ${reference ?? ""} approved`}
    title="Your withdrawal was approved"
  >
    <Text style={paragraph}>Hi {storeName ?? "there"},</Text>
    <Text style={paragraph}>
      Good news — your withdrawal request has been <strong>approved</strong>. Payment will be sent
      to your saved bank account, and you will be notified once the transfer is completed. Large
      payouts may be settled in instalments.
    </Text>
    <div style={panel}>
      <Text style={smallMuted}>Approved amount</Text>
      <Text style={amountStyle}>{ngnText(amountNgn)}</Text>
    </div>
    <DetailRow label="Reference" value={reference ?? "—"} />
    {bankName ? <DetailRow label="Bank" value={bankName} /> : null}
    {accountNumber ? <DetailRow label="Account" value={accountNumber} /> : null}
    {note ? <DetailRow label="Note from finance team" value={note} /> : null}
    <Text style={smallMuted}>Track the status any time from your vendor wallet.</Text>
  </EmailLayout>
);

export const template = {
  component: Email,
  subject: "Your withdrawal request has been approved",
  displayName: "Withdrawal approved",
  previewData: {
    storeName: "Tiny Steps Store",
    reference: "WD-000123",
    amountNgn: 150000,
    bankName: "GTBank",
    accountNumber: "0123456789",
    note: "Approved for payout today.",
  },
} satisfies TemplateEntry;
