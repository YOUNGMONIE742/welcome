import React from "react";
import { Text } from "@react-email/components";
import type { TemplateEntry } from "./registry";
import {
  DetailRow,
  EmailLayout,
  amountStyle,
  ngnText,
  panel,
  paragraph,
  smallMuted,
} from "./shared";

export interface WithdrawalSubmittedProps {
  storeName?: string;
  reference?: string;
  amountNgn?: number;
  availableNgn?: number;
  requestedAt?: string;
}

const Email = ({
  storeName,
  reference,
  amountNgn,
  availableNgn,
  requestedAt,
}: WithdrawalSubmittedProps) => (
  <EmailLayout
    preview={`Withdrawal request ${reference ?? ""} received`}
    title="Withdrawal request received"
  >
    <Text style={paragraph}>Hi {storeName ?? "there"},</Text>
    <Text style={paragraph}>
      We have received your withdrawal request. It is now <strong>pending review</strong> by the
      Welcome Wagon finance team. You will get another update as soon as a decision is made.
    </Text>
    <div style={panel}>
      <Text style={smallMuted}>Amount requested</Text>
      <Text style={amountStyle}>{ngnText(amountNgn)}</Text>
    </div>
    <DetailRow label="Reference" value={reference ?? "—"} />
    <DetailRow label="Requested on" value={requestedAt ?? new Date().toLocaleString("en-NG")} />
    <DetailRow label="Available balance after request" value={ngnText(availableNgn)} />
    <Text style={smallMuted}>
      You can cancel this request from your wallet while it is still pending.
    </Text>
  </EmailLayout>
);

export const template = {
  component: Email,
  subject: "Your withdrawal request has been received",
  displayName: "Withdrawal submitted",
  previewData: {
    storeName: "Tiny Steps Store",
    reference: "WD-000123",
    amountNgn: 150000,
    availableNgn: 42000,
    requestedAt: "5 Aug 2026, 10:15",
  },
} satisfies TemplateEntry;
