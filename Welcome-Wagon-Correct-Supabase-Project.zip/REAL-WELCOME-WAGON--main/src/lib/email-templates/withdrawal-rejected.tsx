import React from "react";
import { Text } from "@react-email/components";
import type { TemplateEntry } from "./registry";
import {
  DetailRow,
  EmailLayout,
  amountStyle,
  ngnText,
  panel,
  paragraph,
  smallMuted,
} from "./shared";

export interface WithdrawalRejectedProps {
  storeName?: string;
  reference?: string;
  amountNgn?: number;
  reason?: string;
  availableNgn?: number;
}

const Email = ({
  storeName,
  reference,
  amountNgn,
  reason,
  availableNgn,
}: WithdrawalRejectedProps) => (
  <EmailLayout
    preview={`Withdrawal ${reference ?? ""} was declined`}
    title="Your withdrawal was declined"
  >
    <Text style={paragraph}>Hi {storeName ?? "there"},</Text>
    <Text style={paragraph}>
      Your withdrawal request was <strong>declined</strong> and the amount has been returned to your
      available wallet balance. You can correct the issue below and submit a new request at any
      time.
    </Text>
    <div style={panel}>
      <Text style={smallMuted}>Declined amount</Text>
      <Text style={amountStyle}>{ngnText(amountNgn)}</Text>
    </div>
    <DetailRow label="Reference" value={reference ?? "—"} />
    <DetailRow label="Reason" value={reason ?? "No reason provided"} />
    <DetailRow label="Available balance" value={ngnText(availableNgn)} />
    <Text style={smallMuted}>Confirm your bank details are correct before requesting again.</Text>
  </EmailLayout>
);

export const template = {
  component: Email,
  subject: "Update on your withdrawal request",
  displayName: "Withdrawal declined",
  previewData: {
    storeName: "Tiny Steps Store",
    reference: "WD-000123",
    amountNgn: 150000,
    reason: "Bank account name does not match the store owner.",
    availableNgn: 192000,
  },
} satisfies TemplateEntry;
