import type React from "react";

import { template as withdrawalSubmitted } from "./withdrawal-submitted";
import { template as withdrawalApproved } from "./withdrawal-approved";
import { template as withdrawalRejected } from "./withdrawal-rejected";
import { template as withdrawalPaymentCompleted } from "./withdrawal-payment-completed";

export interface TemplateEntry {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  component: (props: any) => React.ReactElement;
  subject: string;
  displayName?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  previewData?: Record<string, any>;
  to?: string;
}

export const TEMPLATES = {
  "withdrawal-submitted": withdrawalSubmitted,
  "withdrawal-approved": withdrawalApproved,
  "withdrawal-rejected": withdrawalRejected,
  "withdrawal-payment-completed": withdrawalPaymentCompleted,
} satisfies Record<string, TemplateEntry>;

export type TemplateName = keyof typeof TEMPLATES;
