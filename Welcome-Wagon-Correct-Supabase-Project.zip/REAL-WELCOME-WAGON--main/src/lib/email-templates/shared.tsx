import React from "react";
import {
  Body,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from "@react-email/components";

export const BRAND = {
  name: "Welcome Wagon Kids & More",
  primary: "#d94f8a",
  ink: "#1f1a1d",
  muted: "#6b6169",
  border: "#efe6eb",
};

export const main = {
  backgroundColor: "#ffffff",
  fontFamily: "Arial, Helvetica, sans-serif",
  color: BRAND.ink,
};
export const container = { maxWidth: "560px", margin: "0 auto", padding: "24px" };
export const heading = {
  fontSize: "22px",
  fontWeight: 700 as const,
  color: BRAND.ink,
  margin: "0 0 8px",
};
export const paragraph = {
  fontSize: "14px",
  lineHeight: "22px",
  color: BRAND.ink,
  margin: "0 0 12px",
};
export const smallMuted = { fontSize: "12px", lineHeight: "18px", color: BRAND.muted, margin: "0" };
export const panel = {
  border: `1px solid ${BRAND.border}`,
  borderRadius: "14px",
  padding: "16px",
  margin: "16px 0",
  backgroundColor: "#fdf7fa",
};
export const amountStyle = {
  fontSize: "24px",
  fontWeight: 700 as const,
  color: BRAND.primary,
  margin: "4px 0 0",
};

export function ngnText(amount: number | string | undefined): string {
  const n = Number(amount ?? 0);
  return `₦${(Number.isFinite(n) ? n : 0).toLocaleString("en-NG", { maximumFractionDigits: 2 })}`;
}

export function EmailLayout({
  preview,
  title,
  children,
}: {
  preview: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <Html lang="en" dir="ltr">
      <Head />
      <Preview>{preview}</Preview>
      <Body style={main}>
        <Container style={container}>
          <Text
            style={{ ...smallMuted, fontWeight: 700, color: BRAND.primary, letterSpacing: "1px" }}
          >
            {BRAND.name.toUpperCase()}
          </Text>
          <Heading style={heading}>{title}</Heading>
          <Section>{children}</Section>
          <Hr style={{ borderColor: BRAND.border, margin: "24px 0 12px" }} />
          <Text style={smallMuted}>
            Welcome Wagon Kids &amp; More · Shop A2 Hadidi Plaza 60, Isa Kaita Road, Kaduna, Nigeria
          </Text>
          <Text style={smallMuted}>
            Questions? Reply to this email or contact support on 08035909837.
          </Text>
        </Container>
      </Body>
    </Html>
  );
}

export function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <Text style={{ ...paragraph, margin: "0 0 6px" }}>
      <span style={{ color: BRAND.muted }}>{label}: </span>
      <strong>{value}</strong>
    </Text>
  );
}
