/**
 * Placeholder for error reporting.
 * Previously reported errors to Lovable's dashboard.
 * Now simply logs to console in development.
 */

export function reportLovableError(error: unknown, context: Record<string, unknown> = {}) {
  if (typeof window === "undefined") return;

  // Log to console in development for debugging
  if (process.env.NODE_ENV === "development") {
    console.error("Error boundary caught:", error, context);
  }

  // In production, you can integrate with Sentry or another error tracking service
  // For now, errors are handled by React's default error boundary behavior
}
