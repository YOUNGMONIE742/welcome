import { supabase } from "@/integrations/supabase/client";

/** Ask once for device notification permission (Android, iOS 16.4+, Windows, macOS). */
export async function requestPushPermission(): Promise<boolean> {
  if (typeof window === "undefined" || !("Notification" in window)) return false;
  if (Notification.permission === "granted") return true;
  if (Notification.permission === "denied") return false;
  try {
    const res = await Notification.requestPermission();
    if (res === "granted") {
      const { data } = await supabase.auth.getUser();
      if (data.user) {
        await supabase
          .from("notification_preferences")
          .upsert({ user_id: data.user.id, push_enabled: true }, { onConflict: "user_id" });
      }
      return true;
    }
  } catch {
    /* ignore */
  }
  return false;
}

/** Show a device notification when permission has been granted. */
export function showPush(title: string, body: string) {
  if (typeof window === "undefined" || !("Notification" in window)) return;
  if (Notification.permission !== "granted") return;
  try {
    new Notification(title, { body, icon: "/favicon.ico", tag: title });
  } catch {
    /* ignore */
  }
}
