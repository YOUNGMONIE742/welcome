import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export type CartItem = {
  product_id: string;
  title: string;
  slug: string;
  price_ngn: number;
  quantity: number;
  image?: string | null;
  vendor_id: string | null;
  vendor_name: string;
  sold_by_type: "vendor" | "welcome_wagon";
  stock: number;
  /** Human-readable variant selection, e.g. "Size: M · Color: red". */
  variant?: string | null;
};

/** Items with the same product but different variants are separate lines. */
export function cartKey(product_id: string, variant?: string | null): string {
  return `${product_id}::${variant ?? ""}`;
}

type CartCtx = {
  items: CartItem[];
  count: number;
  subtotal: number;
  add: (item: CartItem) => void;
  setQty: (product_id: string, qty: number, variant?: string | null) => void;
  remove: (product_id: string, variant?: string | null) => void;
  clear: () => void;
};

const Ctx = createContext<CartCtx | null>(null);
const KEY = "wwk_cart_v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = window.localStorage.getItem(KEY);
      if (raw) setItems(JSON.parse(raw) as CartItem[]);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(KEY, JSON.stringify(items));
  }, [items]);

  const add = useCallback((item: CartItem) => {
    setItems((prev) => {
      const key = cartKey(item.product_id, item.variant);
      const ex = prev.find((p) => cartKey(p.product_id, p.variant) === key);
      if (ex) {
        const q = Math.min(ex.quantity + item.quantity, item.stock || 99);
        return prev.map((p) =>
          cartKey(p.product_id, p.variant) === key ? { ...p, quantity: q } : p,
        );
      }
      return [...prev, { ...item, quantity: Math.min(item.quantity, item.stock || 99) }];
    });
  }, []);

  const setQty = useCallback((product_id: string, qty: number, variant?: string | null) => {
    const key = cartKey(product_id, variant);
    setItems((prev) =>
      prev
        .map((p) =>
          cartKey(p.product_id, p.variant) === key
            ? { ...p, quantity: Math.max(0, Math.min(qty, p.stock || 99)) }
            : p,
        )
        .filter((p) => p.quantity > 0),
    );
  }, []);

  const remove = useCallback((product_id: string, variant?: string | null) => {
    const key = cartKey(product_id, variant);
    setItems((prev) => prev.filter((p) => cartKey(p.product_id, p.variant) !== key));
  }, []);

  const clear = useCallback(() => setItems([]), []);

  // Cart protection: drop products whose store was suspended/terminated or that
  // are no longer approved, so customers never check out unavailable items.
  useEffect(() => {
    if (items.length === 0) return;
    let cancelled = false;
    (async () => {
      const ids = items.map((i) => i.product_id);
      const { data, error } = await supabase.rpc("products_availability", { p_ids: ids });
      if (cancelled || error || !data) return;
      const rows = data as Array<{ product_id: string; available: boolean; stock: number }>;
      const gone = new Set(rows.filter((r) => !r.available || r.stock < 1).map((r) => r.product_id));
      for (const id of ids) if (!rows.some((r) => r.product_id === id)) gone.add(id);
      const stockById = new Map(rows.map((r) => [r.product_id, Math.max(0, r.stock)]));
      const needsStockAdjustment = items.some((item) => !gone.has(item.product_id) && item.quantity > (stockById.get(item.product_id) ?? 0));
      if (gone.size === 0 && !needsStockAdjustment) return;
      setItems((prev) => prev
        .filter((p) => !gone.has(p.product_id))
        .map((p) => ({ ...p, quantity: Math.min(p.quantity, stockById.get(p.product_id) ?? 0) }))
        .filter((p) => p.quantity > 0));
      if (gone.size > 0) toast.error("An unavailable product was removed from your cart.");
      else toast.message("Your cart quantities were updated to match available stock.");
    })();
    return () => {
      cancelled = true;
    };
    // re-check whenever product IDs or quantities change
  }, [items.map((i) => `${i.product_id}:${i.quantity}`).join(",")]); // eslint-disable-line react-hooks/exhaustive-deps

  const value = useMemo<CartCtx>(
    () => ({
      items,
      count: items.reduce((n, i) => n + i.quantity, 0),
      subtotal: items.reduce((n, i) => n + i.quantity * Number(i.price_ngn), 0),
      add,
      setQty,
      remove,
      clear,
    }),
    [items, add, setQty, remove, clear],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart(): CartCtx {
  const v = useContext(Ctx);
  if (!v) throw new Error("useCart must be used inside <CartProvider>");
  return v;
}
