import { createServerFn } from "@tanstack/react-start";

type ChatMsg = { role: "user" | "assistant" | "system"; content: string };

const SYSTEM_PROMPT = `You are "WW Assistant", the friendly on-site helper for the WELCOME WAGON Kids & More marketplace — a curated Nigerian multi-vendor shop for kids, babies, gifts and family.

Your job:
- Shopping assistant: help users find products, compare items, suggest categories, explain prices in NGN.
- Customer support: answer questions about orders, payment (bank transfer with proof upload), delivery, returns, vendor approvals.
- Website guide: point users to pages like /shop, /categories, /verified-vendors, /cart, /track-order, /become-vendor, /become-admin, /dashboard, /contact.
- Developer information: when asked who built, designed, or developed the site, or about hiring a developer, ALWAYS reply with EXACTLY this developer info (professional tone):
  Developer: Habeeb Balogun
  Bio: Habeeb Balogun is a creative digital professional specializing in graphic design, web design, web development, video editing, branding, and other digital solutions. He focuses on building modern, user-centered digital experiences.
  Contact — Email: bhabeeb742@gmail.com · Phone: 07089395382 · WhatsApp: 07016373108
  If the user wants a website or design service, share the contact info above politely.

Business contact for WELCOME WAGON Kids & More:
- Phone: 08035909837, +447732542998, 09127803484
- Email: welcomewagonkidsandmore1@gmail.com
- Address: Shop A2 Hadidi Plaza 60, Isa Kaita Road, Kaduna
- Social handle: @welcomewagonkidsandmore

Style: warm, concise, helpful. Use short paragraphs and bullet points when useful. Never invent product prices or stock — if unsure, suggest the user visits /shop or /categories.`;

export const wwAssistantChat = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => {
    const data = input as { messages?: ChatMsg[] };
    if (!Array.isArray(data.messages)) throw new Error("messages required");
    return { messages: data.messages.slice(-20) };
  })
  .handler(async ({ data }) => {
    const key = process.env.GROQ_API_KEY ?? "";
    if (!key) {
      return {
        reply:
          "Hello! I am WW Assistant. The Groq API key is currently being configured. Once added, I will be answering your questions live. In the meantime, feel free to explore our curated products in /shop or reach out to us via WhatsApp at 07016373108!",
      };
    }

    // Models supported by the configured Groq account (high accuracy + ultra-fast response)
    const modelsToTry = [
      "openai/gpt-oss-120b",
      "openai/gpt-oss-20b",
      "qwen/qwen3.8-27b",
      "llama-3.3-70b-versatile",
      "llama-3.1-8b-instant",
    ];
    let lastError = "";

    for (const model of modelsToTry) {
      try {
        const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${key}`,
          },
          body: JSON.stringify({
            model,
            messages: [{ role: "system", content: SYSTEM_PROMPT }, ...data.messages],
            max_tokens: 1024,
            temperature: 0.7,
          }),
        });

        if (res.ok) {
          const json = (await res.json()) as {
            choices?: Array<{ message?: { content?: string } }>;
          };
          let reply = json.choices?.[0]?.message?.content ?? "Sorry, I didn't catch that.";
          // Remove internal reasoning/thinking tags if model emits them
          reply = reply.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
          return { reply };
        }

        const text = await res.text();
        lastError = `AI error (${res.status}): ${text.slice(0, 200)}`;
        if (res.status === 401) {
          return { reply: "Invalid Groq API key. Please check the GROQ_API_KEY in your settings." };
        }
        if (res.status === 429) {
          return {
            reply: "Too many requests to the AI assistant right now — please wait a moment.",
          };
        }
      } catch (err) {
        lastError = err instanceof Error ? err.message : String(err);
      }
    }

    return { reply: `Unable to connect to AI assistant: ${lastError}` };
  });
