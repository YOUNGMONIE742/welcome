import { supabase } from "@/integrations/supabase/client";
import type { TemplateName } from "@/lib/email-templates/registry";

/**
 * Email sending is intentionally DISABLED until a custom sender domain is connected.
 * Templates and triggers are fully built; flip this to `true` (after the sender
 * domain is verified) to start delivering the emails for real.
 * In-app notifications are unaffected and keep working either way.
 */
export const EMAILS_ENABLED = false;

export type SendEmailInput = {
  templateName: TemplateName;
  recipientEmail: string;
  idempotencyKey: string;
  templateData?: Record<string, unknown>;
};

export type SendEmailResult = { status: "sent" | "skipped" | "error"; reason?: string };

/** Sends one app email to one recipient. No-ops while sending is disabled. */
export async function sendAppEmail(input: SendEmailInput): Promise<SendEmailResult> {
  if (!EMAILS_ENABLED) {
    if (import.meta.env.DEV) {
      console.info(
        "[email disabled] would send",
        input.templateName,
        "→",
        input.recipientEmail,
        input.templateData,
      );
    }
    return { status: "skipped", reason: "sending_disabled" };
  }
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData.session?.access_token;
    const res = await fetch("/lovable/email/transactional/send", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...(token ? { authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(input),
    });
    if (!res.ok) return { status: "error", reason: `${res.status} ${await res.text()}` };
    return { status: "sent" };
  } catch (e) {
    return { status: "error", reason: e instanceof Error ? e.message : "unknown_error" };
  }
}
