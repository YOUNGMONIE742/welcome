import { supabase } from "@/integrations/supabase/client";
import { sendAppEmail, type SendEmailResult } from "./send";

type Base = {
  vendorId: string;
  withdrawalId: string;
  reference: string;
};

async function vendorContext(vendorId: string) {
  const [{ data: vendor }, { data: bank }] = await Promise.all([
    supabase
      .from("vendors")
      .select("store_name, contact_email, user_id")
      .eq("id", vendorId)
      .maybeSingle(),
    supabase
      .from("vendor_bank_accounts")
      .select("bank_name, account_number")
      .eq("vendor_id", vendorId)
      .maybeSingle(),
  ]);
  let email = vendor?.contact_email ?? null;
  if (!email && vendor?.user_id) {
    const { data: profile } = await supabase
      .from("profiles")
      .select("email")
      .eq("id", vendor.user_id)
      .maybeSingle();
    email = profile?.email ?? null;
  }
  return {
    email,
    storeName: vendor?.store_name ?? "Vendor",
    bankName: bank?.bank_name ?? undefined,
    accountNumber: bank?.account_number ?? undefined,
  };
}

/** Withdrawal submitted → vendor confirmation. */
export async function emailWithdrawalSubmitted(
  p: Base & { amountNgn: number; availableNgn?: number },
): Promise<SendEmailResult> {
  const ctx = await vendorContext(p.vendorId);
  if (!ctx.email) return { status: "skipped", reason: "no_recipient" };
  return sendAppEmail({
    templateName: "withdrawal-submitted",
    recipientEmail: ctx.email,
    idempotencyKey: `withdrawal-submitted-${p.withdrawalId}`,
    templateData: {
      storeName: ctx.storeName,
      reference: p.reference,
      amountNgn: p.amountNgn,
      availableNgn: p.availableNgn,
      requestedAt: new Date().toLocaleString("en-NG"),
    },
  });
}

/** Withdrawal approved → vendor notice. */
export async function emailWithdrawalApproved(
  p: Base & { amountNgn: number; note?: string },
): Promise<SendEmailResult> {
  const ctx = await vendorContext(p.vendorId);
  if (!ctx.email) return { status: "skipped", reason: "no_recipient" };
  return sendAppEmail({
    templateName: "withdrawal-approved",
    recipientEmail: ctx.email,
    idempotencyKey: `withdrawal-approved-${p.withdrawalId}`,
    templateData: {
      storeName: ctx.storeName,
      reference: p.reference,
      amountNgn: p.amountNgn,
      note: p.note,
      bankName: ctx.bankName,
      accountNumber: ctx.accountNumber,
    },
  });
}

/** Withdrawal rejected → vendor notice with reason. */
export async function emailWithdrawalRejected(
  p: Base & { amountNgn: number; reason?: string; availableNgn?: number },
): Promise<SendEmailResult> {
  const ctx = await vendorContext(p.vendorId);
  if (!ctx.email) return { status: "skipped", reason: "no_recipient" };
  return sendAppEmail({
    templateName: "withdrawal-rejected",
    recipientEmail: ctx.email,
    idempotencyKey: `withdrawal-rejected-${p.withdrawalId}`,
    templateData: {
      storeName: ctx.storeName,
      reference: p.reference,
      amountNgn: p.amountNgn,
      reason: p.reason,
      availableNgn: p.availableNgn,
    },
  });
}

/** Payment (full or partial) recorded → vendor receipt. */
export async function emailWithdrawalPaymentCompleted(
  p: Base & { paidNgn: number; totalNgn: number; alreadyPaidNgn: number },
): Promise<SendEmailResult> {
  const ctx = await vendorContext(p.vendorId);
  if (!ctx.email) return { status: "skipped", reason: "no_recipient" };
  const outstanding = Math.max(0, p.totalNgn - (p.alreadyPaidNgn + p.paidNgn));
  return sendAppEmail({
    templateName: "withdrawal-payment-completed",
    recipientEmail: ctx.email,
    idempotencyKey: `withdrawal-payment-${p.withdrawalId}-${p.alreadyPaidNgn + p.paidNgn}`,
    templateData: {
      storeName: ctx.storeName,
      reference: p.reference,
      paidNgn: p.paidNgn,
      totalNgn: p.totalNgn,
      outstandingNgn: outstanding,
      isPartial: outstanding > 0,
      bankName: ctx.bankName,
      accountNumber: ctx.accountNumber,
      paidAt: new Date().toLocaleString("en-NG"),
    },
  });
}
