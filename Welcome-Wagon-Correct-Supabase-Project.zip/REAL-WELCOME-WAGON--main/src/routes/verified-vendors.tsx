import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PageShell } from "@/components/page-shell";
import { ShieldCheck, Star } from "lucide-react";
import { StoredImage } from "@/components/stored-image";

export const Route = createFileRoute("/verified-vendors")({
  head: () => ({
    meta: [
      { title: "Verified Vendors — Welcome Wagon Kids & More" },
      { name: "description", content: "Meet the verified Nigerian vendors selling on Welcome Wagon Kids & More." },
      { property: "og:title", content: "Verified Vendors" },
      { property: "og:description", content: "Trusted small businesses, vetted by Welcome Wagon." },
    ],
  }),
  component: Vendors,
});

function Vendors() {
  const { data } = useQuery({
    queryKey: ["vendors-all"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("public_vendors" as never)
        .select("id, store_name, slug, description, logo_url, rating, total_sold, joined_at")
        .order("rating", { ascending: false })
        .limit(200);
      if (error) throw error;
      return (data ?? []) as Array<{ id: string; store_name: string; slug: string; description: string | null; logo_url: string | null; rating: number; total_sold: number; joined_at: string }>;
    },
  });

  return (
    <PageShell>
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="flex items-center gap-2 text-primary">
          <ShieldCheck className="h-5 w-5" /><span className="text-sm font-semibold uppercase tracking-wider">Verified</span>
        </div>
        <h1 className="mt-2 font-display text-3xl font-bold md:text-4xl">Our verified vendors</h1>
        <p className="text-sm text-muted-foreground">Every vendor is reviewed by Welcome Wagon before going live.</p>
        {!data || data.length === 0 ? (
          <div className="soft-card mt-10 p-10 text-center text-sm text-muted-foreground">
            We're onboarding our first vendors. Check back soon.
          </div>
        ) : (
          <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {data.map((v) => (
              <div key={v.id} className="soft-card p-5">
                <div className="flex items-center gap-3">
                  <div className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-2xl bg-accent text-primary">
                    {v.logo_url ? (
                      <StoredImage bucket="store-logos" path={v.logo_url} alt={v.store_name} className="h-full w-full object-cover" />
                    ) : (
                      <ShieldCheck className="h-6 w-6" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <h3 className="truncate font-display text-lg font-semibold">{v.store_name}</h3>
                    <p className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Star className="h-3 w-3 fill-amber-400 text-amber-400" /> {Number(v.rating).toFixed(1)} · {v.total_sold} sold
                    </p>
                  </div>
                </div>
                {v.description && <p className="mt-3 line-clamp-3 text-sm text-muted-foreground">{v.description}</p>}
                <p className="mt-3 text-xs text-muted-foreground">Joined {new Date(v.joined_at).toLocaleDateString("en-NG", { month: "short", year: "numeric" })}</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </PageShell>
  );
}