import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const Route = createFileRoute("/support")({
  head: () => ({
    meta: [
      { title: "Support — Welcome Wagon Kids & More" },
      { name: "description", content: "Get help, find answers and read our terms & privacy policy." },
      { property: "og:title", content: "Support" },
      { property: "og:description", content: "Help center for Welcome Wagon Kids & More." },
    ],
  }),
  component: Support,
});

const FAQS = [
  { q: "How do I pay?", a: "All orders are paid via manual bank transfer to our Welcome Wagon account. At checkout you'll upload your payment screenshot and transaction ID." },
  { q: "Where do you ship?", a: "Across Nigeria. Shipping is managed by Welcome Wagon for most orders; some vendors may ship directly with super-admin approval." },
  { q: "Are products approved?", a: "Yes. Every product is reviewed by Welcome Wagon admins before it goes live in the marketplace." },
  { q: "How do I become a vendor?", a: "Create a customer account, apply to become a vendor with your store details, complete the one-time setup payment, and wait for super-admin verification." },
  { q: "Refunds & returns", a: "Reach out via Contact within 48 hours of delivery and we'll guide you through it. Phase 2 will include in-app return requests." },
];

function Support() {
  return (
    <PageShell>
      <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <h1 className="font-display text-3xl font-bold md:text-4xl">Support & FAQs</h1>
        <p className="mt-2 text-sm text-muted-foreground">Quick answers to common questions.</p>
        <Accordion type="single" collapsible className="mt-8">
          {FAQS.map((f, i) => (
            <AccordionItem key={i} value={`item-${i}`}>
              <AccordionTrigger className="text-left font-medium">{f.q}</AccordionTrigger>
              <AccordionContent className="text-sm text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="soft-card mt-12 p-6">
          <h2 className="font-display text-lg font-semibold">Terms & Privacy (summary)</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            By using Welcome Wagon Kids & More you agree to our terms: prices are in NGN, payments are by manual bank transfer, vendor products are reviewed before listing, and orders are subject to availability. Your data is used only to operate this marketplace.
          </p>
        </div>
      </section>
    </PageShell>
  );
}