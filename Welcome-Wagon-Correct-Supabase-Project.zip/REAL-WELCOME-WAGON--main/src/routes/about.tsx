import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Heart, ShieldCheck, Sparkles } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Welcome Wagon Kids & More" },
      { name: "description", content: "Welcome Wagon Kids & More is a Nigerian-curated marketplace for premium kids and family essentials." },
      { property: "og:title", content: "About Welcome Wagon Kids & More" },
      { property: "og:description", content: "A curated Nigerian marketplace for families." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <PageShell>
      <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <span className="chip"><Sparkles className="h-3 w-3" /> Our story</span>
        <h1 className="mt-4 font-display text-4xl font-bold md:text-5xl">Built for Nigerian families.</h1>
        <p className="mt-5 text-base text-muted-foreground md:text-lg">
          Welcome Wagon Kids & More is a curated multi-vendor marketplace where parents discover premium baby essentials, kids fashion, toys, gifts and nursery goods from verified Nigerian small businesses — without ever leaving home.
        </p>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          <div className="soft-card p-5">
            <ShieldCheck className="h-6 w-6 text-primary" />
            <h3 className="mt-3 font-display text-lg font-semibold">Verified vendors</h3>
            <p className="mt-1 text-sm text-muted-foreground">Every seller passes our review process before going live.</p>
          </div>
          <div className="soft-card p-5">
            <Heart className="h-6 w-6 text-primary" />
            <h3 className="mt-3 font-display text-lg font-semibold">Curated for kids</h3>
            <p className="mt-1 text-sm text-muted-foreground">Hand-picked categories with families in mind.</p>
          </div>
          <div className="soft-card p-5">
            <Sparkles className="h-6 w-6 text-primary" />
            <h3 className="mt-3 font-display text-lg font-semibold">Pay in Naira</h3>
            <p className="mt-1 text-sm text-muted-foreground">All prices in NGN. Manual bank transfer at checkout.</p>
          </div>
        </div>
      </section>
    </PageShell>
  );
}