import { createFileRoute, Link, useNavigate, useParams } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { FileUpload } from "@/components/file-upload";
import { ArrowLeft, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/products/$id/edit")({
  head: () => ({ meta: [{ title: "Edit product — Welcome Wagon" }] }),
  component: EditProduct,
});

function EditProduct() {
  const { id } = useParams({ from: "/_authenticated/products/$id/edit" });
  const { user, primaryRole } = useAuth();
  const navigate = useNavigate();
  const isStaff = primaryRole === "admin" || primaryRole === "super_admin";
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("0");
  const [categoryId, setCategoryId] = useState("");
  const [supplier, setSupplier] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const { data: product, isLoading } = useQuery({
    queryKey: ["product", id],
    queryFn: async () => {
      const { data } = await supabase.from("products").select("*").eq("id", id).maybeSingle();
      return data;
    },
  });
  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data } = await supabase.from("categories").select("id, name").order("display_order");
      return data ?? [];
    },
  });

  useEffect(() => {
    if (!product) return;
    setTitle(product.title ?? "");
    setDescription(product.description ?? "");
    setPrice(String(product.price_ngn ?? ""));
    setStock(String(product.stock ?? 0));
    setCategoryId(product.category_id ?? "");
    setSupplier((product as { supplier?: string | null }).supplier ?? "");
    setImage(product.primary_image_url ?? null);
  }, [product]);

  if (isLoading) return <PageShell><div className="p-10 text-center text-sm text-muted-foreground">Loading…</div></PageShell>;
  if (!product) return <PageShell><div className="p-10 text-center">Product not found.</div></PageShell>;
  const canEdit = isStaff || product.created_by === user?.id;
  if (!canEdit) return <PageShell><div className="p-10 text-center">You cannot edit this product.</div></PageShell>;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.from("products").update({
      title, description: description || null, price_ngn: Number(price), stock: Number(stock),
      category_id: categoryId || null, supplier: supplier || null, primary_image_url: image,
      // Send back to review when a vendor edits an approved item
      status: isStaff ? product!.status : (product!.status === "approved" ? "pending_review" : product!.status),
    }).eq("id", id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Product saved");
    navigate({ to: "/products" });
  }

  async function remove() {
    if (!confirm("Delete this product? This cannot be undone.")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    navigate({ to: "/products" });
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
        <Link to="/products" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> My products</Link>
        <div className="mt-4 flex items-center justify-between">
          <h1 className="font-display text-3xl font-bold">Edit product</h1>
          <Button type="button" variant="outline" className="rounded-full text-destructive" onClick={remove}><Trash2 className="mr-1 h-4 w-4" /> Delete</Button>
        </div>
        <form onSubmit={save} className="soft-card mt-6 space-y-4 p-6">
          <label className="block">
            <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Title *</span>
            <input value={title} required onChange={(e) => setTitle(e.target.value)} className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary" />
          </label>
          <label className="block">
            <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Description</span>
            <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4} className="w-full rounded-xl border border-border bg-card p-3 text-sm outline-none focus:border-primary" />
          </label>
          <div className="grid gap-3 sm:grid-cols-3">
            <label className="block"><span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Price (NGN) *</span>
              <input value={price} type="number" min="0" required onChange={(e) => setPrice(e.target.value)} className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary" />
            </label>
            <label className="block"><span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Stock *</span>
              <input value={stock} type="number" min="0" required onChange={(e) => setStock(e.target.value)} className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary" />
            </label>
            <label className="block"><span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Category</span>
              <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary">
                <option value="">—</option>
                {(categories ?? []).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </label>
          </div>
          <label className="block"><span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Supplier</span>
            <input value={supplier} onChange={(e) => setSupplier(e.target.value)} className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary" />
          </label>
          <div>
            <label className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Primary image</label>
            <FileUpload bucket="product-media" prefix={user?.id ?? "anon"} value={image} onChange={setImage} label="Upload image" />
          </div>
          <div className="flex gap-2 pt-2">
            <Button type="submit" className="rounded-full" disabled={busy}>{busy ? "Saving…" : "Save changes"}</Button>
          </div>
        </form>
      </section>
    </PageShell>
  );
}