import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageShell } from "@/components/page-shell";
import { LoadingScreen } from "@/components/loading-screen";
import { AccessDenied } from "@/components/access-denied";
import { Button } from "@/components/ui/button";
import { StoredImage } from "@/components/stored-image";
import { useAuth } from "@/lib/auth-context";
import { ngn } from "@/lib/format";
import { fetchWallets, LEDGER_LABEL, WITHDRAWAL_TONE, num, type Wallet } from "@/lib/finance";
import { emailWithdrawalSubmitted } from "@/lib/email/withdrawal-emails";
import { ArrowLeft, Banknote, Landmark, Wallet as WalletIcon, Loader2, ReceiptText } from "lucide-react";

export const Route = createFileRoute("/_authenticated/wallet")({
  head: () => ({
    meta: [
      { title: "Vendor Wallet — Welcome Wagon Kids & More" },
      { name: "description", content: "Track your Welcome Wagon earnings, marketplace commission, pending balance and withdrawals." },
      { property: "og:title", content: "Vendor Wallet — Welcome Wagon Kids & More" },
      { property: "og:description", content: "Earnings, commission, payouts and withdrawal history for Welcome Wagon vendors." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: VendorWallet,
});

type Withdrawal = {
  id: string; reference: string; amount_ngn: number; paid_ngn: number; status: string;
  note: string | null; decision_reason: string | null; created_at: string;
  withdrawal_payments: Array<{ id: string; amount_ngn: number; proof_url: string | null; created_at: string }>;
};

function VendorWallet() {
  const { loading, roles, user } = useAuth();
  const qc = useQueryClient();

  const { data: vendor, isLoading: vLoading } = useQuery({
    queryKey: ["wallet-vendor", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("vendors").select("id, store_name, is_active").eq("user_id", user!.id).maybeSingle();
      return data;
    },
  });

  const { data: wallets } = useQuery({ queryKey: ["vendor-wallets"], queryFn: fetchWallets });
  const wallet: Wallet | undefined = wallets?.find((w) => w.vendor_id === vendor?.id);

  const { data: bank } = useQuery({
    queryKey: ["vendor-bank", vendor?.id],
    enabled: !!vendor?.id,
    queryFn: async () => {
      const { data } = await supabase.from("vendor_bank_accounts").select("*").eq("vendor_id", vendor!.id).maybeSingle();
      return data;
    },
  });

  const { data: withdrawals } = useQuery({
    queryKey: ["vendor-withdrawals", vendor?.id],
    enabled: !!vendor?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("withdrawals")
        .select("id, reference, amount_ngn, paid_ngn, status, note, decision_reason, created_at, withdrawal_payments(id, amount_ngn, proof_url, created_at)")
        .eq("vendor_id", vendor!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Withdrawal[];
    },
  });

  const { data: ledger } = useQuery({
    queryKey: ["vendor-ledger", vendor?.id],
    enabled: !!vendor?.id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vendor_ledger")
        .select("*")
        .eq("vendor_id", vendor!.id)
        .order("created_at", { ascending: true })
        .limit(300);
      if (error) throw error;
      return data ?? [];
    },
  });

  if (loading || vLoading) return <PageShell><LoadingScreen /></PageShell>;
  if (!roles.includes("vendor") || !vendor) {
    return <PageShell><section className="mx-auto max-w-3xl px-4 py-12"><AccessDenied /></section></PageShell>;
  }

  function refresh() {
    qc.invalidateQueries({ queryKey: ["vendor-wallets"] });
    qc.invalidateQueries({ queryKey: ["vendor-withdrawals"] });
    qc.invalidateQueries({ queryKey: ["vendor-ledger"] });
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> Dashboard</Link>
        <div className="mt-3 flex items-center gap-3">
          <WalletIcon className="h-6 w-6 text-primary" />
          <h1 className="font-display text-3xl font-bold">My wallet</h1>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          {vendor.store_name} · marketplace commission {wallet ? wallet.commission_percent : 0}% is deducted from every sale before your earnings.
        </p>

        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="Wallet balance" value={wallet?.wallet_balance} accent />
          <Stat label="Available balance" value={wallet?.available_balance} />
          <Stat label="Pending balance" value={wallet?.pending_balance} />
          <Stat label="Paid out" value={wallet?.paid_out} />
          <Stat label="Gross sales" value={wallet?.gross_sales} />
          <Stat label="Marketplace commission" value={wallet?.commission_total} />
          <Stat label="Refunds" value={wallet?.refunds_total} />
          <Stat label="Total withdrawals requested" value={wallet?.withdrawals_requested} />
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <BankCard vendorId={vendor.id} bank={bank as never} onSaved={() => qc.invalidateQueries({ queryKey: ["vendor-bank"] })} />
          <RequestCard vendorId={vendor.id} available={wallet?.available_balance ?? 0} hasBank={!!bank} onDone={refresh} />
        </div>

        <h2 className="mt-10 font-display text-2xl font-bold">Withdrawal & payment history</h2>
        <div className="mt-3 space-y-3">
          {!withdrawals || withdrawals.length === 0 ? (
            <p className="soft-card p-6 text-sm text-muted-foreground">No withdrawal requests yet.</p>
          ) : withdrawals.map((w) => {
            const tone = WITHDRAWAL_TONE[w.status] ?? { label: w.status, tone: "bg-secondary" };
            return (
              <article key={w.id} className="soft-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="font-mono text-sm font-bold">{w.reference}</p>
                    <p className="text-xs text-muted-foreground">{new Date(w.created_at).toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${tone.tone}`}>{tone.label}</span>
                    <p className="mt-1 text-sm font-bold text-primary">{ngn(w.amount_ngn)}</p>
                    <p className="text-xs text-muted-foreground">Paid {ngn(w.paid_ngn)} · Outstanding {ngn(num(w.amount_ngn) - num(w.paid_ngn))}</p>
                  </div>
                </div>
                {w.decision_reason && <p className="mt-2 rounded-md bg-muted/50 p-2 text-xs italic">{w.decision_reason}</p>}
                {w.withdrawal_payments?.length > 0 && (
                  <ul className="mt-3 space-y-2 border-t border-border/60 pt-3">
                    {w.withdrawal_payments.map((p) => (
                      <li key={p.id} className="flex items-center gap-3 text-xs">
                        <ReceiptText className="h-4 w-4 text-muted-foreground" />
                        <span className="font-semibold">{ngn(p.amount_ngn)}</span>
                        <span className="text-muted-foreground">{new Date(p.created_at).toLocaleString()}</span>
                        {p.proof_url && (
                          <span className="ml-auto h-16 w-16 overflow-hidden rounded-lg border border-border">
                            <StoredImage bucket="payment-proofs" path={p.proof_url ?? undefined} alt="Payment proof" className="h-full w-full object-cover" />
                          </span>
                        )}
                      </li>
                    ))}
                  </ul>
                )}
                {w.status === "pending" && (
                  <div className="mt-3">
                    <Button variant="outline" size="sm" className="rounded-full" onClick={async () => {
                      const { error } = await supabase.rpc("cancel_withdrawal", { p_id: w.id });
                      if (error) return toast.error(error.message);
                      toast.success("Request cancelled");
                      refresh();
                    }}>Cancel request</Button>
                  </div>
                )}
              </article>
            );
          })}
        </div>

        <h2 className="mt-10 font-display text-2xl font-bold">Transaction ledger</h2>
        <LedgerTable rows={ledger ?? []} />
      </section>
    </PageShell>
  );
}

export function Stat({ label, value, accent }: { label: string; value: number | undefined; accent?: boolean }) {
  return (
    <div className="soft-card p-5">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className={`mt-1 font-display text-2xl font-bold ${accent ? "text-primary" : ""}`}>{ngn(value ?? 0)}</p>
    </div>
  );
}

export function LedgerTable({ rows }: { rows: Array<Record<string, unknown>> }) {
  let running = 0;
  const withBalance: Array<Record<string, unknown>> = rows
    .map((r) => {
      running += num(r.amount_ngn);
      return { ...r, balance_after: running } as Record<string, unknown>;
    })
    .reverse();
  if (withBalance.length === 0) return <p className="soft-card mt-3 p-6 text-sm text-muted-foreground">No transactions recorded yet.</p>;
  return (
    <div className="soft-card mt-3 overflow-x-auto">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead className="bg-secondary/60 text-xs uppercase tracking-wide text-muted-foreground">
          <tr>
            <th className="p-3">Date & time</th><th className="p-3">Type</th><th className="p-3">Description</th>
            <th className="p-3 text-right">Amount</th><th className="p-3 text-right">Balance after</th><th className="p-3">Reference</th>
          </tr>
        </thead>
        <tbody>
          {withBalance.map((r) => (
            <tr key={String(r.id)} className="border-t border-border/60">
              <td className="p-3 text-xs text-muted-foreground">{new Date(String(r.created_at)).toLocaleString()}</td>
              <td className="p-3 text-xs font-semibold">{LEDGER_LABEL[String(r.entry_type)] ?? String(r.entry_type)}</td>
              <td className="p-3 text-xs">{String(r.description ?? "—")}</td>
              <td className={`p-3 text-right font-semibold ${num(r.amount_ngn) < 0 ? "text-rose-600" : "text-emerald-600"}`}>{ngn(num(r.amount_ngn))}</td>
              <td className="p-3 text-right">{ngn(num(r.balance_after))}</td>
              <td className="p-3 font-mono text-[11px] text-muted-foreground">{String(r.reference)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function BankCard({ vendorId, bank, onSaved }: { vendorId: string; bank: { bank_name: string; account_name: string; account_number: string } | null; onSaved: () => void }) {
  const [form, setForm] = useState({ bank_name: "", account_name: "", account_number: "" });
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (bank) setForm({ bank_name: bank.bank_name, account_name: bank.account_name, account_number: bank.account_number });
  }, [bank]);

  async function save() {
    if (!form.bank_name.trim() || !form.account_name.trim() || !/^\d{6,20}$/.test(form.account_number.trim())) {
      return toast.error("Enter a bank name, account name and a valid account number.");
    }
    setBusy(true);
    const { error } = await supabase.from("vendor_bank_accounts").upsert(
      { vendor_id: vendorId, ...form, account_number: form.account_number.trim() },
      { onConflict: "vendor_id" },
    );
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Bank account saved");
    onSaved();
  }

  return (
    <div className="soft-card p-5">
      <div className="flex items-center gap-2"><Landmark className="h-5 w-5 text-primary" /><h2 className="font-display text-lg font-semibold">Bank account</h2></div>
      <p className="mt-1 text-xs text-muted-foreground">Payouts are sent to this account. Only you can edit it.</p>
      <div className="mt-4 space-y-3">
        <Field label="Bank name" value={form.bank_name} onChange={(v) => setForm({ ...form, bank_name: v })} />
        <Field label="Account name" value={form.account_name} onChange={(v) => setForm({ ...form, account_name: v })} />
        <Field label="Account number" value={form.account_number} onChange={(v) => setForm({ ...form, account_number: v.replace(/\D/g, "") })} />
        <Button className="rounded-full" onClick={save} disabled={busy}>
          {busy && <Loader2 className="mr-1 h-4 w-4 animate-spin" />}{bank ? "Update bank details" : "Add bank account"}
        </Button>
      </div>
    </div>
  );
}

function RequestCard({ vendorId, available, hasBank, onDone }: { vendorId: string; available: number; hasBank: boolean; onDone: () => void }) {
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    const v = Number(amount);
    if (!Number.isFinite(v) || v <= 0) return toast.error("Enter a valid amount");
    setBusy(true);
    const { data: newId, error } = await supabase.rpc("request_withdrawal", { p_amount: v, p_note: note || undefined });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Withdrawal request submitted");
    const { data: row } = await supabase.from("withdrawals").select("id, reference").eq("id", newId as string).maybeSingle();
    if (row) {
      await emailWithdrawalSubmitted({
        vendorId,
        withdrawalId: row.id,
        reference: row.reference,
        amountNgn: v,
        availableNgn: Math.max(0, available - v),
      });
    }
    setAmount(""); setNote("");
    onDone();
  }

  return (
    <div className="soft-card p-5">
      <div className="flex items-center gap-2"><Banknote className="h-5 w-5 text-primary" /><h2 className="font-display text-lg font-semibold">Request withdrawal</h2></div>
      <p className="mt-1 text-xs text-muted-foreground">Available for withdrawal: <strong className="text-foreground">{ngn(available)}</strong></p>
      {!hasBank && <p className="mt-2 rounded-md bg-amber-100 p-2 text-xs text-amber-900">Add your bank account details first.</p>}
      <div className="mt-4 space-y-3">
        <Field label="Amount (NGN)" value={amount} onChange={(v) => setAmount(v.replace(/[^\d.]/g, ""))} />
        <Field label="Note (optional)" value={note} onChange={setNote} />
        <Button className="rounded-full" onClick={submit} disabled={busy || !hasBank || available <= 0}>
          {busy && <Loader2 className="mr-1 h-4 w-4 animate-spin" />}Submit request
        </Button>
      </div>
    </div>
  );
}

export function Field({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <label className="block">
      <span className="text-xs font-semibold text-muted-foreground">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 h-10 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary"
      />
    </label>
  );
}
