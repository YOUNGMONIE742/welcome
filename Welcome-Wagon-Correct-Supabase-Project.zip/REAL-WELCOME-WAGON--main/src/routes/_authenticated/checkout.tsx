import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart-context";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { ngn } from "@/lib/format";
import { FileUpload } from "@/components/file-upload";
import { useState } from "react";
import { toast } from "sonner";
import { Landmark, ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/checkout")({
  head: () => ({ meta: [{ title: "Checkout — Welcome Wagon Kids & More" }] }),
  component: Checkout,
});

function Checkout() {
  const cart = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState(user?.email ?? "");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [notes, setNotes] = useState("");
  const [txId, setTxId] = useState("");
  const [proofPath, setProofPath] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const { data: checkoutProducts, isLoading: checkoutProductsLoading, isError: checkoutProductsError } = useQuery({
    queryKey: ["checkout-pricing", cart.items.map((item) => item.product_id).sort().join(",")],
    enabled: cart.items.length > 0,
    queryFn: async () => {
      const ids = [...new Set(cart.items.map((item) => item.product_id))];
      const { data, error } = await supabase
        .from("products")
        .select("id, price_ngn, discount_price_ngn, shipping_fee_ngn")
        .in("id", ids);
      if (error) throw error;
      return Object.fromEntries((data ?? []).map((product) => [product.id, {
        price_ngn: Number(product.price_ngn),
        discount_price_ngn: product.discount_price_ngn == null ? null : Number(product.discount_price_ngn),
        shipping_fee_ngn: Number(product.shipping_fee_ngn ?? 0),
      }])) as Record<string, { price_ngn: number; discount_price_ngn: number | null; shipping_fee_ngn: number }>;
    },
  });
  const currentPrice = (productId: string) => {
    const product = checkoutProducts?.[productId];
    if (!product) return 0;
    return product.discount_price_ngn != null && product.discount_price_ngn > 0 && product.discount_price_ngn < product.price_ngn
      ? product.discount_price_ngn : product.price_ngn;
  };
  const checkoutSubtotal = cart.items.reduce((sum, item) => sum + currentPrice(item.product_id) * item.quantity, 0);
  const shippingTotal = cart.items.reduce((sum, item) => sum + Number(checkoutProducts?.[item.product_id]?.shipping_fee_ngn ?? 0) * item.quantity, 0);
  const checkoutTotal = checkoutSubtotal + shippingTotal;
  const canCheckout = !checkoutProductsLoading && !checkoutProductsError && cart.items.every((item) => !!checkoutProducts?.[item.product_id]);

  const { data: bank } = useQuery({
    queryKey: ["public-bank"],
    queryFn: async () => {
      const { data } = await supabase.from("settings").select("value").eq("key", "bank_details").maybeSingle();
      return (data?.value ?? {}) as { bank_name?: string; account_name?: string; account_number?: string };
    },
  });

  if (cart.items.length === 0) {
    return (
      <PageShell>
        <section className="mx-auto max-w-2xl px-4 py-16 text-center">
          <h1 className="font-display text-2xl font-bold">Your cart is empty</h1>
          <Link to="/shop" className="mt-3 inline-block text-sm font-medium text-primary hover:underline">Go shopping →</Link>
        </section>
      </PageShell>
    );
  }

  async function placeOrder(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    if (!proofPath) return toast.error("Please upload your payment proof.");
    setBusy(true);

    const { data: result, error: checkoutError } = await supabase.rpc("create_checkout_order", {
      p_items: cart.items.map((item) => ({
        product_id: item.product_id,
        quantity: item.quantity,
        variant: item.variant ?? null,
      })),
      p_customer_name: fullName.trim(),
      p_customer_email: (email || user.email || "").trim(),
      p_contact_phone: phone.trim(),
      p_shipping_address: {
        full_name: fullName.trim(),
        email: (email || user.email || "").trim(),
        address: address.trim(),
        city: city.trim(),
        state: state.trim(),
        postal_code: postalCode.trim(),
      },
      p_notes: notes.trim() || null,
      p_transaction_id: txId.trim() || null,
      p_proof_path: proofPath,
    });

    if (checkoutError || !result || typeof result !== "object" || !("order_number" in result)) {
      setBusy(false);
      return toast.error(checkoutError?.message ?? "Failed to create order. Please try again.");
    }
    const orderNumber = String(result.order_number);
    setBusy(false);
    cart.clear();
    toast.success(`Order ${orderNumber} placed — awaiting payment verification.`);
    navigate({ to: "/orders" });
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
        <Link to="/cart" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> Back to cart</Link>
        <h1 className="mt-4 font-display text-3xl font-bold md:text-4xl">Checkout</h1>

        <form onSubmit={placeOrder} className="mt-8 grid gap-6 lg:grid-cols-[1fr_360px]">
          <div className="space-y-6">
            <div className="soft-card p-5">
              <h2 className="font-display text-lg font-semibold">Shipping details</h2>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <Field label="Full name" value={fullName} onChange={setFullName} required />
                <Field label="Email address" value={email} onChange={setEmail} required />
                <Field label="Phone (NG)" value={phone} onChange={setPhone} required />
                <Field label="Address" value={address} onChange={setAddress} required className="sm:col-span-2" />
                <Field label="City" value={city} onChange={setCity} required />
                <Field label="State" value={state} onChange={setState} required />
                <Field label="Postal code (optional)" value={postalCode} onChange={setPostalCode} />
              </div>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Delivery notes (optional)"
                className="mt-3 w-full rounded-xl border border-border bg-card p-3 text-sm outline-none focus:border-primary"
                rows={2}
              />
            </div>

            <div className="soft-card p-5">
              <div className="flex items-center gap-2">
                <Landmark className="h-5 w-5 text-primary" />
                <h2 className="font-display text-lg font-semibold">Bank transfer payment</h2>
              </div>
              {bank?.account_number ? (
                <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-3">
                  <div><dt className="text-xs text-muted-foreground">Bank</dt><dd className="font-semibold">{bank.bank_name}</dd></div>
                  <div><dt className="text-xs text-muted-foreground">Account name</dt><dd className="font-semibold">{bank.account_name}</dd></div>
                  <div><dt className="text-xs text-muted-foreground">Account number</dt><dd className="font-mono font-semibold">{bank.account_number}</dd></div>
                </dl>
              ) : (
                <p className="mt-2 rounded-xl border border-dashed border-border bg-muted/40 p-3 text-sm text-muted-foreground">
                  Bank details not yet set. Please contact support before paying.
                </p>
              )}
              <p className="mt-3 text-xs text-muted-foreground">
                Transfer <strong>{ngn(checkoutTotal)}</strong> (including delivery) to the account above, then upload your proof and transaction ID below.
              </p>
              <div className="mt-3 grid gap-3">
                <Field label="Transaction ID / reference" value={txId} onChange={setTxId} />
                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Payment proof (image / PDF)</label>
                  <FileUpload
                    bucket="payment-proofs"
                    prefix={user?.id ?? "anon"}
                    accept="image/*,application/pdf"
                    maxMB={5}
                    label="Upload proof"
                    value={proofPath}
                    onChange={setProofPath}
                  />
                </div>
              </div>
            </div>
          </div>

          <aside className="soft-card h-fit p-5">
            <h2 className="font-display text-lg font-semibold">Order summary</h2>
            <ul className="mt-3 space-y-2 text-sm">
              {cart.items.map((it) => (
                <li key={`${it.product_id}-${it.variant ?? ""}`} className="flex justify-between gap-2">
                  <span className="line-clamp-1">{it.quantity} × {it.title}{it.variant ? ` (${it.variant})` : ""}</span>
                  <span className="font-semibold">{ngn(currentPrice(it.product_id) * it.quantity)}</span>
                </li>
              ))}
            </ul>
            <div className="mt-4 space-y-2 border-t border-border pt-3 text-sm">
              <div className="flex justify-between"><span>Subtotal</span><span>{ngn(checkoutSubtotal)}</span></div>
              <div className="flex justify-between"><span>Delivery</span><span>{ngn(shippingTotal)}</span></div>
              <div className="flex items-baseline justify-between border-t border-border pt-3">
                <span className="font-semibold">Total</span>
                <span className="font-display text-xl font-bold text-primary">{ngn(checkoutTotal)}</span>
              </div>
            </div>
            {checkoutProductsError && <p className="mt-3 text-xs text-destructive">Could not verify current prices and delivery fees. Refresh the page before paying.</p>}
            {checkoutProductsLoading && <p className="mt-3 text-xs text-muted-foreground">Checking current prices and delivery fees…</p>}
            {!checkoutProductsLoading && !checkoutProductsError && !canCheckout && <p className="mt-3 text-xs text-destructive">One or more cart items are unavailable. Return to your cart and refresh it.</p>}
            {!bank?.account_number && <p className="mt-3 text-xs text-destructive">Checkout is paused until the store bank account is configured in Admin Settings.</p>}
            <Button type="submit" disabled={busy || !canCheckout || !bank?.account_number} className="mt-4 w-full rounded-full">
              {busy ? "Placing…" : "Place order"}
            </Button>
          </aside>
        </form>
      </section>
    </PageShell>
  );
}

function Field({ label, value, onChange, required, className }: { label: string; value: string; onChange: (v: string) => void; required?: boolean; className?: string }) {
  return (
    <label className={`block ${className ?? ""}`}>
      <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">{label}{required && " *"}</span>
      <input
        value={value}
        required={required}
        onChange={(e) => onChange(e.target.value)}
        className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary"
      />
    </label>
  );
}