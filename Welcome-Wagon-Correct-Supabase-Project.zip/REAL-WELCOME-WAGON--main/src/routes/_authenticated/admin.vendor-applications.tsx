import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";
import { useState } from "react";
import { toast } from "sonner";
import { StoredImage, useSignedUrl } from "@/components/stored-image";
import { ngn, statusBadge } from "@/lib/format";
import { FileText, ExternalLink } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/vendor-applications")({
  component: VendorAppsAdmin,
});

function VendorAppsAdmin() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"pending" | "approved" | "declined">("pending");
  const { data: apps, isLoading } = useQuery({
    queryKey: ["admin-vendor-apps", filter],
    queryFn: async () => {
      const { data: rows } = await supabase
        .from("vendor_applications")
        .select("*")
        .eq("status", filter)
        .order("created_at", { ascending: false });
      if (!rows || rows.length === 0) return [];
      const ids = Array.from(new Set(rows.map((r) => r.user_id)));
      const { data: profs } = await supabase.from("profiles").select("id, email, full_name").in("id", ids);
      const byId = new Map((profs ?? []).map((p) => [p.id, p]));
      return rows.map((r) => ({ ...r, profile: byId.get(r.user_id) ?? null }));
    },
  });

  async function approve(app: { id: string }) {
    // Atomic server-side approval: creates the store, grants the vendor role
    // and marks the application approved in one transaction.
    const { error } = await supabase.rpc("approve_vendor_application", { p_app_id: app.id });
    if (error) return toast.error(error.message);
    toast.success("Vendor approved — store and vendor access activated");
    qc.invalidateQueries({ queryKey: ["admin-vendor-apps"] });
  }
  async function decline(id: string) {
    const reason = prompt("Reason for decline?") ?? "";
    if (!reason) return;
    const { error } = await supabase
      .from("vendor_applications")
      .update({ status: "declined", decline_reason: reason, reviewed_by: user!.id, reviewed_at: new Date().toISOString() })
      .eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Declined");
    qc.invalidateQueries({ queryKey: ["admin-vendor-apps"] });
  }

  return (
    <div>
      <div className="mb-4 flex gap-2">
        {(["pending", "approved", "declined"] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`rounded-full px-3 py-1 text-xs font-semibold capitalize ${filter === f ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{f}</button>
        ))}
      </div>
      {isLoading ? <p className="text-sm text-muted-foreground">Loading…</p> : !apps || apps.length === 0 ? (
        <p className="soft-card p-8 text-center text-sm text-muted-foreground">No {filter} applications.</p>
      ) : (
        <ul className="space-y-3">
          {apps.map((a) => {
            const profile = a.profile;
            return (
              <li key={a.id} className="soft-card p-5">
                <div className="flex flex-wrap items-start gap-4">
                  <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-secondary">
                    <StoredImage bucket="store-logos" path={a.store_logo_url} alt={a.store_name} className="h-full w-full object-cover" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-display text-lg font-semibold">{a.store_name}</h3>
                    <p className="text-xs text-muted-foreground">{profile?.full_name ?? profile?.email} · {a.contact_phone ?? "no phone"}</p>
                    {a.store_description && <p className="mt-1 text-sm">{a.store_description}</p>}
                    <div className="mt-2 flex flex-wrap gap-3 text-xs">
                      <span>Amount: <strong>{a.payment_amount ? ngn(Number(a.payment_amount)) : "—"}</strong></span>
                      <span>TX: <span className="font-mono">{a.payment_transaction_id ?? "—"}</span></span>
                      <ProofLink path={a.payment_proof_url} />
                    </div>
                  </div>
                  {a.status === "pending" ? (
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="rounded-full" onClick={() => decline(a.id)}>Decline</Button>
                      <Button size="sm" className="rounded-full" onClick={() => approve(a)}>Approve</Button>
                    </div>
                  ) : (
                    <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${statusBadge(a.status).tone}`}>{statusBadge(a.status).label}</span>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function ProofLink({ path }: { path: string | null }) {
  const { data: url } = useSignedUrl("payment-proofs", path);
  if (!path) return <span className="text-muted-foreground">No proof</span>;
  if (!url) return <span className="text-muted-foreground">Loading…</span>;
  return <a href={url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-medium text-primary hover:underline"><FileText className="h-3 w-3" /> View proof <ExternalLink className="h-3 w-3" /></a>;
}