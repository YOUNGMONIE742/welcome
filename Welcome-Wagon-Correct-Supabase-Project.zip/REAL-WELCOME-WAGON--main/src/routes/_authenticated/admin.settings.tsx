import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { FileUpload } from "@/components/file-upload";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/admin/settings")({
  component: SettingsAdmin,
});

function SettingsAdmin() {
  const qc = useQueryClient();
  const { user } = useAuth();
  const { data } = useQuery({
    queryKey: ["all-settings"],
    queryFn: async () => {
      const { data } = await supabase.from("settings").select("key, value");
      return Object.fromEntries((data ?? []).map((s) => [s.key, s.value]));
    },
  });

  const [bankName, setBankName] = useState("");
  const [accountName, setAccountName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [commission, setCommission] = useState("10");
  const [setupFee, setSetupFee] = useState("");
  const [vendorEnabled, setVendorEnabled] = useState(true);
  const [adminEnabled, setAdminEnabled] = useState(true);
  const [logo, setLogo] = useState<string | null>(null);

  useEffect(() => {
    if (!data) return;
    const b = (data.bank_details ?? {}) as {
      bank_name?: string;
      account_name?: string;
      account_number?: string;
    };
    setBankName(b.bank_name ?? "");
    setAccountName(b.account_name ?? "");
    setAccountNumber(b.account_number ?? "");
    setCommission(String(data.default_commission_percent ?? 10));
    setSetupFee(data.vendor_setup_fee_ngn ? String(data.vendor_setup_fee_ngn) : "");
    setVendorEnabled(data.vendor_applications_enabled !== false);
    setAdminEnabled(data.admin_applications_enabled !== false);
    setLogo((data.site_logo_url as string | null) ?? null);
  }, [data]);

  async function save(key: string, value: unknown, is_public = true) {
    const { error } = await supabase
      .from("settings")
      .upsert({ key, value: value as never, is_public });
    if (error) toast.error(error.message);
  }

  async function saveAll() {
    await Promise.all([
      save(
        "bank_details",
        { bank_name: bankName, account_name: accountName, account_number: accountNumber },
        true,
      ),
      save("default_commission_percent", Number(commission)),
      save("vendor_setup_fee_ngn", setupFee ? Number(setupFee) : null),
      save("vendor_applications_enabled", vendorEnabled),
      save("admin_applications_enabled", adminEnabled),
      save("site_logo_url", logo),
    ]);
    toast.success("Settings saved");
    qc.invalidateQueries({ queryKey: ["all-settings"] });
    qc.invalidateQueries({ queryKey: ["public-settings"] });
    qc.invalidateQueries({ queryKey: ["public-bank"] });
  }

  return (
    <div className="space-y-6">
      <div className="soft-card p-5">
        <h2 className="font-display text-lg font-semibold">Welcome Wagon bank account</h2>
        <p className="text-xs text-muted-foreground">
          Shown to customers at checkout and to applying vendors.
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <Field label="Bank name" value={bankName} onChange={setBankName} />
          <Field label="Account name" value={accountName} onChange={setAccountName} />
          <Field label="Account number" value={accountNumber} onChange={setAccountNumber} />
        </div>
      </div>

      <div className="soft-card p-5">
        <h2 className="font-display text-lg font-semibold">Commission & fees</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Field
            label="Default vendor commission %"
            value={commission}
            onChange={setCommission}
            type="number"
          />
          <Field
            label="Vendor setup fee (NGN)"
            value={setupFee}
            onChange={setSetupFee}
            type="number"
          />
        </div>
      </div>

      <div className="soft-card p-5">
        <h2 className="font-display text-lg font-semibold">Application access</h2>
        <label className="mt-3 flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={vendorEnabled}
            onChange={(e) => setVendorEnabled(e.target.checked)}
          />{" "}
          Vendor applications open
        </label>
        <label className="mt-2 flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={adminEnabled}
            onChange={(e) => setAdminEnabled(e.target.checked)}
          />{" "}
          Admin applications open
        </label>
      </div>

      <div className="soft-card p-5">
        <h2 className="font-display text-lg font-semibold">Site logo</h2>
        <p className="text-xs text-muted-foreground">
          Replaceable wordmark used in headers and emails. Leave empty to use the default brand
          asset.
        </p>
        <div className="mt-3">
          <FileUpload
            bucket="site-assets"
            prefix="logos"
            value={logo}
            onChange={setLogo}
            label="Upload logo"
          />
        </div>
      </div>

      <Button className="rounded-full" onClick={saveAll} disabled={!user}>
        Save all settings
      </Button>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">
        {label}
      </span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary"
      />
    </label>
  );
}
