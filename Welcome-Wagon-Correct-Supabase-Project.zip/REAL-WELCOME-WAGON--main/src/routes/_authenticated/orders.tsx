import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { ngn, statusBadge } from "@/lib/format";
import { ArrowLeft, ShoppingBag } from "lucide-react";
import { StoredImage } from "@/components/stored-image";

export const Route = createFileRoute("/_authenticated/orders")({
  head: () => ({ meta: [{ title: "My orders — Welcome Wagon" }] }),
  component: MyOrders,
});

function MyOrders() {
  const { user } = useAuth();
  const { data: orders } = useQuery({
    queryKey: ["my-orders", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("orders")
        .select("id, order_number, status, total_ngn, created_at, order_items(title, quantity, unit_price_ngn, sold_by_type, product_id, products(primary_image_url, product_code, vendors(store_name)))")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });
  return <OrdersView orders={orders} />;
}

type ItemRow = {
  title: string; quantity: number; unit_price_ngn: number;
  sold_by_type: "vendor" | "welcome_wagon";
  product_id: string;
  products: { primary_image_url: string | null; product_code: string | null; vendors: { store_name: string } | null } | null;
};
type OrderRow = { id: string; order_number: string; status: string; total_ngn: number; created_at: string; order_items: ItemRow[] };

function OrdersView({ orders }: { orders: OrderRow[] | undefined }) {
  return (
    <PageShell>
      <section className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> Dashboard</Link>
        <h1 className="mt-4 font-display text-3xl font-bold">My orders</h1>
        {(!orders || orders.length === 0) ? (
          <div className="soft-card mt-8 p-12 text-center">
            <ShoppingBag className="mx-auto h-10 w-10 text-muted-foreground" />
            <p className="mt-3 text-sm text-muted-foreground">No orders yet.</p>
            <Link to="/shop" className="mt-3 inline-block text-sm font-medium text-primary hover:underline">Start shopping →</Link>
          </div>
        ) : (
          <ul className="mt-6 space-y-3">
            {orders.map((o) => {
              const s = statusBadge(o.status);
              const items = o.order_items ?? [];
              return (
                <li key={o.id} className="soft-card p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="font-mono text-sm font-bold">{o.order_number}</p>
                      <p className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString()} · {items.reduce((n, i) => n + i.quantity, 0)} items</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${s.tone}`}>{s.label}</span>
                      <span className="font-bold text-primary">{ngn(o.total_ngn)}</span>
                    </div>
                  </div>
                  {items.length > 0 && (
                    <ul className="mt-3 space-y-2 border-t border-border pt-3">
                      {items.map((it, idx) => {
                        const seller = it.sold_by_type === "welcome_wagon" ? "Welcome Wagon Kids & More" : it.products?.vendors?.store_name ?? "Vendor";
                        return (
                          <li key={idx} className="flex items-center gap-3">
                            <ItemImage path={it.products?.primary_image_url ?? null} />
                            <div className="min-w-0 flex-1">
                              <p className="line-clamp-1 text-sm font-semibold">{it.title}</p>
                              <p className="text-xs text-muted-foreground">{seller}{it.products?.product_code ? ` · ${it.products.product_code}` : ""}</p>
                            </div>
                            <div className="text-right text-xs">
                              <p className="font-semibold">{it.quantity} × {ngn(it.unit_price_ngn)}</p>
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </PageShell>
  );
}

function ItemImage({ path }: { path: string | null }) {
  return (
    <div className="h-12 w-12 shrink-0 overflow-hidden rounded-lg bg-secondary">
      {path ? <StoredImage bucket="product-media" path={path} alt="" className="h-full w-full object-cover" /> : null}
    </div>
  );
}