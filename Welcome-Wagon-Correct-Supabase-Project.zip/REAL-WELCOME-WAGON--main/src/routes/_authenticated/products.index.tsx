import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Plus, Package, ArrowLeft, Pencil } from "lucide-react";
import { StoredImage } from "@/components/stored-image";
import { ngn, statusBadge } from "@/lib/format";
import { LoadingScreen } from "@/components/loading-screen";

export const Route = createFileRoute("/_authenticated/products/")({
  head: () => ({ meta: [{ title: "My products — Welcome Wagon" }] }),
  component: VendorProducts,
});

function VendorProducts() {
  const { user, primaryRole } = useAuth();
  const { data: vendor } = useQuery({
    queryKey: ["my-vendor", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("vendors").select("*").eq("user_id", user!.id).maybeSingle();
      return data;
    },
  });
  const { data: products, isLoading } = useQuery({
    queryKey: ["my-products", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("products").select("*").eq("created_by", user!.id).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  if (!vendor && primaryRole !== "super_admin" && primaryRole !== "admin") {
    return (
      <PageShell>
        <section className="mx-auto max-w-2xl px-4 py-16 text-center">
          <h1 className="font-display text-2xl font-bold">Vendor account required</h1>
          <p className="mt-2 text-sm text-muted-foreground">Apply to become a vendor first.</p>
          <Link to="/become-vendor" className="mt-3 inline-block text-sm font-medium text-primary hover:underline">Apply →</Link>
        </section>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> Dashboard</Link>
        <div className="mt-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="font-display text-3xl font-bold">My products</h1>
            <p className="text-sm text-muted-foreground">Products you've submitted. Approved items appear in the shop.</p>
          </div>
          <Link to="/products/new"><Button className="rounded-full"><Plus className="mr-1 h-4 w-4" /> New product</Button></Link>
        </div>

        {isLoading ? <LoadingScreen /> : !products || products.length === 0 ? (
          <div className="soft-card mt-10 p-12 text-center">
            <Package className="mx-auto h-10 w-10 text-muted-foreground" />
            <p className="mt-3 text-sm text-muted-foreground">No products yet.</p>
          </div>
        ) : (
          <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {products.map((p) => {
              const s = statusBadge(p.status);
              return (
                <div key={p.id} className="soft-card overflow-hidden">
                  <div className="relative aspect-square bg-secondary">
                    <StoredImage bucket="product-media" path={p.primary_image_url} alt={p.title} className="h-full w-full object-cover" />
                    <span className={`absolute left-2 top-2 rounded-full px-2 py-0.5 text-[10px] font-semibold ${s.tone}`}>{s.label}</span>
                  </div>
                  <div className="p-3">
                    <h3 className="line-clamp-2 text-sm font-semibold">{p.title}</h3>
                    <p className="mt-1 text-xs text-muted-foreground">Stock: {p.stock}</p>
                    <p className="mt-1 text-base font-bold text-primary">{ngn(p.price_ngn)}</p>
                    {p.status === "declined" && p.decline_reason && (
                      <p className="mt-2 rounded-lg bg-destructive/10 p-2 text-xs text-destructive">{p.decline_reason}</p>
                    )}
                    <div className="mt-3 flex">
                      <Link to="/products/$id/edit" params={{ id: p.id }} className="ml-auto">
                        <Button size="sm" variant="outline" className="rounded-full"><Pencil className="mr-1 h-3.5 w-3.5" /> Edit</Button>
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </PageShell>
  );
}