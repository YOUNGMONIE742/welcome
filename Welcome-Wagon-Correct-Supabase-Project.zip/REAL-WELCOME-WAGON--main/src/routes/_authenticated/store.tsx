import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Store } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { FileUpload } from "@/components/file-upload";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { LoadingScreen } from "@/components/loading-screen";

export const Route = createFileRoute("/_authenticated/store")({
  head: () => ({ meta: [{ title: "Store profile — Welcome Wagon Kids & More" }] }),
  component: StoreProfile,
});

type Form = {
  store_name: string;
  description: string;
  contact_phone: string;
  contact_email: string;
  business_address: string;
  business_hours: string;
  return_policy: string;
  exchange_policy: string;
  delivery_policy: string;
  facebook: string;
  instagram: string;
  whatsapp: string;
  tiktok: string;
};

const EMPTY: Form = {
  store_name: "",
  description: "",
  contact_phone: "",
  contact_email: "",
  business_address: "",
  business_hours: "",
  return_policy: "",
  exchange_policy: "",
  delivery_policy: "",
  facebook: "",
  instagram: "",
  whatsapp: "",
  tiktok: "",
};

function StoreProfile() {
  const { user, loading } = useAuth();
  const [form, setForm] = useState<Form>(EMPTY);
  const [logo, setLogo] = useState<string | null>(null);
  const [banner, setBanner] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const {
    data: vendor,
    isLoading,
    refetch,
  } = useQuery({
    queryKey: ["my-store", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vendors")
        .select("*")
        .eq("user_id", user!.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    if (!vendor) return;
    const s = (vendor.social_links ?? {}) as Record<string, string>;
    setForm({
      store_name: vendor.store_name ?? "",
      description: vendor.description ?? "",
      contact_phone: vendor.contact_phone ?? "",
      contact_email: vendor.contact_email ?? "",
      business_address: vendor.business_address ?? "",
      business_hours: vendor.business_hours ?? "",
      return_policy: vendor.return_policy ?? "",
      exchange_policy: vendor.exchange_policy ?? "",
      delivery_policy: vendor.delivery_policy ?? "",
      facebook: s["facebook"] ?? "",
      instagram: s["instagram"] ?? "",
      whatsapp: s["whatsapp"] ?? "",
      tiktok: s["tiktok"] ?? "",
    });
    setLogo(vendor.logo_url);
    setBanner(vendor.banner_url);
  }, [vendor]);

  if (loading || isLoading)
    return (
      <PageShell>
        <LoadingScreen />
      </PageShell>
    );

  if (!vendor) {
    return (
      <PageShell>
        <section className="mx-auto max-w-2xl px-4 py-16 text-center sm:px-6">
          <h1 className="font-display text-2xl font-bold">No store yet</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Apply to become a vendor to open your store.
          </p>
          <Link to="/become-vendor" className="mt-4 inline-block">
            <Button className="rounded-full">Apply as a vendor</Button>
          </Link>
        </section>
      </PageShell>
    );
  }

  const suspended = vendor.status !== "active";

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!vendor) return;
    setBusy(true);
    const { error } = await supabase
      .from("vendors")
      .update({
        store_name: form.store_name.trim(),
        description: form.description || null,
        contact_phone: form.contact_phone || null,
        contact_email: form.contact_email || null,
        business_address: form.business_address || null,
        business_hours: form.business_hours || null,
        return_policy: form.return_policy || null,
        exchange_policy: form.exchange_policy || null,
        delivery_policy: form.delivery_policy || null,
        social_links: {
          facebook: form.facebook,
          instagram: form.instagram,
          whatsapp: form.whatsapp,
          tiktok: form.tiktok,
        },
        logo_url: logo,
        banner_url: banner,
      })
      .eq("id", vendor.id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Store profile updated");
    await refetch();
  }

  const set = (k: keyof Form) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <PageShell>
      <section className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
        <Link
          to="/dashboard"
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"
        >
          <ArrowLeft className="h-4 w-4" /> Dashboard
        </Link>
        <div className="mt-3 flex items-center gap-3">
          <Store className="h-6 w-6 text-primary" />
          <h1 className="font-display text-3xl font-bold">Store profile</h1>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          Status:{" "}
          <span className={suspended ? "text-destructive" : "text-success"}>{vendor.status}</span>
        </p>
        {suspended && (
          <p className="soft-card mt-4 p-4 text-sm text-destructive">
            Your store is {vendor.status}. {vendor.status_reason ?? ""} Editing is disabled until it
            is reactivated.
          </p>
        )}

        <form onSubmit={save} className="soft-card mt-6 space-y-4 p-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <FileUpload
              bucket="store-logos"
              prefix={`${user?.id}/logo`}
              accept="image/*"
              label="Store logo"
              value={logo}
              onChange={setLogo}
            />
            <FileUpload
              bucket="store-logos"
              prefix={`${user?.id}/banner`}
              accept="image/*"
              label="Store banner"
              value={banner}
              onChange={setBanner}
            />
          </div>
          <F label="Store name" value={form.store_name} onChange={set("store_name")} />
          <T label="Store description" value={form.description} onChange={set("description")} />
          <div className="grid gap-4 sm:grid-cols-2">
            <F label="Phone number" value={form.contact_phone} onChange={set("contact_phone")} />
            <F label="Email address" value={form.contact_email} onChange={set("contact_email")} />
          </div>
          <F
            label="Business address"
            value={form.business_address}
            onChange={set("business_address")}
          />
          <F label="Business hours" value={form.business_hours} onChange={set("business_hours")} />
          <T label="Return policy" value={form.return_policy} onChange={set("return_policy")} />
          <T
            label="Exchange policy"
            value={form.exchange_policy}
            onChange={set("exchange_policy")}
          />
          <T
            label="Delivery policy"
            value={form.delivery_policy}
            onChange={set("delivery_policy")}
          />
          <div className="grid gap-4 sm:grid-cols-2">
            <F label="Facebook" value={form.facebook} onChange={set("facebook")} />
            <F label="Instagram" value={form.instagram} onChange={set("instagram")} />
            <F label="WhatsApp" value={form.whatsapp} onChange={set("whatsapp")} />
            <F label="TikTok" value={form.tiktok} onChange={set("tiktok")} />
          </div>
          <Button type="submit" className="rounded-full" disabled={busy || suspended}>
            {busy ? "Saving…" : "Save store profile"}
          </Button>
        </form>
      </section>
    </PageShell>
  );
}

function F({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">
        {label}
      </span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary"
      />
    </label>
  );
}

function T({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">
        {label}
      </span>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={3}
        className="w-full rounded-xl border border-border bg-card p-3 text-sm outline-none focus:border-primary"
      />
    </label>
  );
}
