import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async ({ location }) => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("ww_admin_session");
    }

    const { data: sessionData } = await supabase.auth.getSession();
    let user = sessionData?.session?.user;

    if (!user) {
      const { data, error } = await supabase.auth.getUser();
      if (error || !data.user) {
        throw redirect({ to: "/auth", search: { redirect: location.href } as never });
      }
      user = data.user;
    }
    return { user };
  },
  component: () => <Outlet />,
});
