import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { useAuth } from "@/lib/auth-context";
import { LoadingScreen } from "@/components/loading-screen";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Bell, Megaphone } from "lucide-react";

export const Route = createFileRoute("/_authenticated/notifications")({
  head: () => ({ meta: [{ title: "Notifications — Welcome Wagon Kids & More" }] }),
  component: Notifications,
});

function Notifications() {
  const { loading } = useAuth();
  const { data, isLoading } = useQuery({
    queryKey: ["my-announcements"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("announcements")
        .select("id, title, body, audience, created_at")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data ?? [];
    },
  });

  if (loading) return <PageShell><LoadingScreen /></PageShell>;

  return (
    <PageShell>
      <section className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> Dashboard</Link>
        <div className="mt-3 flex items-center gap-3">
          <Bell className="h-6 w-6 text-primary" />
          <h1 className="font-display text-3xl font-bold">Notifications</h1>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">Announcements from Welcome Wagon, tailored to your account.</p>

        <div className="mt-6 space-y-3">
          {isLoading ? (
            <div className="soft-card p-5 text-sm text-muted-foreground">Loading…</div>
          ) : !data || data.length === 0 ? (
            <div className="soft-card flex flex-col items-center gap-2 p-10 text-center">
              <Megaphone className="h-8 w-8 text-muted-foreground" />
              <p className="font-semibold">You're all caught up</p>
              <p className="text-xs text-muted-foreground">No announcements right now.</p>
            </div>
          ) : (
            data.map((a) => (
              <article key={a.id} className="soft-card p-5">
                <div className="flex items-center justify-between gap-3">
                  <h2 className="font-display text-lg font-semibold">{a.title}</h2>
                  <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-semibold uppercase text-foreground">{a.audience}</span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{new Date(a.created_at).toLocaleString()}</p>
                <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed">{a.body}</p>
              </article>
            ))
          )}
        </div>
      </section>
    </PageShell>
  );
}