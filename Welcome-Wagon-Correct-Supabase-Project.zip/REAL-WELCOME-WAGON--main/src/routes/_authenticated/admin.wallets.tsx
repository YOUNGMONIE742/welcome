import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { StoredImage } from "@/components/stored-image";
import { FileUpload } from "@/components/file-upload";
import { useAuth } from "@/lib/auth-context";
import { ngn } from "@/lib/format";
import { confirmSuperAdminPassword, fetchWallets, num, WITHDRAWAL_TONE, type Wallet } from "@/lib/finance";
import { emailWithdrawalApproved, emailWithdrawalPaymentCompleted, emailWithdrawalRejected } from "@/lib/email/withdrawal-emails";
import { LedgerTable, Field } from "./wallet";
import { Wallet as WalletIcon, Percent, CalendarClock, ShieldCheck, Loader2, X } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/wallets")({
  component: AdminWallets,
});

type Withdrawal = {
  id: string; vendor_id: string; reference: string; amount_ngn: number; paid_ngn: number;
  status: string; note: string | null; decision_reason: string | null; created_at: string;
  withdrawal_payments: Array<{ id: string; amount_ngn: number; proof_url: string | null; created_at: string }>;
};

function AdminWallets() {
  const { primaryRole, isSuperAdminEmail, user } = useAuth();
  const isSuper = primaryRole === "super_admin" && isSuperAdminEmail;
  const qc = useQueryClient();
  const [openVendor, setOpenVendor] = useState<Wallet | null>(null);

  const { data: wallets, isLoading } = useQuery({ queryKey: ["vendor-wallets"], queryFn: fetchWallets });
  const { data: settings, isLoading: settingsLoading } = useQuery({
    queryKey: ["finance-settings"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("finance_settings");
      if (error) throw error;
      const map: Record<string, unknown> = {};
      for (const row of (data ?? []) as Array<{ key: string; value: unknown }>) map[row.key] = row.value;
      return map;
    },
  });
  const { data: withdrawals } = useQuery({
    queryKey: ["all-withdrawals"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("withdrawals")
        .select("id, vendor_id, reference, amount_ngn, paid_ngn, status, note, decision_reason, created_at, withdrawal_payments(id, amount_ngn, proof_url, created_at)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Withdrawal[];
    },
  });
  const { data: banks } = useQuery({
    queryKey: ["all-vendor-banks"],
    queryFn: async () => {
      const { data } = await supabase.from("vendor_bank_accounts").select("*");
      return data ?? [];
    },
  });

  function refresh() {
    qc.invalidateQueries({ queryKey: ["vendor-wallets"] });
    qc.invalidateQueries({ queryKey: ["all-withdrawals"] });
    qc.invalidateQueries({ queryKey: ["finance-settings"] });
  }

  const totals = (wallets ?? []).reduce(
    (a, w) => ({
      gross: a.gross + w.gross_sales, commission: a.commission + w.commission_total,
      earnings: a.earnings + (w.gross_sales - w.commission_total), refunds: a.refunds + w.refunds_total,
      pendingWd: a.pendingWd + w.pending_withdrawals, paid: a.paid + w.paid_out,
    }),
    { gross: 0, commission: 0, earnings: 0, refunds: 0, pendingWd: 0, paid: 0 },
  );

  return (
    <div>
      <div className="flex items-center gap-2">
        <WalletIcon className="h-5 w-5 text-primary" />
        <h2 className="font-display text-xl font-bold">Vendor wallet management</h2>
        {!isSuper && <span className="rounded-full bg-secondary px-2 py-0.5 text-[11px] font-semibold">Read only</span>}
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card label="Gross marketplace sales" value={totals.gross} accent />
        <Card label="Commission earned" value={totals.commission} accent />
        <Card label="Vendor earnings" value={totals.earnings} />
        <Card label="Refunds" value={totals.refunds} />
        <Card label="Pending withdrawals" value={totals.pendingWd} />
        <Card label="Completed payouts" value={totals.paid} />
        <Card label="Net marketplace revenue" value={totals.commission - totals.refunds} accent />
      </div>

      {isSuper && (settingsLoading || !settings ? (
        <div className="mt-8 grid gap-4 lg:grid-cols-3">
          {[0, 1, 2].map((i) => <div key={i} className="soft-card h-40 animate-pulse bg-secondary/40" />)}
        </div>
      ) : (
        <FinanceSettings
          key={JSON.stringify(settings)}
          settings={settings}
          onSaved={refresh}
        />
      ))}

      <h3 className="mt-8 font-display text-lg font-semibold">Withdrawal requests</h3>
      <div className="mt-3 space-y-3">
        {!withdrawals || withdrawals.length === 0 ? (
          <p className="soft-card p-6 text-sm text-muted-foreground">No withdrawal requests yet.</p>
        ) : withdrawals.map((w) => {
          const vendor = wallets?.find((v) => v.vendor_id === w.vendor_id);
          const bank = banks?.find((b) => b.vendor_id === w.vendor_id);
          const tone = WITHDRAWAL_TONE[w.status] ?? { label: w.status, tone: "bg-secondary" };
          return (
            <article key={w.id} className="soft-card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-display text-base font-semibold">{vendor?.store_name ?? "Vendor"}</p>
                  <p className="font-mono text-xs text-muted-foreground">{w.reference} · {new Date(w.created_at).toLocaleString()}</p>
                  {bank && <p className="mt-1 text-xs text-muted-foreground">{bank.bank_name} · {bank.account_name} · <span className="font-mono">{bank.account_number}</span></p>}
                  {w.note && <p className="mt-1 text-xs italic text-muted-foreground">“{w.note}”</p>}
                </div>
                <div className="text-right">
                  <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${tone.tone}`}>{tone.label}</span>
                  <p className="mt-1 font-bold text-primary">{ngn(w.amount_ngn)}</p>
                  <p className="text-xs text-muted-foreground">Paid {ngn(w.paid_ngn)} · Outstanding {ngn(num(w.amount_ngn) - num(w.paid_ngn))}</p>
                </div>
              </div>

              {w.withdrawal_payments?.length > 0 && (
                <ul className="mt-3 flex flex-wrap gap-3 border-t border-border/60 pt-3">
                  {w.withdrawal_payments.map((p) => (
                    <li key={p.id} className="flex items-center gap-2 rounded-xl border border-border/60 p-2 text-xs">
                      <div className="h-14 w-14 overflow-hidden rounded-lg bg-secondary">
                        <StoredImage bucket="payment-proofs" path={p.proof_url ?? undefined} alt="Payment proof" className="h-full w-full object-cover" />
                      </div>
                      <div>
                        <p className="font-semibold">{ngn(p.amount_ngn)}</p>
                        <p className="text-muted-foreground">{new Date(p.created_at).toLocaleString()}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              )}

              {isSuper && <WithdrawalActions w={w} userId={user?.id ?? ""} onDone={refresh} />}
            </article>
          );
        })}
      </div>

      <h3 className="mt-8 font-display text-lg font-semibold">Vendor wallets</h3>
      {isLoading ? (
        <p className="soft-card mt-3 p-6 text-sm text-muted-foreground">Loading wallets…</p>
      ) : (
        <div className="soft-card mt-3 overflow-x-auto">
          <table className="w-full min-w-[900px] text-left text-sm">
            <thead className="bg-secondary/60 text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="p-3">Vendor</th><th className="p-3 text-right">Commission</th>
                <th className="p-3 text-right">Pending</th><th className="p-3 text-right">Available</th>
                <th className="p-3 text-right">Wallet</th><th className="p-3 text-right">Paid out</th>
                <th className="p-3 text-right">Open requests</th><th className="p-3" />
              </tr>
            </thead>
            <tbody>
              {(wallets ?? []).map((w) => (
                <tr key={w.vendor_id} className="border-t border-border/60">
                  <td className="p-3 font-semibold">{w.store_name}{!w.is_active && <span className="ml-2 rounded-full bg-rose-100 px-2 py-0.5 text-[10px] text-rose-800">inactive</span>}</td>
                  <td className="p-3 text-right">{w.commission_percent}%</td>
                  <td className="p-3 text-right">{ngn(w.pending_balance)}</td>
                  <td className="p-3 text-right">{ngn(w.available_balance)}</td>
                  <td className="p-3 text-right font-semibold">{ngn(w.wallet_balance)}</td>
                  <td className="p-3 text-right">{ngn(w.paid_out)}</td>
                  <td className="p-3 text-right">{ngn(w.pending_withdrawals)}</td>
                  <td className="p-3 text-right"><Button size="sm" variant="outline" className="rounded-full" onClick={() => setOpenVendor(w)}>Open</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {openVendor && (
        <VendorDetail wallet={openVendor} isSuper={isSuper} onClose={() => setOpenVendor(null)} onSaved={refresh} />
      )}
    </div>
  );
}

function Card({ label, value, accent }: { label: string; value: number; accent?: boolean }) {
  return (
    <div className="soft-card p-5">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className={`mt-1 font-display text-xl font-bold ${accent ? "text-primary" : ""}`}>{ngn(value)}</p>
    </div>
  );
}

function FinanceSettings({ settings, onSaved }: { settings: Record<string, unknown>; onSaved: () => void }) {
  const [commission, setCommission] = useState(String(settings["default_commission_percent"] ?? 10));
  const [hold, setHold] = useState(String(settings["refund_protection_days"] ?? 7));
  const sched = (settings["payout_schedule"] ?? { mode: "always" }) as Record<string, unknown>;
  const [mode, setMode] = useState(String(sched.mode ?? "always"));
  const [day1, setDay1] = useState(String(sched.day1 ?? 15));
  const [day2, setDay2] = useState(String(sched.day2 ?? 28));
  const [weekday, setWeekday] = useState(String(sched.weekday ?? 5));
  const [busy, setBusy] = useState(false);

  async function save(key: string, value: unknown) {
    setBusy(true);
    const { error } = await supabase.rpc("set_finance_setting", { p_key: key, p_value: value as never });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Saved");
    onSaved();
  }

  return (
    <div className="mt-8 grid gap-4 lg:grid-cols-3">
      <div className="soft-card p-5">
        <div className="flex items-center gap-2"><Percent className="h-4 w-4 text-primary" /><h3 className="font-display text-base font-semibold">Global commission</h3></div>
        <p className="mt-1 text-xs text-muted-foreground">Applied to every vendor without a specific rate.</p>
        <div className="mt-3 flex items-end gap-2">
          <Field label="Percent (%)" value={commission} onChange={(v) => setCommission(v.replace(/[^\d.]/g, ""))} />
          <Button className="rounded-full" disabled={busy} onClick={() => save("default_commission_percent", Number(commission))}>Save</Button>
        </div>
      </div>

      <div className="soft-card p-5">
        <div className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-primary" /><h3 className="font-display text-base font-semibold">Refund protection period</h3></div>
        <p className="mt-1 text-xs text-muted-foreground">Earnings stay in Pending balance for this long.</p>
        <div className="mt-3 flex items-end gap-2">
          <label className="block flex-1">
            <span className="text-xs font-semibold text-muted-foreground">Period</span>
            <select value={hold} onChange={(e) => setHold(e.target.value)} className="mt-1 h-10 w-full rounded-xl border border-border bg-card px-3 text-sm">
              {["0", "3", "7", "14", "30"].map((d) => <option key={d} value={d}>{d === "0" ? "Disabled (instant)" : `${d} days`}</option>)}
              {!["0", "3", "7", "14", "30"].includes(hold) && <option value={hold}>{hold} days (custom)</option>}
            </select>
          </label>
          <Button className="rounded-full" disabled={busy} onClick={() => save("refund_protection_days", Number(hold))}>Save</Button>
        </div>
        <Field label="Custom days" value={hold} onChange={(v) => setHold(v.replace(/\D/g, ""))} />
      </div>

      <div className="soft-card p-5">
        <div className="flex items-center gap-2"><CalendarClock className="h-4 w-4 text-primary" /><h3 className="font-display text-base font-semibold">Vendor payout schedule</h3></div>
        <p className="mt-1 text-xs text-muted-foreground">Requests outside the window are rejected automatically.</p>
        <label className="mt-3 block">
          <span className="text-xs font-semibold text-muted-foreground">Schedule</span>
          <select value={mode} onChange={(e) => setMode(e.target.value)} className="mt-1 h-10 w-full rounded-xl border border-border bg-card px-3 text-sm">
            <option value="always">Any time</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="twice_monthly">Twice monthly</option>
            <option value="custom">Custom days of month</option>
          </select>
        </label>
        {mode === "weekly" && <Field label="Weekday (1=Mon … 7=Sun)" value={weekday} onChange={(v) => setWeekday(v.replace(/\D/g, ""))} />}
        {(mode === "monthly" || mode === "twice_monthly" || mode === "custom") && <Field label="Day of month" value={day1} onChange={(v) => setDay1(v.replace(/\D/g, ""))} />}
        {mode === "twice_monthly" && <Field label="Second day of month" value={day2} onChange={(v) => setDay2(v.replace(/\D/g, ""))} />}
        <Button className="mt-3 rounded-full" disabled={busy} onClick={() => save("payout_schedule", {
          mode,
          weekday: Number(weekday) || 5,
          day1: Number(day1) || 15,
          day2: Number(day2) || 28,
          days: mode === "custom" ? [Number(day1) || 15] : [],
        })}>Save schedule</Button>
      </div>
    </div>
  );
}

function WithdrawalActions({ w, userId, onDone }: { w: Withdrawal; userId: string; onDone: () => void }) {
  const [reason, setReason] = useState("");
  const [amount, setAmount] = useState(String(num(w.amount_ngn) - num(w.paid_ngn)));
  const [proof, setProof] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  async function guarded(
    run: () => PromiseLike<{ error: { message: string } | null }>,
    successMsg: string,
    afterSuccess?: () => Promise<unknown>,
  ) {
    if (!password) return toast.error("Enter your super admin password to confirm.");
    setBusy(true);
    const ok = await confirmSuperAdminPassword(password);
    if (!ok) { setBusy(false); return toast.error("Password confirmation failed."); }
    const { error } = await run();
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(successMsg);
    if (afterSuccess) await afterSuccess();
    setPassword(""); setProof(null);
    onDone();
  }

  const canReview = w.status === "pending";
  const canPay = w.status === "approved" || w.status === "partially_paid";
  if (!canReview && !canPay) return null;

  return (
    <div className="mt-4 space-y-3 border-t border-border/60 pt-3">
      <Field label="Super admin password (required)" value={password} onChange={setPassword} type="password" />
      {canReview && (
        <div className="flex flex-wrap items-end gap-2">
          <div className="flex-1 min-w-[200px]"><Field label="Decision note / rejection reason" value={reason} onChange={setReason} /></div>
          <Button className="rounded-full" disabled={busy} onClick={() => guarded(
            () => supabase.rpc("review_withdrawal", { p_id: w.id, p_approve: true, p_reason: reason || undefined }),
            "Withdrawal approved",
            () => emailWithdrawalApproved({
              vendorId: w.vendor_id, withdrawalId: w.id, reference: w.reference,
              amountNgn: num(w.amount_ngn), note: reason || undefined,
            }))}>
            {busy && <Loader2 className="mr-1 h-4 w-4 animate-spin" />}Approve
          </Button>
          <Button variant="outline" className="rounded-full" disabled={busy} onClick={() => guarded(
            () => supabase.rpc("review_withdrawal", { p_id: w.id, p_approve: false, p_reason: reason || undefined }),
            "Withdrawal rejected",
            () => emailWithdrawalRejected({
              vendorId: w.vendor_id, withdrawalId: w.id, reference: w.reference,
              amountNgn: num(w.amount_ngn), reason: reason || undefined,
            }))}>
            Reject
          </Button>
        </div>
      )}
      {canPay && (
        <div className="flex flex-wrap items-end gap-3">
          <div className="w-40"><Field label="Payment amount (NGN)" value={amount} onChange={(v) => setAmount(v.replace(/[^\d.]/g, ""))} /></div>
          <FileUpload bucket="payment-proofs" prefix={`${userId}/payouts`} accept="image/*" label="Upload payment proof" value={proof} onChange={setProof} />
          <Button className="rounded-full" disabled={busy || !proof} onClick={() => guarded(
            () => supabase.rpc("record_withdrawal_payment", { p_id: w.id, p_amount: Number(amount), p_proof_url: proof! }),
            "Payment recorded",
            () => emailWithdrawalPaymentCompleted({
              vendorId: w.vendor_id, withdrawalId: w.id, reference: w.reference,
              paidNgn: Number(amount), totalNgn: num(w.amount_ngn), alreadyPaidNgn: num(w.paid_ngn),
            }))}>
            {busy && <Loader2 className="mr-1 h-4 w-4 animate-spin" />}Confirm payment
          </Button>
        </div>
      )}
    </div>
  );
}

function VendorDetail({ wallet, isSuper, onClose, onSaved }: { wallet: Wallet; isSuper: boolean; onClose: () => void; onSaved: () => void }) {
  const [pct, setPct] = useState(String(wallet.commission_percent));
  const [busy, setBusy] = useState(false);

  const { data: ledger } = useQuery({
    queryKey: ["admin-vendor-ledger", wallet.vendor_id],
    queryFn: async () => {
      const { data } = await supabase.from("vendor_ledger").select("*").eq("vendor_id", wallet.vendor_id).order("created_at", { ascending: true }).limit(300);
      return data ?? [];
    },
  });
  const { data: audit } = useQuery({
    queryKey: ["admin-vendor-audit", wallet.vendor_id],
    queryFn: async () => {
      const { data } = await supabase.from("financial_audit_log").select("*").eq("vendor_id", wallet.vendor_id).order("created_at", { ascending: false }).limit(100);
      return data ?? [];
    },
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/50 p-4" onClick={onClose}>
      <div className="mx-auto max-w-4xl rounded-2xl bg-card p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-display text-2xl font-bold">{wallet.store_name}</h3>
            <p className="text-xs text-muted-foreground">Commission {wallet.commission_percent}%</p>
          </div>
          <button onClick={onClose} aria-label="Close"><X className="h-5 w-5" /></button>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <Card label="Gross sales" value={wallet.gross_sales} />
          <Card label="Commission" value={wallet.commission_total} />
          <Card label="Refunds" value={wallet.refunds_total} />
          <Card label="Pending balance" value={wallet.pending_balance} />
          <Card label="Available balance" value={wallet.available_balance} />
          <Card label="Paid out" value={wallet.paid_out} />
        </div>

        {isSuper && (
          <div className="mt-5 flex items-end gap-2 rounded-xl border border-border/60 p-4">
            <div className="flex-1"><Field label="Vendor-specific commission (%) — overrides global" value={pct} onChange={(v) => setPct(v.replace(/[^\d.]/g, ""))} /></div>
            <Button className="rounded-full" disabled={busy} onClick={async () => {
              setBusy(true);
              const { error } = await supabase.rpc("set_vendor_commission", { p_vendor: wallet.vendor_id, p_percent: Number(pct) });
              setBusy(false);
              if (error) return toast.error(error.message);
              toast.success("Commission updated"); onSaved();
            }}>Save</Button>
            <Button variant="outline" className="rounded-full" disabled={busy} onClick={async () => {
              setBusy(true);
              const { error } = await supabase.rpc("set_vendor_commission", { p_vendor: wallet.vendor_id, p_percent: null as never });
              setBusy(false);
              if (error) return toast.error(error.message);
              toast.success("Reset to global commission"); onSaved();
            }}>Use global</Button>
          </div>
        )}

        <h4 className="mt-6 font-display text-lg font-semibold">Transaction ledger</h4>
        <LedgerTable rows={(ledger ?? []) as Array<Record<string, unknown>>} />

        <h4 className="mt-6 font-display text-lg font-semibold">Audit log</h4>
        <ul className="mt-2 space-y-2">
          {(audit ?? []).length === 0 ? <li className="text-sm text-muted-foreground">No financial actions logged yet.</li> :
            (audit ?? []).map((a) => (
              <li key={a.id} className="rounded-lg border border-border/60 p-3 text-xs">
                <span className="font-semibold">{a.action}</span> · {a.actor_role ?? "system"} · {new Date(a.created_at).toLocaleString()}
                <div className="text-muted-foreground">{JSON.stringify(a.previous_value)} → {JSON.stringify(a.new_value)}</div>
              </li>
            ))}
        </ul>
      </div>
    </div>
  );
}
