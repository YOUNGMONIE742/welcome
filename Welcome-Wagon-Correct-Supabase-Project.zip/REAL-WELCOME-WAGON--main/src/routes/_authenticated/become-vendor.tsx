import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";
import { LoadingScreen } from "@/components/loading-screen";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Store, ShieldCheck, ArrowLeft, Sparkles } from "lucide-react";
import { useState } from "react";
import { FileUpload } from "@/components/file-upload";
import { toast } from "sonner";
import { ngn } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/become-vendor")({
  head: () => ({ meta: [{ title: "Become a vendor — Welcome Wagon Kids & More" }] }),
  component: BecomeVendor,
});

function BecomeVendor() {
  const { user, loading } = useAuth();
  const qc = useQueryClient();
  const [storeName, setStoreName] = useState("");
  const [storeDesc, setStoreDesc] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [logoPath, setLogoPath] = useState<string | null>(null);
  const [proofPath, setProofPath] = useState<string | null>(null);
  const [txId, setTxId] = useState("");
  const [amount, setAmount] = useState<string>("");
  const [busy, setBusy] = useState(false);

  const { data: app, refetch } = useQuery({
    queryKey: ["my-vendor-app", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("vendor_applications")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      return data;
    },
  });
  const { data: settings } = useQuery({
    queryKey: ["public-settings"],
    queryFn: async () => {
      const { data } = await supabase
        .from("settings")
        .select("key, value")
        .in("key", ["bank_details", "vendor_applications_enabled"]);
      return Object.fromEntries((data ?? []).map((s) => [s.key, s.value]));
    },
  });

  if (loading) return <PageShell><LoadingScreen /></PageShell>;

  const enabled = settings?.vendor_applications_enabled !== false;
  const bank = (settings?.bank_details ?? {}) as { bank_name?: string; account_name?: string; account_number?: string };
  const setupFee = (settings?.vendor_setup_fee_ngn as number | undefined) ?? null;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    if (!proofPath) return toast.error("Upload your payment proof first.");
    setBusy(true);
    const { error } = await supabase.from("vendor_applications").insert({
      user_id: user.id,
      store_name: storeName,
      store_description: storeDesc || null,
      store_logo_url: logoPath,
      contact_phone: phone || null,
      contact_email: email || null,
      payment_proof_url: proofPath,
      payment_transaction_id: txId || null,
      payment_amount: amount ? Number(amount) : null,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Application submitted! Super admin will review shortly.");
    qc.invalidateQueries({ queryKey: ["my-vendor-app"] });
    refetch();
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> Back to dashboard</Link>
        <span className="chip mt-4"><Sparkles className="h-3 w-3" /> Vendor program</span>
        <h1 className="mt-3 font-display text-3xl font-bold md:text-4xl">Become a Welcome Wagon vendor</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Reach families across Nigeria. After applying, our super admin reviews your details and confirms your setup payment before unlocking your vendor dashboard.
        </p>

        {!enabled && (
          <div className="soft-card mt-6 border-destructive/30 bg-destructive/5 p-5 text-sm text-destructive">
            Vendor applications are temporarily closed. Please check back later.
          </div>
        )}

        {app && app.status !== "declined" ? (
          <div className="soft-card mt-8 p-6">
            <h2 className="font-display text-xl font-semibold">Your application</h2>
            <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
              <div><dt className="text-xs text-muted-foreground">Store</dt><dd className="font-semibold">{app.store_name}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Status</dt><dd className="font-semibold capitalize text-primary">{app.status}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Submitted</dt><dd>{new Date(app.created_at).toLocaleString()}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Payment verified</dt><dd>{app.payment_verified ? "Yes" : "Awaiting"}</dd></div>
            </dl>
          </div>
        ) : enabled ? (
          <form onSubmit={submit} className="soft-card mt-8 space-y-4 p-6">
            <div className="flex items-center gap-3">
              <Store className="h-6 w-6 text-primary" />
              <h2 className="font-display text-xl font-semibold">Application form</h2>
            </div>
            {app?.status === "declined" && (
              <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
                Previous application declined: {app.decline_reason ?? "No reason provided"}. Please correct and resubmit.
              </div>
            )}
            <Input label="Store name *" value={storeName} onChange={setStoreName} required />
            <Textarea label="Store description" value={storeDesc} onChange={setStoreDesc} rows={3} />
            <div className="grid gap-3 sm:grid-cols-2">
              <Input label="Contact phone" value={phone} onChange={setPhone} />
              <Input label="Contact email" value={email} onChange={setEmail} type="email" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Store logo</label>
              <FileUpload bucket="store-logos" prefix={user?.id ?? "anon"} value={logoPath} onChange={setLogoPath} label="Upload logo" />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Input label="Payment transaction ID" value={txId} onChange={setTxId} />
              <Input label={`Amount paid${setupFee ? ` (${ngn(setupFee)})` : ""}`} value={amount} onChange={setAmount} type="number" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">Payment proof *</label>
              <FileUpload bucket="payment-proofs" prefix={user?.id ?? "anon"} accept="image/*,application/pdf" value={proofPath} onChange={setProofPath} label="Upload proof" />
            </div>
            <Button type="submit" disabled={busy} className="rounded-full">{busy ? "Submitting…" : "Submit application"}</Button>
          </form>
        ) : null}

        <div className="soft-card mt-6 p-6">
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-6 w-6 text-primary" />
            <h2 className="font-display text-xl font-semibold">Welcome Wagon bank account</h2>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">
            Make your one-time setup payment to this account, then upload your proof in the application form.
          </p>
          {bank.account_number ? (
            <dl className="mt-4 grid gap-2 text-sm sm:grid-cols-3">
              <div><dt className="text-xs text-muted-foreground">Bank</dt><dd className="font-semibold">{bank.bank_name}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Account name</dt><dd className="font-semibold">{bank.account_name}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Account number</dt><dd className="font-mono font-semibold">{bank.account_number}</dd></div>
            </dl>
          ) : (
            <div className="mt-4 rounded-xl border border-dashed border-border bg-muted/40 p-4 text-sm text-muted-foreground">
              Bank details haven't been set yet. The super admin can configure them from <em>Super Admin → Bank & commission settings</em>.
            </div>
          )}
        </div>
      </section>
    </PageShell>
  );
}

function Input({ label, value, onChange, type = "text", required }: { label: string; value: string; onChange: (v: string) => void; type?: string; required?: boolean }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">{label}</span>
      <input value={value} type={type} required={required} onChange={(e) => onChange(e.target.value)} className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary" />
    </label>
  );
}
function Textarea({ label, value, onChange, rows = 3 }: { label: string; value: string; onChange: (v: string) => void; rows?: number }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">{label}</span>
      <textarea value={value} rows={rows} onChange={(e) => onChange(e.target.value)} className="w-full rounded-xl border border-border bg-card p-3 text-sm outline-none focus:border-primary" />
    </label>
  );
}