import { createFileRoute, Link } from "@tanstack/react-router";
import { useAuth, type AppRole } from "@/lib/auth-context";
import { PageShell } from "@/components/page-shell";
import { LoadingScreen } from "@/components/loading-screen";
import { AccessDenied } from "@/components/access-denied";
import { Button } from "@/components/ui/button";
import {
  Crown,
  ShieldCheck,
  Store,
  ShoppingBag,
  Bell,
  LogOut,
  ChevronRight,
  Package,
  Users,
  BarChart3,
  Settings as SettingsIcon,
  Lock,
  BadgeCheck,
  Loader2,
  Tag,
  Wallet,
} from "lucide-react";
import { fetchWallets } from "@/lib/finance";
import { ngn } from "@/lib/format";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Welcome Wagon Kids & More" }] }),
  component: DashboardRouter,
});

function DashboardRouter() {
  const { loading, primaryRole, profile, user, signOut, roles, isSuperAdminEmail, refresh } =
    useAuth();

  // Re-read roles on every dashboard visit so newly granted access
  // (e.g. a just-approved vendor) takes effect without signing out.
  useEffect(() => {
    void refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  if (loading)
    return (
      <PageShell>
        <LoadingScreen />
      </PageShell>
    );

  const role: AppRole = isSuperAdminEmail ? "super_admin" : (primaryRole ?? "customer");

  return (
    <PageShell>
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs uppercase tracking-wider text-muted-foreground">
              {labelFor(role)} dashboard
            </p>
            <h1 className="mt-1 font-display text-3xl font-bold md:text-4xl">
              Hello, {profile?.full_name ?? profile?.username ?? user?.email}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Signed in as <span className="font-mono">{user?.email}</span>
              {roles.length > 1 && <> · roles: {roles.join(", ")}</>}
            </p>
          </div>
          <Button variant="outline" onClick={signOut} className="rounded-full">
            <LogOut className="mr-1 h-4 w-4" /> Sign out
          </Button>
        </div>

        <div className="mt-8">
          {role === "super_admin" ? (
            <SuperAdminPanel />
          ) : role === "admin" ? (
            <AdminPanel />
          ) : role === "vendor" ? (
            <VendorPanel />
          ) : (
            <CustomerPanel />
          )}
        </div>
      </section>
    </PageShell>
  );
}

function labelFor(role: AppRole) {
  return (
    { customer: "Customer", vendor: "Vendor", admin: "Admin", super_admin: "Super Admin" } as const
  )[role];
}

function Tile({
  icon: Icon,
  title,
  desc,
  to,
  soon,
}: {
  icon: typeof Crown;
  title: string;
  desc: string;
  to?: string;
  soon?: boolean;
}) {
  const inner = (
    <div className="soft-card group flex items-start gap-3 p-5 transition hover:-translate-y-0.5">
      <div className="grid h-11 w-11 place-items-center rounded-2xl bg-secondary text-primary">
        <Icon className="h-5 w-5" />
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2">
          <h3 className="font-display text-base font-semibold">{title}</h3>
          {soon && (
            <span className="rounded-full bg-accent px-2 py-0.5 text-[10px] font-semibold uppercase text-accent-foreground">
              Phase 2
            </span>
          )}
        </div>
        <p className="mt-1 text-xs text-muted-foreground">{desc}</p>
      </div>
      <ChevronRight className="h-4 w-4 text-muted-foreground transition group-hover:translate-x-0.5 group-hover:text-primary" />
    </div>
  );
  return to ? <Link to={to}>{inner}</Link> : inner;
}

/* ============ CUSTOMER ============ */
function CustomerPanel() {
  const { data: app } = useQuery({
    queryKey: ["my-vendor-app"],
    queryFn: async () => {
      const { data } = await supabase
        .from("vendor_applications")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      return data;
    },
  });
  return (
    <>
      {app && (
        <div className="soft-card mb-6 flex items-center gap-4 p-5">
          <Loader2 className="h-5 w-5 text-primary" />
          <div className="flex-1">
            <p className="text-sm font-semibold">
              Vendor application:{" "}
              <span className="capitalize text-primary">{app.status.replace("_", " ")}</span>
            </p>
            <p className="text-xs text-muted-foreground">
              {app.store_name} · submitted {new Date(app.created_at).toLocaleDateString()}
            </p>
          </div>
          <Link to="/become-vendor">
            <Button variant="outline" size="sm" className="rounded-full">
              View
            </Button>
          </Link>
        </div>
      )}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Tile
          icon={ShoppingBag}
          title="My orders"
          desc="Track delivery, view history."
          to="/orders"
        />
        <Tile
          icon={Store}
          title="Become a vendor"
          desc="Open your store on Welcome Wagon."
          to="/become-vendor"
        />
        <Tile
          icon={ShieldCheck}
          title="Apply for admin"
          desc="Help moderate the marketplace."
          to="/become-admin"
        />
        <Tile
          icon={Bell}
          title="Notifications"
          desc="Announcements from Welcome Wagon."
          to="/notifications"
        />
        <Tile
          icon={SettingsIcon}
          title="Account settings"
          desc="Update your name, phone and username."
          to="/settings"
        />
      </div>
    </>
  );
}

/* ============ VENDOR ============ */
function VendorPanel() {
  const { user } = useAuth();
  const { data: vendor, isLoading } = useQuery({
    queryKey: ["my-vendor", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data } = await supabase
        .from("vendors")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();
      return data;
    },
  });
  const { data: sales } = useQuery({
    queryKey: ["my-vendor-sales", vendor?.id],
    enabled: !!vendor?.id,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_vendor_sales_report");
      if (error) throw error;
      const rows = data ?? [];
      const unitsSold = rows.reduce((sum, row) => sum + Number(row.units_sold ?? 0), 0);
      const revenue = rows.reduce((sum, row) => sum + Number(row.sales_amount_ngn ?? 0), 0);
      const top = rows
        .map((row) => ({ title: row.product_title, qty: Number(row.units_sold ?? 0), revenue: Number(row.sales_amount_ngn ?? 0) }))
        .sort((a, b) => b.qty - a.qty)
        .slice(0, 5);
      return { unitsSold, revenue, top, orderLines: rows.length };
    },
  });
  const { data: wallets } = useQuery({
    queryKey: ["vendor-wallets"],
    queryFn: fetchWallets,
    enabled: !!vendor?.id,
  });
  const wallet = wallets?.find((w) => w.vendor_id === vendor?.id);

  if (isLoading) return <LoadingScreen />;

  if (!vendor) {
    return (
      <div className="soft-card mx-auto max-w-xl p-8 text-center">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-muted text-muted-foreground">
          <Lock className="h-6 w-6" />
        </div>
        <h2 className="mt-4 font-display text-2xl font-bold">Vendor dashboard locked</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Your store will unlock here once super admin approves your vendor application and verifies
          your setup payment.
        </p>
        <div className="mt-5">
          <Link to="/become-vendor">
            <Button className="rounded-full">View application</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="soft-card mb-6 flex items-center gap-4 p-5">
        <BadgeCheck className="h-6 w-6 text-success" />
        <div className="flex-1">
          <p className="font-display text-lg font-semibold">{vendor.store_name}</p>
          <p className="text-xs text-muted-foreground">
            Joined {new Date(vendor.joined_at).toLocaleDateString()} · ⭐{" "}
            {Number(vendor.rating).toFixed(1)} · {vendor.total_sold} sold
          </p>
        </div>
      </div>
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <div className="soft-card p-5">
          <p className="text-xs uppercase text-muted-foreground">Units sold</p>
          <p className="mt-1 font-display text-2xl font-bold">{sales?.unitsSold ?? 0}</p>
        </div>
        <div className="soft-card p-5">
          <p className="text-xs uppercase text-muted-foreground">Products with sales</p>
          <p className="mt-1 font-display text-2xl font-bold">{sales?.orderLines ?? 0}</p>
        </div>
        <div className="soft-card p-5">
          <p className="text-xs uppercase text-muted-foreground">Revenue</p>
          <p className="mt-1 font-display text-2xl font-bold">
            ₦{Number(sales?.revenue ?? 0).toLocaleString("en-NG")}
          </p>
        </div>
      </div>
      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="soft-card p-5">
          <p className="text-xs uppercase text-muted-foreground">Wallet balance</p>
          <p className="mt-1 font-display text-2xl font-bold text-primary">
            {ngn(wallet?.wallet_balance ?? 0)}
          </p>
        </div>
        <div className="soft-card p-5">
          <p className="text-xs uppercase text-muted-foreground">Available to withdraw</p>
          <p className="mt-1 font-display text-2xl font-bold">
            {ngn(wallet?.available_balance ?? 0)}
          </p>
        </div>
        <div className="soft-card p-5">
          <p className="text-xs uppercase text-muted-foreground">Pending balance</p>
          <p className="mt-1 font-display text-2xl font-bold">
            {ngn(wallet?.pending_balance ?? 0)}
          </p>
        </div>
        <div className="soft-card p-5">
          <p className="text-xs uppercase text-muted-foreground">
            Commission ({wallet?.commission_percent ?? 0}%)
          </p>
          <p className="mt-1 font-display text-2xl font-bold">
            {ngn(wallet?.commission_total ?? 0)}
          </p>
        </div>
      </div>
      {sales && sales.top.length > 0 && (
        <div className="soft-card mb-6 p-5">
          <h3 className="font-display text-base font-semibold">Top selling products</h3>
          <ul className="mt-3 divide-y divide-border">
            {sales.top.map((t) => (
              <li key={t.title} className="flex items-center justify-between py-2 text-sm">
                <span className="truncate pr-3">{t.title}</span>
                <span className="text-xs text-muted-foreground">
                  {t.qty} sold · ₦{t.revenue.toLocaleString("en-NG")}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Tile
          icon={Package}
          title="My products"
          desc="Add, edit, submit for review."
          to="/products"
        />
        <Tile
          icon={Wallet}
          title="My wallet"
          desc="Earnings, payouts and withdrawal requests."
          to="/wallet"
        />
        <Tile
          icon={Package}
          title="Store profile"
          desc="Logo, banner, contact details and policies."
          to="/store"
        />
        <Tile
          icon={Package}
          title="Add product"
          desc="List a new product for review."
          to="/products/new"
        />
        <Tile icon={Bell} title="Notifications" desc="Vendor announcements." to="/notifications" />
        <Tile
          icon={SettingsIcon}
          title="Account settings"
          desc="Update your name, phone and username."
          to="/settings"
        />
      </div>
    </>
  );
}

/* ============ ADMIN ============ */
function AdminPanel() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <Tile
        icon={Package}
        title="Product moderation"
        desc="Review pending product submissions."
        to="/admin/products"
      />
      <Tile
        icon={Wallet}
        title="Wallets & payouts"
        desc="View vendor balances and payout history."
        to="/admin/wallets"
      />
      <Tile
        icon={Package}
        title="Add product"
        desc="Publish a product directly."
        to="/products/new"
      />
      <Tile
        icon={Store}
        title="Vendor applications"
        desc="Approve or decline applications."
        to="/admin/vendor-applications"
      />
      <Tile
        icon={Bell}
        title="Notifications"
        desc="Read admin-only announcements."
        to="/notifications"
      />
      <Tile
        icon={SettingsIcon}
        title="Account settings"
        desc="Update your name, phone and username."
        to="/settings"
      />
    </div>
  );
}

/* ============ SUPER ADMIN ============ */
function SuperAdminPanel() {
  return (
    <>
      <div className="soft-card mb-6 flex items-center gap-3 p-5">
        <Crown className="h-6 w-6 text-primary" />
        <div>
          <p className="font-display text-lg font-semibold">Super Admin access</p>
          <p className="text-xs text-muted-foreground">
            Authorized administrator console and management portal.
          </p>
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Tile
          icon={Store}
          title="Vendor applications"
          desc="Approve, decline & verify setup payments."
          to="/admin/vendor-applications"
        />
        <Tile
          icon={ShieldCheck}
          title="Admin applications"
          desc="Approve or decline admin requests."
          to="/admin/admin-applications"
        />
        <Tile
          icon={Package}
          title="Product moderation"
          desc="Approve, decline or unpublish products."
          to="/admin/products"
        />
        <Tile
          icon={Tag}
          title="Categories"
          desc="Add, rename or remove marketplace categories."
          to="/admin/categories"
        />
        <Tile
          icon={Users}
          title="Users & roles"
          desc="Suspend, terminate or grant roles to admins & vendors."
          to="/admin/users"
        />
        <Tile
          icon={Package}
          title="Add product"
          desc="Publish products directly as Welcome Wagon."
          to="/products/new"
        />
        <Tile
          icon={Crown}
          title="Payments & orders"
          desc="Verify payment proofs, update order status."
          to="/admin/payments"
        />
        <Tile
          icon={Wallet}
          title="Wallets & payouts"
          desc="Vendor balances, commission, withdrawals & proofs."
          to="/admin/wallets"
        />
        <Tile
          icon={SettingsIcon}
          title="Bank & commission settings"
          desc="Bank account, commission, application toggles, site logo."
          to="/admin/settings"
        />
        <Tile
          icon={BarChart3}
          title="Analytics"
          desc="Marketplace KPIs across users, vendors & orders."
          to="/admin/analytics"
        />
        <Tile
          icon={Bell}
          title="Announcements"
          desc="Broadcast to customers, vendors or admins."
          to="/admin/announcements"
        />
        <Tile
          icon={Bell}
          title="Feedback inbox"
          desc="Read messages sent through the contact form."
          to="/admin/feedback"
        />
        <Tile
          icon={SettingsIcon}
          title="Account settings"
          desc="Update your name, phone and username."
          to="/settings"
        />
      </div>
    </>
  );
}
