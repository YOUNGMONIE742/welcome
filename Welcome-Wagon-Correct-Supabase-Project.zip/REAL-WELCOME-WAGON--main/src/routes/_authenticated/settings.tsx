import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Eye, EyeOff, LogOut } from "lucide-react";
import { requestPushPermission } from "@/lib/push";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Account settings — Welcome Wagon" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user, profile, refresh, signOut } = useAuth();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [phone, setPhone] = useState("");
  const [busy, setBusy] = useState(false);
  const [pwd, setPwd] = useState("");
  const [pwd2, setPwd2] = useState("");

  useEffect(() => {
    if (!profile) return;
    setFullName(profile.full_name ?? "");
    setUsername(profile.username ?? "");
    setPhone(profile.phone ?? "");
  }, [profile]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setBusy(true);
    const { error } = await supabase
      .from("profiles")
      .update({ full_name: fullName || null, username: username || null, phone: phone || null })
      .eq("id", user.id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Profile updated");
    await refresh();
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    if (pwd.length < 8) return toast.error("Password must be at least 8 characters.");
    if (pwd !== pwd2) return toast.error("Passwords do not match.");
    setBusy(true);

    try {
      // Ensure we have an active, valid Supabase session
      const { data: sessionData, error: sessionErr } = await supabase.auth.getSession();
      if (sessionErr || !sessionData?.session) {
        const { data: refreshed, error: refreshErr } = await supabase.auth.refreshSession();
        if (refreshErr || !refreshed?.session) {
          setBusy(false);
          toast.error("Authentication session missing or expired", {
            description:
              "Please sign in again to verify your identity before changing your password.",
          });
          return;
        }
      }

      const { error } = await supabase.auth.updateUser({ password: pwd });
      setBusy(false);
      if (error) return toast.error(error.message);
      setPwd("");
      setPwd2("");
      toast.success("Password updated successfully!");
    } catch (err) {
      setBusy(false);
      const msg = err instanceof Error ? err.message : String(err);
      toast.error("Failed to update password", { description: msg });
    }
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-2xl px-4 py-10 sm:px-6">
        <Link
          to="/dashboard"
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"
        >
          <ArrowLeft className="h-4 w-4" /> Dashboard
        </Link>
        <h1 className="mt-3 font-display text-3xl font-bold">Account settings</h1>
        <p className="text-sm text-muted-foreground">
          Signed in as <span className="font-mono">{user?.email}</span>
        </p>

        <form onSubmit={save} className="soft-card mt-6 space-y-4 p-6">
          <h2 className="font-display text-lg font-semibold">Profile</h2>
          <Field label="Full name" value={fullName} onChange={setFullName} />
          <Field label="Username" value={username} onChange={setUsername} />
          <Field label="Phone" value={phone} onChange={setPhone} />
          <Button type="submit" className="rounded-full" disabled={busy}>
            Save profile
          </Button>
        </form>

        <form onSubmit={changePassword} className="soft-card mt-6 space-y-4 p-6">
          <div>
            <h2 className="font-display text-lg font-semibold">Change password</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Set or update your account password to keep your account secure.
            </p>
          </div>
          <Field label="New password" type="password" value={pwd} onChange={setPwd} />
          <Field label="Confirm new password" type="password" value={pwd2} onChange={setPwd2} />
          <Button type="submit" variant="outline" className="rounded-full" disabled={busy || !pwd}>
            {busy ? "Updating…" : "Update password"}
          </Button>
        </form>

        <NotificationPreferences />

        {/* Sign Out Card */}
        <div className="soft-card mt-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-6 border-destructive/20">
          <div>
            <h2 className="font-display text-lg font-semibold">Sign out</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Securely sign out of your Welcome Wagon account on this browser.
            </p>
          </div>
          <Button
            type="button"
            variant="outline"
            className="rounded-full text-destructive hover:bg-destructive/10 hover:text-destructive border-destructive/30 shrink-0"
            onClick={async () => {
              await signOut();
              toast.success("Signed out successfully");
              navigate({ to: "/", replace: true });
            }}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Sign out
          </Button>
        </div>
      </section>
    </PageShell>
  );
}

const PREF_KEYS = [
  { key: "orders", label: "Orders & delivery updates" },
  { key: "payments", label: "Payments & refunds" },
  { key: "wallet", label: "Wallet & withdrawals" },
  { key: "reviews", label: "Reviews" },
  { key: "announcements", label: "Announcements" },
] as const;

function NotificationPreferences() {
  const { user } = useAuth();
  const [prefs, setPrefs] = useState<Record<string, boolean>>({});
  const [push, setPush] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from("notification_preferences")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();
      if (data) {
        setPrefs({
          orders: data.orders,
          payments: data.payments,
          wallet: data.wallet,
          reviews: data.reviews,
          announcements: data.announcements,
        });
        setPush(data.push_enabled);
      } else {
        setPrefs({
          orders: true,
          payments: true,
          wallet: true,
          reviews: true,
          announcements: true,
        });
      }
    })();
  }, [user]);

  async function save() {
    if (!user) return;
    setBusy(true);
    let pushOn = push;
    if (push) pushOn = await requestPushPermission();
    const { error } = await supabase
      .from("notification_preferences")
      .upsert({ user_id: user.id, ...prefs, push_enabled: pushOn } as never, {
        onConflict: "user_id",
      });
    setBusy(false);
    if (error) return toast.error(error.message);
    setPush(pushOn);
    toast.success("Notification preferences saved");
  }

  if (!user) return null;

  return (
    <div className="soft-card mt-6 space-y-3 p-6">
      <h2 className="font-display text-lg font-semibold">Notifications</h2>
      <p className="text-xs text-muted-foreground">
        Security and account notices are always delivered.
      </p>
      {PREF_KEYS.map((p) => (
        <label
          key={p.key}
          className="flex items-center justify-between gap-3 rounded-xl border border-border/60 px-3 py-2 text-sm"
        >
          <span>{p.label}</span>
          <input
            type="checkbox"
            checked={prefs[p.key] ?? true}
            onChange={(e) => setPrefs((s) => ({ ...s, [p.key]: e.target.checked }))}
            className="h-4 w-4"
          />
        </label>
      ))}
      <label className="flex items-center justify-between gap-3 rounded-xl border border-border/60 px-3 py-2 text-sm">
        <span>Device (push) notifications</span>
        <input
          type="checkbox"
          checked={push}
          onChange={(e) => setPush(e.target.checked)}
          className="h-4 w-4"
        />
      </label>
      <Button className="rounded-full" onClick={save} disabled={busy}>
        Save preferences
      </Button>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  const [showPassword, setShowPassword] = useState(false);
  const isPassword = type === "password";
  const actualType = isPassword ? (showPassword ? "text" : "password") : type;

  return (
    <div className="block">
      <label className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">
        {label}
      </label>
      <div className="relative">
        <input
          type={actualType}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className={`h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary ${
            isPassword ? "pr-10" : ""
          }`}
        />
        {isPassword && (
          <button
            type="button"
            onClick={() => setShowPassword((v) => !v)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1 cursor-pointer transition-colors"
            aria-label={showPassword ? "Hide password" : "Show password"}
          >
            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        )}
      </div>
    </div>
  );
}
