import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";
import { useState } from "react";
import { toast } from "sonner";
import { statusBadge } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/admin/admin-applications")({
  component: AdminAppsAdmin,
});

function AdminAppsAdmin() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"pending" | "approved" | "declined">("pending");
  const { data: apps } = useQuery({
    queryKey: ["admin-admin-apps", filter],
    queryFn: async () => {
      const { data: rows } = await supabase
        .from("admin_applications")
        .select("*")
        .eq("status", filter)
        .order("created_at", { ascending: false });
      if (!rows || rows.length === 0) return [];
      const ids = Array.from(new Set(rows.map((r) => r.user_id)));
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, email, full_name")
        .in("id", ids);
      const byId = new Map((profs ?? []).map((p) => [p.id, p]));
      return rows.map((r) => ({ ...r, profile: byId.get(r.user_id) ?? null }));
    },
  });

  async function approve(userId: string, id: string) {
    const { error: rErr } = await supabase
      .from("user_roles")
      .upsert(
        { user_id: userId, role: "admin" },
        { onConflict: "user_id,role", ignoreDuplicates: true },
      );
    if (rErr) return toast.error(rErr.message);
    const { error } = await supabase
      .from("admin_applications")
      .update({ status: "approved", reviewed_by: user!.id, reviewed_at: new Date().toISOString() })
      .eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Admin approved");
    qc.invalidateQueries({ queryKey: ["admin-admin-apps"] });
  }
  async function decline(id: string) {
    const reason = prompt("Reason?") ?? "";
    if (!reason) return;
    const { error } = await supabase
      .from("admin_applications")
      .update({
        status: "declined",
        decline_reason: reason,
        reviewed_by: user!.id,
        reviewed_at: new Date().toISOString(),
      })
      .eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["admin-admin-apps"] });
  }

  return (
    <div>
      <div className="mb-4 flex gap-2">
        {(["pending", "approved", "declined"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full px-3 py-1 text-xs font-semibold capitalize ${filter === f ? "bg-primary text-primary-foreground" : "bg-secondary"}`}
          >
            {f}
          </button>
        ))}
      </div>
      {!apps || apps.length === 0 ? (
        <p className="soft-card p-8 text-center text-sm text-muted-foreground">
          No {filter} applications.
        </p>
      ) : (
        <ul className="space-y-3">
          {apps.map((a) => (
            <li key={a.id} className="soft-card p-5">
              <div className="flex flex-wrap items-start gap-4">
                <div className="min-w-0 flex-1">
                  <h3 className="font-semibold">
                    {a.profile?.full_name ?? a.profile?.email ?? "Unknown"}
                  </h3>
                  <p className="text-xs text-muted-foreground">{a.profile?.email}</p>
                  <p className="mt-2 text-sm">{a.reason}</p>
                </div>
                {a.status === "pending" ? (
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="rounded-full"
                      onClick={() => decline(a.id)}
                    >
                      Decline
                    </Button>
                    <Button
                      size="sm"
                      className="rounded-full"
                      onClick={() => approve(a.user_id, a.id)}
                    >
                      Approve
                    </Button>
                  </div>
                ) : (
                  <span
                    className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${statusBadge(a.status).tone}`}
                  >
                    {statusBadge(a.status).label}
                  </span>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
