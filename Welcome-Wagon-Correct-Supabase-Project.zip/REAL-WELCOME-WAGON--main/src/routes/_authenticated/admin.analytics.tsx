import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Users, Store, Package, ShoppingBag, Banknote, Hourglass } from "lucide-react";
import { ngn } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/admin/analytics")({
  component: Analytics,
});

async function count(
  table: "profiles" | "vendors" | "products" | "orders" | "vendor_applications",
  filters?: Record<string, string>,
) {
  let q = supabase.from(table).select("*", { count: "exact", head: true });
  if (filters) for (const [k, v] of Object.entries(filters)) q = q.eq(k, v);
  const { count, error } = await q;
  if (error) throw error;
  return count ?? 0;
}

function Analytics() {
  const { data, isLoading } = useQuery({
    queryKey: ["admin-analytics"],
    queryFn: async () => {
      const [
        users,
        vendors,
        pendingVendors,
        products,
        pendingProducts,
        orders,
        paidOrders,
        revenueRows,
      ] = await Promise.all([
        count("profiles"),
        count("vendors"),
        count("vendor_applications", { status: "pending" }),
        count("products", { status: "approved" }),
        count("products", { status: "pending_review" }),
        count("orders"),
        count("orders", { status: "paid" }),
        supabase
          .from("orders")
          .select("total_ngn, status")
          .in("status", ["paid", "processing", "shipped", "delivered"]),
      ]);
      const revenue = (revenueRows.data ?? []).reduce((s, r) => s + Number(r.total_ngn ?? 0), 0);
      // This RPC applies the Super Admin check on the database. Do not query raw order_items here.
      const { data: vendorSalesRows, error: vendorSalesError } = await supabase.rpc("get_vendor_sales_report");
      return {
        users,
        vendors,
        pendingVendors,
        products,
        pendingProducts,
        orders,
        paidOrders,
        revenue,
        vendorSales: vendorSalesError ? [] : (vendorSalesRows ?? []),
      };
    },
  });

  const cards = [
    { icon: Users, label: "Registered users", value: data?.users },
    { icon: Store, label: "Verified vendors", value: data?.vendors },
    { icon: Hourglass, label: "Pending vendor apps", value: data?.pendingVendors },
    { icon: Package, label: "Live products", value: data?.products },
    { icon: Hourglass, label: "Pending products", value: data?.pendingProducts },
    { icon: ShoppingBag, label: "Total orders", value: data?.orders },
    { icon: ShoppingBag, label: "Verified orders", value: data?.paidOrders },
    {
      icon: Banknote,
      label: "Gross revenue (verified)",
      value: data ? ngn(data.revenue) : undefined,
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-xl font-semibold">Marketplace overview</h2>
        <p className="text-sm text-muted-foreground">
          Live KPIs across users, vendors, products and orders.
        </p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="soft-card flex items-start gap-3 p-5">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-secondary text-primary">
              <c.icon className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground">{c.label}</p>
              <p className="mt-1 font-display text-2xl font-bold">
                {isLoading || c.value === undefined ? "—" : c.value}
              </p>
            </div>
          </div>
        ))}
      </div>
      <section className="soft-card overflow-hidden p-5">
        <div className="mb-4">
          <h3 className="font-display text-lg font-semibold">Vendor sales by product</h3>
          <p className="text-sm text-muted-foreground">Only paid, processing, shipped, and delivered orders are counted.</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead>
              <tr className="border-b text-xs uppercase tracking-wide text-muted-foreground">
                <th className="px-3 py-3">Vendor</th>
                <th className="px-3 py-3">Product</th>
                <th className="px-3 py-3 text-right">Units sold</th>
                <th className="px-3 py-3 text-right">Sales amount</th>
                <th className="px-3 py-3 text-right">Orders*</th>
              </tr>
            </thead>
            <tbody>
              {(data?.vendorSales ?? []).map((sale) => (
                <tr key={`${sale.vendor_id}-${sale.product_id}`} className="border-b last:border-0">
                  <td className="px-3 py-3 font-medium">{sale.vendor_name}</td>
                  <td className="px-3 py-3">{sale.product_title}</td>
                  <td className="px-3 py-3 text-right">{Number(sale.units_sold).toLocaleString("en-NG")}</td>
                  <td className="px-3 py-3 text-right">{ngn(Number(sale.sales_amount_ngn))}</td>
                  <td className="px-3 py-3 text-right">{Number(sale.orders_count).toLocaleString("en-NG")}</td>
                </tr>
              ))}
              {!isLoading && (data?.vendorSales?.length ?? 0) === 0 && (
                <tr><td colSpan={5} className="px-3 py-8 text-center text-muted-foreground">No qualifying vendor sales yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">*Orders are counted per product row, so the same order can appear under more than one product.</p>
      </section>
    </div>
  );
}
