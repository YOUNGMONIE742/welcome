import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Trash2, Megaphone } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/announcements")({
  component: AnnouncementsAdmin,
});

const AUDIENCES = ["all", "customers", "vendors", "admins"] as const;

function AnnouncementsAdmin() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [audience, setAudience] = useState<(typeof AUDIENCES)[number]>("all");
  const [targetEmails, setTargetEmails] = useState("");

  const { data: people } = useQuery({
    queryKey: ["announce-people"],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("id, email").order("email");
      return data ?? [];
    },
  });

  const { data: items, isLoading } = useQuery({
    queryKey: ["admin-announcements"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("announcements")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const create = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Not signed in");
      if (title.trim().length < 3) throw new Error("Title is too short");
      if (body.trim().length < 10) throw new Error("Body is too short (min 10 chars)");
      if (title.length > 120) throw new Error("Title must be under 120 chars");
      if (body.length > 4000) throw new Error("Body must be under 4000 chars");
      let targets: string[] | null = null;
      const wanted = targetEmails
        .split(/[,\s]+/)
        .map((s) => s.trim().toLowerCase())
        .filter(Boolean);
      if (wanted.length > 0) {
        const map = new Map((people ?? []).map((p) => [p.email.toLowerCase(), p.id]));
        const missing = wanted.filter((e) => !map.has(e));
        if (missing.length > 0) throw new Error(`No account found for: ${missing.join(", ")}`);
        targets = wanted.map((e) => map.get(e)!);
      }
      const { error } = await supabase.from("announcements").insert({
        title: title.trim(),
        body: body.trim(),
        audience,
        created_by: user.id,
        target_user_ids: targets,
      });
      if (error) throw error;
      if (targets) {
        await supabase.from("notifications").insert(
          targets.map((uid) => ({
            user_id: uid,
            title: title.trim(),
            body: body.trim(),
            link: "/notifications",
            kind: "announcement",
          })),
        );
      }
    },
    onSuccess: () => {
      toast.success("Announcement published");
      setTitle("");
      setBody("");
      setAudience("all");
      setTargetEmails("");
      qc.invalidateQueries({ queryKey: ["admin-announcements"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("announcements").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Deleted");
      qc.invalidateQueries({ queryKey: ["admin-announcements"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          create.mutate();
        }}
        className="soft-card space-y-4 p-6 h-fit"
      >
        <div className="flex items-center gap-2">
          <Megaphone className="h-5 w-5 text-primary" />
          <h2 className="font-display text-xl font-semibold">New announcement</h2>
        </div>
        <label className="block">
          <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">
            Audience
          </span>
          <select
            value={audience}
            onChange={(e) => setAudience(e.target.value as typeof audience)}
            className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary"
          >
            {AUDIENCES.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">
            Specific users (optional)
          </span>
          <input
            value={targetEmails}
            onChange={(e) => setTargetEmails(e.target.value)}
            placeholder="email1@example.com, email2@example.com"
            className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary"
          />
          <span className="mt-1 block text-[11px] text-muted-foreground">
            When filled, only these users receive it — the audience group is ignored.
          </span>
        </label>
        <label className="block">
          <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">
            Title
          </span>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            maxLength={120}
            required
            className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary"
          />
        </label>
        <label className="block">
          <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">
            Message
          </span>
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            maxLength={4000}
            rows={6}
            required
            className="w-full rounded-xl border border-border bg-card p-3 text-sm outline-none focus:border-primary"
          />
        </label>
        <Button type="submit" disabled={create.isPending} className="rounded-full">
          {create.isPending ? "Publishing…" : "Publish announcement"}
        </Button>
      </form>

      <div className="space-y-3">
        <h2 className="font-display text-lg font-semibold">Published</h2>
        {isLoading ? (
          <div className="soft-card p-5 text-sm text-muted-foreground">Loading…</div>
        ) : !items || items.length === 0 ? (
          <div className="soft-card p-5 text-sm text-muted-foreground">No announcements yet.</div>
        ) : (
          items.map((a) => (
            <article key={a.id} className="soft-card p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-[10px] font-semibold uppercase text-muted-foreground">
                    {a.audience} · {new Date(a.created_at).toLocaleString()}
                  </p>
                  <h3 className="mt-0.5 font-display text-base font-semibold">{a.title}</h3>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    if (confirm("Delete announcement?")) remove.mutate(a.id);
                  }}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
              <p className="mt-2 whitespace-pre-wrap text-sm text-muted-foreground">{a.body}</p>
            </article>
          ))
        )}
      </div>
    </div>
  );
}
