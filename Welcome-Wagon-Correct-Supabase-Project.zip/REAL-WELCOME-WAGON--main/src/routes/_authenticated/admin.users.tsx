import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { toast } from "sonner";
import type { AppRole } from "@/lib/auth-context";
import { SUPER_ADMIN_EMAILS, useAuth } from "@/lib/auth-context";
import { confirmSuperAdminPassword } from "@/lib/finance";

export const Route = createFileRoute("/_authenticated/admin/users")({
  component: UsersAdmin,
});

type Row = {
  id: string;
  email: string;
  full_name: string | null;
  phone: string | null;
  created_at: string | null;
  roles: AppRole[];
  vendor: { id: string; store_name: string; is_active: boolean; status: string } | null;
};

type RoleFilter = "all" | AppRole | "vendor_suspended";
type SortKey = "newest" | "email" | "name";

function UsersAdmin() {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [roleFilter, setRoleFilter] = useState<RoleFilter>("all");
  const [sortKey, setSortKey] = useState<SortKey>("newest");
  const { primaryRole, isSuperAdminEmail } = useAuth();
  const viewerIsSuper = primaryRole === "super_admin" && isSuperAdminEmail;
  const [lifecycle, setLifecycle] = useState<{
    vendorId: string;
    store: string;
    action: "suspended" | "active" | "terminated";
  } | null>(null);

  const { data: rows, isLoading } = useQuery({
    queryKey: ["admin-users"],
    queryFn: async (): Promise<Row[]> => {
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, email, full_name, phone, created_at")
        .order("created_at", { ascending: false });
      const ids = (profs ?? []).map((p) => p.id);
      if (ids.length === 0) return [];
      const [{ data: roles }, { data: vendors }] = await Promise.all([
        supabase.from("user_roles").select("user_id, role").in("user_id", ids),
        supabase
          .from("vendors")
          .select("id, user_id, store_name, is_active, status")
          .in("user_id", ids),
      ]);
      const rolesBy = new Map<string, AppRole[]>();
      for (const r of roles ?? []) {
        const arr = rolesBy.get(r.user_id) ?? [];
        arr.push(r.role as AppRole);
        rolesBy.set(r.user_id, arr);
      }
      const vendorBy = new Map((vendors ?? []).map((v) => [v.user_id, v]));
      return (profs ?? []).map((p) => ({
        id: p.id,
        email: p.email,
        full_name: p.full_name,
        phone: p.phone,
        created_at: p.created_at,
        roles: rolesBy.get(p.id) ?? [],
        vendor: vendorBy.get(p.id)
          ? {
              id: vendorBy.get(p.id)!.id,
              store_name: vendorBy.get(p.id)!.store_name,
              is_active: vendorBy.get(p.id)!.is_active,
              status:
                vendorBy.get(p.id)!.status ??
                (vendorBy.get(p.id)!.is_active ? "active" : "suspended"),
            }
          : null,
      }));
    },
  });

  async function grant(userId: string, role: AppRole) {
    const { error } = await supabase.rpc("set_user_role", {
      p_user_id: userId,
      p_role: role,
      p_grant: true,
    });
    if (error) return toast.error(error.message);
    toast.success(`Granted ${role}`);
    qc.invalidateQueries({ queryKey: ["admin-users"] });
  }

  async function revoke(userId: string, role: AppRole) {
    if (!confirm(`Revoke ${role} role?`)) return;
    const { error } = await supabase.rpc("set_user_role", {
      p_user_id: userId,
      p_role: role,
      p_grant: false,
    });
    if (error) return toast.error(error.message);
    toast.success(`Revoked ${role}`);
    qc.invalidateQueries({ queryKey: ["admin-users"] });
  }

  const filtered = (rows ?? [])
    .filter((r) => {
      if (roleFilter === "vendor_suspended") {
        if (!r.vendor || r.vendor.status === "active") return false;
      } else if (roleFilter !== "all" && !r.roles.includes(roleFilter)) {
        return false;
      }
      if (!q) return true;
      const s = q.toLowerCase();
      return (
        r.email.toLowerCase().includes(s) ||
        (r.full_name ?? "").toLowerCase().includes(s) ||
        (r.vendor?.store_name ?? "").toLowerCase().includes(s)
      );
    })
    .sort((a, b) => {
      if (sortKey === "email") return a.email.localeCompare(b.email);
      if (sortKey === "name") return (a.full_name ?? a.email).localeCompare(b.full_name ?? b.email);
      return (b.created_at ?? "").localeCompare(a.created_at ?? "");
    });

  const selectCls =
    "h-11 rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary";

  return (
    <div>
      <div className="flex flex-wrap gap-2">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search email, name or store"
          className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary sm:max-w-sm"
        />
        <select
          aria-label="Filter by role"
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value as RoleFilter)}
          className={selectCls}
        >
          <option value="all">All roles</option>
          <option value="customer">Customers</option>
          <option value="vendor">Vendors</option>
          <option value="admin">Admins</option>
          <option value="super_admin">Super admins</option>
          <option value="vendor_suspended">Suspended/terminated stores</option>
        </select>
        <select
          aria-label="Sort users"
          value={sortKey}
          onChange={(e) => setSortKey(e.target.value as SortKey)}
          className={selectCls}
        >
          <option value="newest">Newest first</option>
          <option value="email">Email A–Z</option>
          <option value="name">Name A–Z</option>
        </select>
        <span className="self-center text-xs text-muted-foreground">
          {filtered.length} user{filtered.length === 1 ? "" : "s"}
        </span>
      </div>
      {isLoading ? (
        <p className="mt-6 text-sm text-muted-foreground">Loading…</p>
      ) : filtered.length === 0 ? (
        <p className="soft-card mt-6 p-8 text-center text-sm text-muted-foreground">No users.</p>
      ) : (
        <ul className="mt-4 space-y-3">
          {filtered.map((r) => {
            const isSuper = SUPER_ADMIN_EMAILS.includes(r.email.toLowerCase());
            const hasAdmin = r.roles.includes("admin");
            const hasVendor = r.roles.includes("vendor");
            return (
              <li key={r.id} className="soft-card p-4">
                <div className="flex flex-wrap items-start gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold">
                      {r.full_name ?? "—"}{" "}
                      <span className="ml-1 text-xs text-muted-foreground">{r.email}</span>
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {r.phone ?? "no phone"} · roles: {r.roles.join(", ") || "none"}
                      {isSuper && " · SUPER"}
                    </p>
                    {r.vendor && (
                      <p className="mt-1 text-xs">
                        Store: <strong>{r.vendor.store_name}</strong> ·{" "}
                        <span
                          className={
                            r.vendor.status === "active" ? "text-success" : "text-destructive"
                          }
                        >
                          {r.vendor.status}
                        </span>
                      </p>
                    )}
                  </div>
                  {!isSuper && (
                    <div className="flex flex-wrap gap-2">
                      {hasAdmin ? (
                        <Button
                          size="sm"
                          variant="outline"
                          className="rounded-full"
                          onClick={() => revoke(r.id, "admin")}
                        >
                          Revoke admin
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          className="rounded-full"
                          onClick={() => grant(r.id, "admin")}
                        >
                          Make admin
                        </Button>
                      )}
                      {hasVendor && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="rounded-full"
                          onClick={() => revoke(r.id, "vendor")}
                        >
                          Revoke vendor
                        </Button>
                      )}
                      {r.vendor && viewerIsSuper && r.vendor.status !== "terminated" && (
                        <>
                          <Button
                            size="sm"
                            variant="outline"
                            className="rounded-full"
                            onClick={() =>
                              setLifecycle({
                                vendorId: r.vendor!.id,
                                store: r.vendor!.store_name,
                                action: r.vendor!.status === "active" ? "suspended" : "active",
                              })
                            }
                          >
                            {r.vendor.status === "active" ? "Suspend store" : "Reactivate"}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="rounded-full text-destructive"
                            onClick={() =>
                              setLifecycle({
                                vendorId: r.vendor!.id,
                                store: r.vendor!.store_name,
                                action: "terminated",
                              })
                            }
                          >
                            Terminate
                          </Button>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
      {lifecycle && (
        <VendorLifecycleDialog
          {...lifecycle}
          onClose={() => setLifecycle(null)}
          onDone={() => {
            setLifecycle(null);
            qc.invalidateQueries({ queryKey: ["admin-users"] });
          }}
        />
      )}
    </div>
  );
}

function VendorLifecycleDialog({
  vendorId,
  store,
  action,
  onClose,
  onDone,
}: {
  vendorId: string;
  store: string;
  action: "suspended" | "active" | "terminated";
  onClose: () => void;
  onDone: () => void;
}) {
  const [password, setPassword] = useState("");
  const [reason, setReason] = useState("");
  const [confirmWord, setConfirmWord] = useState("");
  const [busy, setBusy] = useState(false);

  const title =
    action === "active"
      ? "Reactivate store"
      : action === "suspended"
        ? "Suspend store"
        : "Terminate store permanently";
  const needsWord = action === "terminated";

  async function run() {
    if (!password) return toast.error("Enter your super admin password to confirm.");
    if (needsWord && confirmWord !== "TERMINATE")
      return toast.error("Type TERMINATE exactly to confirm.");
    setBusy(true);
    const ok = await confirmSuperAdminPassword(password);
    if (!ok) {
      setBusy(false);
      return toast.error("Password confirmation failed.");
    }
    const { error } = await supabase.rpc("set_vendor_status", {
      p_vendor: vendorId,
      p_status: action,
      p_reason: reason || undefined,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(
      action === "active"
        ? "Store reactivated — dashboard, products and wallet restored."
        : action === "suspended"
          ? "Store suspended — products hidden, data preserved."
          : "Store terminated and archived.",
    );
    onDone();
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div
        className="w-full max-w-md rounded-2xl bg-card p-6 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="font-display text-xl font-bold">{title}</h3>
        <p className="mt-1 text-sm text-muted-foreground">{store}</p>
        <p className="mt-3 text-xs text-muted-foreground">
          {action === "active"
            ? "Dashboard, vendor role, store, products, reviews, ratings, wallet, analytics, orders and withdrawal history are all restored."
            : action === "suspended"
              ? "The account reverts to a normal customer account. Store and products are hidden, new orders, product edits and withdrawals are blocked. Nothing is deleted."
              : "The account is permanently disabled and the store archived. Financial history and audit logs are preserved and cannot be undone."}
        </p>
        <label className="mt-4 block">
          <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">
            Reason (shown to the vendor)
          </span>
          <input
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm"
          />
        </label>
        <label className="mt-3 block">
          <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">
            Super admin password
          </span>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="h-11 w-full rounded-xl border border-border bg-card px-3 text-sm"
          />
        </label>
        {needsWord && (
          <label className="mt-3 block">
            <span className="mb-1 block text-xs font-semibold uppercase text-muted-foreground">
              Type TERMINATE to confirm
            </span>
            <input
              value={confirmWord}
              onChange={(e) => setConfirmWord(e.target.value)}
              className="h-11 w-full rounded-xl border border-border bg-card px-3 font-mono text-sm"
            />
          </label>
        )}
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="outline" className="rounded-full" onClick={onClose}>
            Cancel
          </Button>
          <Button className="rounded-full" disabled={busy} onClick={run}>
            Confirm
          </Button>
        </div>
      </div>
    </div>
  );
}
