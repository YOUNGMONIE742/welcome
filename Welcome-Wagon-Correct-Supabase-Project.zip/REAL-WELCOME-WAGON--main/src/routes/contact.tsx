import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Mail, MapPin, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Welcome Wagon Kids & More" },
      { name: "description", content: "Reach Welcome Wagon Kids & More — Nigeria's curated kids marketplace." },
      { property: "og:title", content: "Contact" },
      { property: "og:description", content: "Get in touch with our team." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const fd = new FormData(form);
    const name = String(fd.get("name") ?? "").trim();
    const email = String(fd.get("email") ?? "").trim();
    const message = String(fd.get("message") ?? "").trim();
    if (!name || !email || !message) return;
    setBusy(true);
    const { data: userData } = await supabase.auth.getUser();
    const { error } = await supabase.from("feedback").insert({
      name, email, message, source: "contact", user_id: userData.user?.id ?? null,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Thanks! We'll get back to you shortly.");
    form.reset();
  }
  return (
    <PageShell>
      <section className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 md:grid-cols-2">
        <div>
          <h1 className="font-display text-3xl font-bold md:text-4xl">We'd love to hear from you</h1>
          <p className="mt-2 text-sm text-muted-foreground">For partnerships, vendor inquiries or support.</p>
          <ul className="mt-8 space-y-3 text-sm">
            <li className="flex items-start gap-3"><Mail className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> welcomewagonkidsandmore1@gmail.com</li>
            <li className="flex items-start gap-3"><Phone className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> 0803 590 9837</li>
            <li className="flex items-start gap-3"><Phone className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> +44 7732 542998</li>
            <li className="flex items-start gap-3"><Phone className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> 0912 780 3484</li>
            <li className="flex items-start gap-3"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> Shop A2 Hadidi Plaza 60, Isa Kaita Road, Kaduna</li>
          </ul>
        </div>
        <form onSubmit={submit} className="soft-card space-y-3 p-6">
          <div>
            <label className="text-xs font-medium">Name</label>
            <input name="name" required maxLength={100} className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 outline-none focus:border-primary" />
          </div>
          <div>
            <label className="text-xs font-medium">Email</label>
            <input name="email" required type="email" maxLength={200} className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 outline-none focus:border-primary" />
          </div>
          <div>
            <label className="text-xs font-medium">Message</label>
            <textarea name="message" required maxLength={2000} rows={5} className="mt-1 w-full rounded-xl border border-border bg-card px-3 py-2 outline-none focus:border-primary" />
          </div>
          <Button type="submit" disabled={busy} className="w-full rounded-full">
            {busy ? "Sending…" : "Send message"}
          </Button>
        </form>
      </section>
    </PageShell>
  );
}