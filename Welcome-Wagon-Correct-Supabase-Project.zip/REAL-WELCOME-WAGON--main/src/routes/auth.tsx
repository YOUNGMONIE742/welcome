import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import brandLogo from "@/assets/brand-logo.png";
import { Eye, EyeOff, KeyRound, ShieldCheck, Mail, ArrowRight } from "lucide-react";

const searchSchema = z
  .object({
    tab: z.enum(["login", "register"]).optional(),
    redirect: z.string().optional(),
    token_hash: z.string().optional(),
    type: z.string().optional(),
    error: z.string().optional(),
    error_description: z.string().optional(),
  })
  .passthrough();

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign In or Register — Welcome Wagon Kids & More" },
      {
        name: "description",
        content: "Sign in or create your Welcome Wagon account to shop, sell, and manage orders.",
      },
    ],
  }),
  validateSearch: searchSchema,
  component: AuthPage,
});

const registerSchema = z.object({
  full_name: z.string().trim().min(2, "Enter your full name").max(100),
  username: z
    .string()
    .trim()
    .min(3, "At least 3 characters")
    .max(30)
    .regex(/^[a-zA-Z0-9_.]+$/, "Letters, numbers, _ or . only"),
  email: z.string().trim().email("Enter a valid email address").max(200),
  phone: z.string().trim().min(7, "Enter a valid phone number").max(20),
  password: z.string().min(8, "Password must be at least 8 characters").max(72),
});

export function AuthPage() {
  const search = Route.useSearch();
  const redirect = search.redirect;


  const [passwordMode, setPasswordMode] = useState<"login" | "register">(
    search.tab === "register" ? "register" : "login",
  );

  // Password visibility
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showRegisterPassword, setShowRegisterPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Password reset modal & recovery state
  const [showResetModal, setShowResetModal] = useState(false);
  const [resetModalTab, setResetModalTab] = useState<"request" | "verify">("request");
  const [resetEmail, setResetEmail] = useState("");
  const [resetOtp, setResetOtp] = useState("");

  // Direct recovery mode (when arriving with recovery token or after OTP verification)
  const [isRecovery, setIsRecovery] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [busy, setBusy] = useState(false);

  const { session, loading } = useAuth();
  const navigate = useNavigate();

  // Redirect if already logged in — but NOT if in password recovery mode
  useEffect(() => {
    if (!loading && session && !isRecovery) {
      navigate({
        to: redirect && redirect.startsWith("/") ? (redirect as never) : "/dashboard",
        replace: true,
      });
    }
  }, [loading, session, navigate, redirect, isRecovery]);

  // Handle email verification / password reset links & tokens
  useEffect(() => {
    if (typeof window === "undefined") return;

    const url = new URL(window.location.href);
    const hash = window.location.hash
      ? new URLSearchParams(window.location.hash.substring(1))
      : null;

    const errorParam = url.searchParams.get("error_description") || url.searchParams.get("error");
    const hashError = hash?.get("error_description") || hash?.get("error");
    const tokenHash = url.searchParams.get("token_hash") || hash?.get("token_hash");
    const otpType = (url.searchParams.get("type") || hash?.get("type")) as
      | "email"
      | "signup"
      | "invite"
      | "magiclink"
      | null;

    if (errorParam || hashError) {
      toast.error("Authentication notice", {
        description: errorParam || hashError || "An error occurred",
      });
      return;
    }

    if (tokenHash) {
      setBusy(true);
      supabase.auth
        .verifyOtp({ token_hash: tokenHash, type: (otpType ?? "email") as "email" })
        .then(({ data, error }) => {
          setBusy(false);
          if (error) {
            toast.error("Verification error", { description: error.message });
            return;
          }
          if (data?.session) {
            toast.success("Verified successfully!");
            navigate({
              to: redirect && redirect.startsWith("/") ? (redirect as never) : "/dashboard",
              replace: true,
            });
          }
        })
        .catch((err) => {
          setBusy(false);
          toast.error("Verification error", {
            description: err instanceof Error ? err.message : "Failed to verify token",
          });
        });
    }
  }, [navigate, redirect]);

  // Handle Login (Supabase Auth only)
  async function handleLogin(form: FormData) {
    const rawIdentifier = ((form.get("identifier") as string) || "").trim();
    const password = (form.get("password") as string) || "";

    if (!rawIdentifier) {
      toast.error("Please enter your email or username");
      return;
    }
    if (!password) {
      toast.error("Please enter your password");
      return;
    }

    setBusy(true);
    try {
      let targetEmail = rawIdentifier.toLowerCase();

      // If user provided a username without '@', look up their email in profiles
      if (!targetEmail.includes("@")) {
        try {
          const { data: profile } = await supabase
            .from("profiles")
            .select("email")
            .ilike("username", rawIdentifier)
            .maybeSingle();

          if (profile?.email) {
            targetEmail = profile.email.toLowerCase();
          }
        } catch {
          // If query fails, fall back to targetEmail
        }
      }

      const { error } = await supabase.auth.signInWithPassword({
        email: targetEmail,
        password,
      });

      if (error) {
        let msg = error.message;
        if (msg.toLowerCase().includes("invalid login credentials")) {
          msg = "Incorrect email/username or password. Please check your credentials and try again.";
        } else if (msg.toLowerCase().includes("email not confirmed")) {
          msg = "Email address not verified yet. Please check your inbox or reset your password.";
        }
        toast.error("Sign-in failed", { description: msg });
        return;
      }

      toast.success("Welcome back!");
      navigate({
        to: redirect && redirect.startsWith("/") ? (redirect as never) : "/dashboard",
        replace: true,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error("Sign-in failed", {
        description: msg || "An unexpected error occurred. Please try again.",
      });
    } finally {
      setBusy(false);
    }
  }

  // Handle Registration
  async function handleRegister(form: FormData) {
    const parsed = registerSchema.safeParse({
      full_name: form.get("full_name"),
      username: form.get("username"),
      email: form.get("email"),
      phone: form.get("phone"),
      password: form.get("password"),
    });

    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }

    setBusy(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email: parsed.data.email.toLowerCase(),
        password: parsed.data.password,
        options: {
          data: {
            full_name: parsed.data.full_name,
            username: parsed.data.username,
            phone: parsed.data.phone,
          },
        },
      });

      if (error) {
        toast.error("Could not create account", { description: error.message });
        return;
      }

      if (data.session) {
        toast.success("Account created successfully!");
        navigate({
          to: redirect && redirect.startsWith("/") ? (redirect as never) : "/dashboard",
          replace: true,
        });
      } else {
        toast.success("Account created! You can now sign in below.");
        setPasswordMode("login");
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error("Registration error", { description: msg });
    } finally {
      setBusy(false);
    }
  }

  // Send a Supabase Auth password-recovery code.
  async function handlePasswordReset(e: React.FormEvent) {
    e.preventDefault();
    const cleanEmail = resetEmail.trim().toLowerCase();
    if (!cleanEmail) {
      toast.error("Enter your account email address");
      return;
    }

    setBusy(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, {
        redirectTo: `${window.location.origin}/auth`,
      });
      if (error) throw error;
      toast.success("Password reset email sent", {
        description: "Check your email for the recovery code or link.",
      });
      setResetModalTab("verify");
    } catch (err) {
      toast.error("Could not send reset email", {
        description: err instanceof Error ? err.message : String(err),
      });
    } finally {
      setBusy(false);
    }
  }

  // Verify the Supabase Auth recovery code.
  async function handleVerifyResetOtp(e: React.FormEvent) {
    e.preventDefault();
    const cleanEmail = resetEmail.trim().toLowerCase();
    const cleanToken = resetOtp.trim();
    if (!cleanEmail || !cleanToken) {
      toast.error("Enter your email address and recovery code");
      return;
    }

    setBusy(true);
    try {
      const { error } = await supabase.auth.verifyOtp({
        email: cleanEmail,
        token: cleanToken,
        type: "recovery",
      });
      if (error) throw error;
      toast.success("Code verified. Choose a new password.");
      setShowResetModal(false);
      setIsRecovery(true);
    } catch (err) {
      toast.error("Verification failed", {
        description: err instanceof Error ? err.message : "Invalid or expired recovery code.",
      });
    } finally {
      setBusy(false);
    }
  }

  // Update the password for the verified Supabase recovery session.
  async function handleUpdatePassword(e: React.FormEvent) {
    e.preventDefault();
    if (newPassword.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }

    setBusy(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      toast.success("Password updated successfully. You can now sign in.");
      setIsRecovery(false);
      setNewPassword("");
      setConfirmPassword("");
      setPasswordMode("login");
    } catch (err) {
      toast.error("Failed to update password", {
        description: err instanceof Error ? err.message : String(err),
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <PageShell>
      <section className="mx-auto grid max-w-md gap-6 px-4 py-12 sm:px-6">
        {/* Brand Header */}
        <div className="text-center">
          <img src={brandLogo} alt="Welcome Wagon Kids & More" className="mx-auto h-12 w-auto" />
          <h1 className="mt-4 font-display text-2xl font-bold">Welcome to Welcome Wagon</h1>
          <p className="mt-1 text-xs text-muted-foreground">
            Nigeria's trusted marketplace for kids fashion, maternity &amp; essentials.
          </p>
        </div>

        <div className="soft-card p-6 space-y-5 shadow-sm">
          {/* If in recovery mode, display Set New Password form */}
          {isRecovery ? (
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <div className="rounded-xl bg-primary/10 border border-primary/20 p-4 text-xs text-foreground">
                <p className="font-semibold text-primary flex items-center gap-1.5 text-sm">
                  <KeyRound className="h-4 w-4" /> Set New Password
                </p>
                <p className="mt-1 text-muted-foreground">
                  Your identity has been verified. Enter your new password below to secure your account.
                </p>
              </div>

              <div>
                <label className="text-xs font-medium text-foreground">New Password</label>
                <div className="relative mt-1">
                  <input
                    type={showNewPassword ? "text" : "password"}
                    required
                    minLength={8}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="At least 8 characters"
                    className="h-11 w-full rounded-xl border border-border bg-card pl-3 pr-10 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1 cursor-pointer"
                    aria-label={showNewPassword ? "Hide password" : "Show password"}
                  >
                    {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-foreground">Confirm New Password</label>
                <div className="relative mt-1">
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    required
                    minLength={8}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-type new password"
                    className="h-11 w-full rounded-xl border border-border bg-card pl-3 pr-10 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1 cursor-pointer"
                    aria-label={showConfirmPassword ? "Hide password" : "Show password"}
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>

              <Button type="submit" disabled={busy} className="h-11 w-full rounded-full mt-2">
                {busy ? "Saving new password…" : "Save New Password"}
              </Button>

              <button
                type="button"
                onClick={() => setIsRecovery(false)}
                className="w-full text-center text-xs text-muted-foreground hover:text-foreground py-1 cursor-pointer"
              >
                Back to sign in
              </button>
            </form>
          ) : (
            <>
              {/* Mode toggle */}
              <div className="flex rounded-xl bg-muted/70 p-1 text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setPasswordMode("login")}
                  className={`flex-1 py-2 rounded-lg transition-all cursor-pointer ${
                    passwordMode === "login"
                      ? "bg-background text-foreground shadow-xs font-bold"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => setPasswordMode("register")}
                  className={`flex-1 py-2 rounded-lg transition-all cursor-pointer ${
                    passwordMode === "register"
                      ? "bg-background text-foreground shadow-xs font-bold"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Create Account
                </button>
              </div>

              {passwordMode === "login" ? (
                <form
                  className="space-y-4"
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleLogin(new FormData(e.currentTarget));
                  }}
                >
                  <div>
                    <label className="text-xs font-medium text-foreground">
                      Email address or Username
                    </label>
                    <input
                      name="identifier"
                      type="text"
                      required
                      autoComplete="username"
                      placeholder="you@example.com or username"
                      className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-medium text-foreground">Password</label>
                      <button
                        type="button"
                        onClick={() => {
                          setResetModalTab("request");
                          setShowResetModal(true);
                        }}
                        className="text-xs text-primary hover:underline cursor-pointer font-medium"
                      >
                        Forgot password?
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        name="password"
                        type={showLoginPassword ? "text" : "password"}
                        required
                        autoComplete="current-password"
                        placeholder="••••••••"
                        className="h-11 w-full rounded-xl border border-border bg-card pl-3 pr-10 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                      />
                      <button
                        type="button"
                        onClick={() => setShowLoginPassword((v) => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1 cursor-pointer transition-colors"
                        aria-label={showLoginPassword ? "Hide password" : "Show password"}
                      >
                        {showLoginPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={busy}
                    className="h-11 w-full rounded-full mt-2 text-sm font-semibold"
                  >
                    {busy ? "Signing in…" : "Sign In"}
                  </Button>
                </form>
              ) : (
                <form
                  className="space-y-3.5"
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleRegister(new FormData(e.currentTarget));
                  }}
                >
                  <Field label="Full name" name="full_name" required placeholder="e.g. Chinelo Obi" />
                  <Field
                    label="Username"
                    name="username"
                    required
                    placeholder="e.g. chinelo_store"
                  />
                  <Field
                    label="Email address"
                    name="email"
                    type="email"
                    required
                    placeholder="you@example.com"
                  />
                  <Field
                    label="Phone number"
                    name="phone"
                    type="tel"
                    required
                    placeholder="+234 801 234 5678"
                  />
                  <div>
                    <label className="text-xs font-medium text-foreground">
                      Password (min 8 characters)
                    </label>
                    <div className="relative mt-1">
                      <input
                        name="password"
                        type={showRegisterPassword ? "text" : "password"}
                        required
                        autoComplete="new-password"
                        placeholder="••••••••"
                        className="h-11 w-full rounded-xl border border-border bg-card pl-3 pr-10 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                      />
                      <button
                        type="button"
                        onClick={() => setShowRegisterPassword((v) => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1 cursor-pointer transition-colors"
                        aria-label={showRegisterPassword ? "Hide password" : "Show password"}
                      >
                        {showRegisterPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                  </div>
                  <Button
                    type="submit"
                    disabled={busy}
                    className="h-11 w-full rounded-full mt-2 text-sm font-semibold"
                  >
                    {busy ? "Creating account…" : "Create Account"}
                  </Button>
                </form>
              )}
            </>
          )}
        </div>

        {/* Forgot Password Modal */}
        {showResetModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-xs p-4">
            <div className="soft-card max-w-sm w-full p-6 space-y-4 shadow-xl border border-border">
              <div className="flex items-center gap-2 font-display text-lg font-semibold">
                <KeyRound className="h-5 w-5 text-primary" /> Reset Password
              </div>

              {/* Modal Tabs: Request Email vs Enter Code */}
              <div className="flex rounded-lg bg-muted/60 p-1 text-xs">
                <button
                  type="button"
                  onClick={() => setResetModalTab("request")}
                  className={`flex-1 py-1.5 rounded-md font-medium transition-all cursor-pointer ${
                    resetModalTab === "request"
                      ? "bg-background text-foreground shadow-xs font-bold"
                      : "text-muted-foreground"
                  }`}
                >
                  Request Reset Code
                </button>
                <button
                  type="button"
                  onClick={() => setResetModalTab("verify")}
                  className={`flex-1 py-1.5 rounded-md font-medium transition-all cursor-pointer ${
                    resetModalTab === "verify"
                      ? "bg-background text-foreground shadow-xs font-bold"
                      : "text-muted-foreground"
                  }`}
                >
                  Enter Verification Code
                </button>
              </div>

              {resetModalTab === "request" ? (
                <form onSubmit={handlePasswordReset} className="space-y-3">
                  <p className="text-xs text-muted-foreground">
                    Enter your registered account email. Supabase will send a password-recovery code or link to your email.
                  </p>
                  <div>
                    <label className="text-xs font-medium text-foreground">Email address</label>
                    <input
                      type="email"
                      required
                      value={resetEmail}
                      onChange={(e) => setResetEmail(e.target.value)}
                      placeholder="you@example.com"
                      className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div className="flex items-center justify-end gap-2 pt-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowResetModal(false)}
                      className="rounded-full"
                    >
                      Cancel
                    </Button>
                    <Button type="submit" disabled={busy} className="rounded-full">
                      {busy ? "Sending…" : "Send Reset Code"}
                    </Button>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleVerifyResetOtp} className="space-y-3">
                  <p className="text-xs text-muted-foreground">
                    Enter the verification code sent to your email along with your email address to set a new password.
                  </p>
                  <div>
                    <label className="text-xs font-medium text-foreground">Email address</label>
                    <input
                      type="email"
                      required
                      value={resetEmail}
                      onChange={(e) => setResetEmail(e.target.value)}
                      placeholder="you@example.com"
                      className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-foreground">Verification Code</label>
                    <input
                      type="text"
                      required
                      value={resetOtp}
                      onChange={(e) => setResetOtp(e.target.value)}
                      placeholder="e.g. 123456"
                      maxLength={12}
                      className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 font-mono text-center tracking-widest text-base outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div className="flex items-center justify-end gap-2 pt-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowResetModal(false)}
                      className="rounded-full"
                    >
                      Cancel
                    </Button>
                    <Button type="submit" disabled={busy} className="rounded-full">
                      {busy ? "Verifying…" : "Verify Code"}
                    </Button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}

        <p className="text-center text-xs text-muted-foreground">
          By continuing you agree to our{" "}
          <Link to="/support" className="underline hover:text-primary">
            Terms
          </Link>{" "}
          &amp;{" "}
          <Link to="/support" className="underline hover:text-primary">
            Privacy
          </Link>
          .
        </p>
      </section>
    </PageShell>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
  defaultValue,
  placeholder,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  defaultValue?: string;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="text-xs font-medium text-foreground">{label}</label>
      <input
        name={name}
        type={type}
        required={required}
        defaultValue={defaultValue}
        placeholder={placeholder}
        autoComplete={name}
        className="mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
      />
    </div>
  );
}
