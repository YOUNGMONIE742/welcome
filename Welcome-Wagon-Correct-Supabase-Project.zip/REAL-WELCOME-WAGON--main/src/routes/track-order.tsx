import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { Package, Truck, CheckCircle2, Clock } from "lucide-react";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/track-order")({
  head: () => ({
    meta: [
      { title: "Track Order — Welcome Wagon Kids & More" },
      { name: "description", content: "Track your Welcome Wagon Kids & More order by order number." },
      { property: "og:title", content: "Track Order" },
      { property: "og:description", content: "Check your delivery status." },
    ],
  }),
  component: TrackOrder,
});

const STEPS = [
  { key: "pending_payment", label: "Awaiting payment", Icon: Clock },
  { key: "payment_review", label: "Payment under review", Icon: Clock },
  { key: "paid", label: "Payment confirmed", Icon: CheckCircle2 },
  { key: "processing", label: "Processing", Icon: Package },
  { key: "shipped", label: "Shipped", Icon: Truck },
  { key: "delivered", label: "Delivered", Icon: CheckCircle2 },
];

function TrackOrder() {
  const [orderNumber, setOrderNumber] = useState("");
  const [busy, setBusy] = useState(false);
  const [order, setOrder] = useState<{ order_number: string; status: string; created_at: string; total_ngn: number } | null>(null);

  async function lookup(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setOrder(null);
    const { data, error } = await supabase
      .from("orders")
      .select("order_number, status, created_at, total_ngn")
      .eq("order_number", orderNumber.trim().toUpperCase())
      .maybeSingle();
    setBusy(false);
    if (error || !data) {
      toast.error("Order not found. Make sure you're signed in with the same email used at checkout.");
      return;
    }
    setOrder(data);
  }

  const currentIdx = order ? STEPS.findIndex((s) => s.key === order.status) : -1;

  return (
    <PageShell>
      <section className="mx-auto max-w-2xl px-4 py-16 sm:px-6">
        <h1 className="font-display text-3xl font-bold md:text-4xl">Track your order</h1>
        <p className="mt-2 text-sm text-muted-foreground">Enter your order number to see its current status.</p>
        <form onSubmit={lookup} className="soft-card mt-6 flex flex-col gap-3 p-4 sm:flex-row">
          <input
            required
            value={orderNumber}
            onChange={(e) => setOrderNumber(e.target.value)}
            placeholder="WW-XXXXXXXX"
            className="h-11 flex-1 rounded-xl border border-border bg-card px-3 outline-none focus:border-primary"
          />
          <Button type="submit" disabled={busy} className="rounded-full">{busy ? "Looking…" : "Track"}</Button>
        </form>

        {order && (
          <div className="soft-card mt-6 p-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-xs text-muted-foreground">Order</p>
                <p className="font-mono text-lg font-bold">{order.order_number}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Total</p>
                <p className="text-lg font-bold text-primary">₦{Number(order.total_ngn).toLocaleString()}</p>
              </div>
            </div>
            <ol className="mt-8 space-y-4">
              {STEPS.map((s, i) => {
                const done = currentIdx >= i;
                const active = currentIdx === i;
                return (
                  <li key={s.key} className="flex items-center gap-3">
                    <div className={`grid h-9 w-9 place-items-center rounded-full border ${done ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground"}`}>
                      <s.Icon className="h-4 w-4" />
                    </div>
                    <span className={`text-sm ${active ? "font-semibold text-primary" : done ? "text-foreground" : "text-muted-foreground"}`}>{s.label}</span>
                  </li>
                );
              })}
            </ol>
          </div>
        )}
      </section>
    </PageShell>
  );
}