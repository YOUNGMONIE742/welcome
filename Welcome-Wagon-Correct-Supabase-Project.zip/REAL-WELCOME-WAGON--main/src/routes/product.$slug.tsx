import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PageShell } from "@/components/page-shell";
import { StoredImage, useSignedUrl } from "@/components/stored-image";
import { Button } from "@/components/ui/button";
import { ngn } from "@/lib/format";
import { useCart } from "@/lib/cart-context";
import { parseVariantGroups, variantSummary } from "@/lib/variants";
import { ArrowLeft, ShoppingBag, BadgeCheck, Minus, Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/product/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `Product — Welcome Wagon Kids & More` },
      { name: "description", content: `Shop ${params.slug} on Welcome Wagon Kids & More.` },
    ],
  }),
  component: ProductPage,
  errorComponent: ({ error }) => <PageShell><div className="p-12 text-center text-sm">{error.message}</div></PageShell>,
  notFoundComponent: () => <PageShell><div className="p-12 text-center text-sm">Product not found.</div></PageShell>,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const router = useRouter();
  const cart = useCart();
  const [qty, setQty] = useState(1);
  const [selection, setSelection] = useState<Record<string, string>>({});
  const [activeImage, setActiveImage] = useState<string | null>(null);

  const { data: product, isLoading } = useQuery({
    queryKey: ["product", slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("id, title, slug, description, short_description, price_ngn, discount_price_ngn, stock, reserved_stock, low_stock_threshold, primary_image_url, video_url, images, product_code, brand, subcategory, shipping_fee_ngn, delivery_time, return_policy, warranty, variants, sold_by_type, vendor_id, categories(name), vendors(store_name, slug)")
        .eq("slug", slug)
        .eq("status", "approved")
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  if (isLoading) {
    return (
      <PageShell>
        <section className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
          <div className="h-4 w-24 animate-pulse rounded bg-secondary" />
          <div className="mt-4 grid gap-8 md:grid-cols-2">
            <div className="space-y-3">
              <div className="soft-card aspect-square animate-pulse" />
              <div className="flex gap-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="h-20 w-20 animate-pulse rounded-xl bg-secondary" />
                ))}
              </div>
            </div>
            <div className="space-y-3">
              <div className="h-5 w-32 animate-pulse rounded-full bg-secondary" />
              <div className="h-9 w-3/4 animate-pulse rounded bg-secondary" />
              <div className="h-7 w-28 animate-pulse rounded bg-secondary" />
              <div className="h-24 w-full animate-pulse rounded-xl bg-secondary" />
              <div className="h-11 w-48 animate-pulse rounded-full bg-secondary" />
            </div>
          </div>
        </section>
      </PageShell>
    );
  }
  if (!product) {
    return (
      <PageShell>
        <section className="mx-auto max-w-3xl px-4 py-16 text-center">
          <h1 className="font-display text-2xl font-bold">Product unavailable</h1>
          <p className="mt-2 text-sm text-muted-foreground">It may have been removed or is awaiting approval.</p>
          <Link to="/shop" className="mt-4 inline-block text-sm font-medium text-primary hover:underline">← Back to shop</Link>
        </section>
      </PageShell>
    );
  }

  const vendorName = product.sold_by_type === "welcome_wagon"
    ? "Welcome Wagon"
    : (product.vendors as { store_name: string } | null)?.store_name ?? "Vendor";

  const variantGroups = parseVariantGroups(product.variants);
  const groupNames = Object.keys(variantGroups);
  const chosen = variantSummary(selection);
  const gallery = Array.from(
    new Set(
      [product.primary_image_url, ...((product.images as string[] | null) ?? [])].filter(
        (x): x is string => !!x,
      ),
    ),
  );
  const mainImage = activeImage && gallery.includes(activeImage) ? activeImage : gallery[0] ?? null;

  function addToCart() {
    if (!product) return;
    const missing = groupNames.filter((g) => !selection[g]);
    if (missing.length) { toast.error(`Please choose ${missing.join(" and ")} first.`); return; }
    const available = Math.max(0, (product.stock ?? 0) - ((product as { reserved_stock?: number }).reserved_stock ?? 0));
    if (available <= 0) { toast.error("Out of stock"); return; }
    if (qty > available) { toast.error(`Only ${available} left`); return; }
    cart.add({
      product_id: product.id,
      title: product.title,
      slug: product.slug,
      price_ngn: Number(product.discount_price_ngn ?? product.price_ngn),
      quantity: qty,
      image: product.primary_image_url,
      vendor_id: product.vendor_id,
      vendor_name: vendorName,
      sold_by_type: product.sold_by_type as "vendor" | "welcome_wagon",
      stock: available,
      variant: chosen,
    });
    toast.success(`Added ${qty} × ${product.title} to cart`);
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        <button onClick={() => router.history.back()} className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary">
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <div className="mt-4 grid gap-8 md:grid-cols-2">
          <div className="space-y-3">
            <div className="soft-card aspect-square overflow-hidden">
              <StoredImage bucket="product-media" path={mainImage} alt={product.title} className="h-full w-full object-cover" />
            </div>
            {gallery.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {gallery.map((img) => (
                  <button
                    key={img}
                    onClick={() => setActiveImage(img)}
                    aria-label="View image"
                    className={`h-20 w-20 shrink-0 overflow-hidden rounded-xl border-2 transition ${mainImage === img ? "border-primary" : "border-transparent opacity-70 hover:opacity-100"}`}
                  >
                    <StoredImage bucket="product-media" path={img} alt="" className="h-full w-full object-cover" />
                  </button>
                ))}
              </div>
            )}
            {product.video_url && (
              <div className="soft-card overflow-hidden">
                <video controls className="w-full" src={/^https?:\/\//.test(product.video_url) ? product.video_url : undefined}>
                  {!/^https?:\/\//.test(product.video_url) && <ProductVideoSource path={product.video_url} />}
                </video>
              </div>
            )}
          </div>
          <div>
            <span className="chip"><BadgeCheck className="h-3 w-3" /> Sold by {vendorName}</span>
            <h1 className="mt-3 font-display text-3xl font-bold md:text-4xl">{product.title}</h1>
            <div className="mt-2 flex items-baseline gap-3">
              {product.discount_price_ngn ? (
                <>
                  <p className="text-2xl font-bold text-primary">{ngn(product.discount_price_ngn)}</p>
                  <p className="text-sm text-muted-foreground line-through">{ngn(product.price_ngn)}</p>
                </>
              ) : (
                <p className="text-2xl font-bold text-primary">{ngn(product.price_ngn)}</p>
              )}
            </div>
            {product.product_code && <p className="mt-1 text-xs text-muted-foreground">Code: <span className="font-mono">{product.product_code}</span></p>}
            <p className="mt-3 text-sm text-muted-foreground">{product.description ?? "No description provided."}</p>
            <dl className="mt-4 grid grid-cols-2 gap-2 text-xs">
              {product.brand && <div><dt className="text-muted-foreground">Brand</dt><dd className="font-semibold">{product.brand}</dd></div>}
              {(product.categories as { name: string } | null)?.name && <div><dt className="text-muted-foreground">Category</dt><dd className="font-semibold">{(product.categories as { name: string }).name}</dd></div>}
              {product.shipping_fee_ngn != null && <div><dt className="text-muted-foreground">Shipping</dt><dd className="font-semibold">{Number(product.shipping_fee_ngn) === 0 ? "Free" : ngn(product.shipping_fee_ngn)}</dd></div>}
              {product.delivery_time && <div><dt className="text-muted-foreground">Delivery</dt><dd className="font-semibold">{product.delivery_time}</dd></div>}
              {product.return_policy && <div className="col-span-2"><dt className="text-muted-foreground">Return policy</dt><dd>{product.return_policy}</dd></div>}
              {product.warranty && <div className="col-span-2"><dt className="text-muted-foreground">Warranty</dt><dd>{product.warranty}</dd></div>}
            </dl>
            {groupNames.length > 0 && (
              <div className="mt-4 space-y-3">
                {groupNames.map((group) => (
                  <div key={group}>
                    <p className="mb-1.5 text-xs font-semibold uppercase text-muted-foreground">{group}</p>
                    <div className="flex flex-wrap gap-2">
                      {variantGroups[group].map((opt) => {
                        const active = selection[group] === opt;
                        return (
                          <button
                            key={opt}
                            onClick={() => setSelection((s) => ({ ...s, [group]: opt }))}
                            className={`rounded-full border px-3.5 py-1.5 text-sm font-medium transition ${active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card hover:border-primary"}`}
                          >
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
            {(() => {
              const available = Math.max(0, (product.stock ?? 0) - ((product as { reserved_stock?: number }).reserved_stock ?? 0));
              return (
            <>
            <p className="mt-4 text-xs"><strong>{available}</strong> available{available > 0 && available <= product.low_stock_threshold && <span className="ml-2 rounded-full bg-destructive/10 px-2 py-0.5 text-[10px] font-semibold uppercase text-destructive">Low stock</span>}</p>

            {available > 0 ? (
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <div className="inline-flex items-center rounded-full border border-border">
                  <button className="grid h-10 w-10 place-items-center" onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Decrease"><Minus className="h-4 w-4" /></button>
                  <span className="w-10 text-center font-semibold">{qty}</span>
                  <button className="grid h-10 w-10 place-items-center" onClick={() => setQty((q) => Math.min(available, q + 1))} aria-label="Increase"><Plus className="h-4 w-4" /></button>
                </div>
                <Button className="rounded-full" onClick={addToCart}><ShoppingBag className="mr-1 h-4 w-4" /> Add to cart</Button>
              </div>
            ) : (
              <div className="mt-5 rounded-xl border border-destructive/30 bg-destructive/5 p-3 text-sm font-semibold text-destructive">Out of stock — unavailable until restocked</div>
            )}
            </>
              );
            })()}
          </div>
        </div>
      </section>
    </PageShell>
  );
}

function ProductVideoSource({ path }: { path: string }) {
  const { data } = useSignedUrl("product-media", path);
  if (!data) return null;
  return <source src={data} />;
}