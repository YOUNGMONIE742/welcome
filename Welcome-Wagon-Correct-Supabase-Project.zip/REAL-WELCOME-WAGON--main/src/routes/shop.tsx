import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageShell } from "@/components/page-shell";
import { Package, ShoppingBag, Search, X, Eye } from "lucide-react";
import { StoredImage } from "@/components/stored-image";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart-context";
import { ProductQuickView } from "@/components/product-quick-view";
import { toast } from "sonner";
import { z } from "zod";

const shopSearchSchema = z.object({
  q: z.string().optional(),
  category: z.string().optional(),
  sort: z.enum(["newest", "price_asc", "price_desc", "name_asc"]).optional(),
});

export const Route = createFileRoute("/shop")({
  head: () => ({
    meta: [
      { title: "Shop — Welcome Wagon Kids & More" },
      { name: "description", content: "Browse kids fashion, baby essentials, toys, gifts and nursery from verified Nigerian vendors." },
      { property: "og:title", content: "Shop — Welcome Wagon Kids & More" },
      { property: "og:description", content: "Browse approved products from Nigeria's curated kids marketplace." },
    ],
  }),
  validateSearch: shopSearchSchema,
  component: Shop,
});

function ngn(n: number) {
  return new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 0 }).format(n);
}

type ShopProduct = {
  id: string; title: string; slug: string; price_ngn: number;
  primary_image_url: string | null; stock: number; reserved_stock: number;
  low_stock_threshold: number; sold_by_type: string; vendor_id: string | null;
  vendors: { store_name: string } | null;
};

function Shop() {
  const { q, category, sort } = Route.useSearch();
  const navigate = useNavigate();
  const cart = useCart();
  const [term, setTerm] = useState(q ?? "");
  const [quickViewId, setQuickViewId] = useState<string | null>(null);
  useEffect(() => { setTerm(q ?? ""); }, [q]);

  const { data: categories } = useQuery({
    queryKey: ["shop-categories"],
    queryFn: async () => {
      const { data } = await supabase.from("categories").select("name, slug").order("display_order");
      return data ?? [];
    },
  });

  function apply(next: { q?: string; category?: string; sort?: string }) {
    navigate({
      to: "/shop",
      search: (prev: Record<string, string | undefined>) => {
        const merged = { ...prev, ...next } as Record<string, string | undefined>;
        for (const k of Object.keys(merged)) if (!merged[k]) delete merged[k];
        return merged as never;
      },
    });
  }

  const { data: products, isLoading } = useQuery({
    queryKey: ["shop-products", q ?? "", category ?? "", sort ?? "newest"],
    queryFn: async () => {
      const select = `id, title, slug, price_ngn, primary_image_url, stock, reserved_stock, low_stock_threshold, sold_by_type, vendor_id, vendors(store_name), categories${category ? "!inner" : ""}(slug)`;
      let query = supabase
        .from("products")
        .select(select)
        .eq("status", "approved")
        .limit(60);
      if (sort === "price_asc") query = query.order("price_ngn", { ascending: true });
      else if (sort === "price_desc") query = query.order("price_ngn", { ascending: false });
      else if (sort === "name_asc") query = query.order("title", { ascending: true });
      else query = query.order("created_at", { ascending: false });
      if (q) {
        const safe = q.replace(/[(),]/g, " ").trim();
        query = query.or(
          [
            `title.ilike.%${safe}%`,
            `description.ilike.%${safe}%`,
            `short_description.ilike.%${safe}%`,
            `brand.ilike.%${safe}%`,
            `subcategory.ilike.%${safe}%`,
            `sku.ilike.%${safe}%`,
            `product_code.ilike.%${safe}%`,
            `tags.cs.{${safe}}`,
          ].join(","),
        );
      }
      if (category) query = query.eq("categories.slug", category);
      const { data, error } = await query;
      if (error) throw error;
      return (data ?? []) as unknown as ShopProduct[];
    },
  });

  return (
    <PageShell>
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <h1 className="font-display text-3xl font-bold md:text-4xl">Shop</h1>
        <p className="text-sm text-muted-foreground">{q ? `Results for "${q}"` : category ? `Category: ${category}` : "All approved products"}</p>

        <form
          className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center"
          onSubmit={(e) => { e.preventDefault(); apply({ q: term.trim() }); }}
        >
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              value={term}
              onChange={(e) => setTerm(e.target.value)}
              placeholder="Search products, brands, categories…"
              aria-label="Search products"
              className="h-11 w-full rounded-full border border-border bg-card pl-9 pr-9 text-sm outline-none focus:border-primary"
            />
            {term && (
              <button type="button" aria-label="Clear search" onClick={() => { setTerm(""); apply({ q: undefined }); }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <select
            aria-label="Filter by category"
            value={category ?? ""}
            onChange={(e) => apply({ category: e.target.value || undefined })}
            className="h-11 rounded-full border border-border bg-card px-4 text-sm outline-none focus:border-primary"
          >
            <option value="">All categories</option>
            {(categories ?? []).map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
          </select>
          <select
            aria-label="Sort products"
            value={sort ?? "newest"}
            onChange={(e) => apply({ sort: e.target.value === "newest" ? undefined : e.target.value })}
            className="h-11 rounded-full border border-border bg-card px-4 text-sm outline-none focus:border-primary"
          >
            <option value="newest">Newest first</option>
            <option value="price_asc">Price: low to high</option>
            <option value="price_desc">Price: high to low</option>
            <option value="name_asc">Name: A–Z</option>
          </select>
          <Button type="submit" className="h-11 rounded-full px-6">Search</Button>
        </form>

        {isLoading ? (
          <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="soft-card aspect-[3/4] animate-pulse" />
            ))}
          </div>
        ) : !products || products.length === 0 ? (
          <div className="soft-card mt-10 p-12 text-center">
            <Package className="mx-auto h-10 w-10 text-muted-foreground" />
            <h2 className="mt-4 font-display text-xl font-semibold">{q || category ? "No matching products" : "No products yet"}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {q || category ? "Try a different search term or clear the filters." : "The marketplace is just opening. Approved products will appear here."}
            </p>
            <Link to="/verified-vendors" className="mt-4 inline-block text-sm font-medium text-primary hover:underline">
              Meet our vendors →
            </Link>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {products.map((p) => {
              const available = Math.max(0, (p.stock ?? 0) - (p.reserved_stock ?? 0));
              const lowStock = available > 0 && available <= p.low_stock_threshold;
              const vendorName = p.sold_by_type === "welcome_wagon"
                ? "Welcome Wagon"
                : (p.vendors as { store_name: string } | null)?.store_name ?? "Vendor";
              return (
                <div key={p.id} className="soft-card group overflow-hidden">
                  <Link to="/product/$slug" params={{ slug: p.slug }} className="block">
                    <div className="relative aspect-square bg-secondary overflow-hidden">
                      <StoredImage bucket="product-media" path={p.primary_image_url} alt={p.title} className="h-full w-full object-cover transition group-hover:scale-105" />
                      {lowStock && (
                        <span className="absolute left-2 top-2 rounded-full bg-destructive/90 px-2 py-0.5 text-[10px] font-semibold uppercase text-destructive-foreground">Low Stock</span>
                      )}
                      {available === 0 && (
                        <span className="absolute left-2 top-2 rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold uppercase">Out of stock</span>
                      )}
                      <button
                        aria-label={`Quick view ${p.title}`}
                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); setQuickViewId(p.id); }}
                        className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-card/90 text-foreground opacity-0 shadow transition group-hover:opacity-100 hover:bg-card"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="p-3">
                      <h3 className="line-clamp-2 text-sm font-semibold">{p.title}</h3>
                      <p className="mt-1 text-xs text-muted-foreground">Sold by {vendorName}</p>
                      <p className="mt-2 text-base font-bold text-primary">{ngn(Number(p.price_ngn))}</p>
                    </div>
                  </Link>
                  <div className="flex gap-2 px-3 pb-3">
                    <Button
                      size="sm"
                      variant="outline"
                      className="rounded-full sm:hidden"
                      onClick={() => setQuickViewId(p.id)}
                      aria-label={`Quick view ${p.title}`}
                    >
                      <Eye className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="sm"
                      className="flex-1 rounded-full"
                      disabled={available === 0}
                      onClick={() => {
                        cart.add({
                          product_id: p.id,
                          title: p.title,
                          slug: p.slug,
                          price_ngn: Number(p.price_ngn),
                          quantity: 1,
                          image: p.primary_image_url,
                          vendor_id: p.vendor_id,
                          vendor_name: vendorName,
                          sold_by_type: p.sold_by_type as "vendor" | "welcome_wagon",
                          stock: p.stock,
                        });
                        toast.success(`Added ${p.title} to cart`);
                      }}
                    >
                      <ShoppingBag className="mr-1 h-3.5 w-3.5" /> Add to cart
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
      {quickViewId && <ProductQuickView productId={quickViewId} onClose={() => setQuickViewId(null)} />}
    </PageShell>
  );
}