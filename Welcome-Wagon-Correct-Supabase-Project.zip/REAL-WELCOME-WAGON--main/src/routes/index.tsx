import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { ArrowRight, ShieldCheck, Sparkles, Truck, Star, Heart, Package, ShoppingBag } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import heroImg from "@/assets/hero-family.jpg";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { StoredImage } from "@/components/stored-image";
import { useCart } from "@/lib/cart-context";
import { toast } from "sonner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Welcome Wagon Kids & More — Luxury Kids Marketplace in Nigeria" },
      { name: "description", content: "Shop premium kids fashion, toys, nursery & gifts from verified Nigerian vendors. Curated, trusted, and delivered nationwide in NGN." },
      { property: "og:title", content: "Welcome Wagon Kids & More" },
      { property: "og:description", content: "Nigeria's curated multi-vendor marketplace for kids & family." },
    ],
  }),
  component: Index,
});

function Index() {
  const cart = useCart();
  const { data: categories } = useQuery({
    queryKey: ["home-categories"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("categories")
        .select("id, name, slug, image_url, display_order")
        .order("display_order")
        .limit(6);
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: vendors } = useQuery({
    queryKey: ["home-vendors"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("public_vendors" as never)
        .select("id, store_name, slug, logo_url, rating, total_sold")
        .order("rating", { ascending: false })
        .limit(8);
      if (error) throw error;
      return (data ?? []) as Array<{ id: string; store_name: string; slug: string; logo_url: string | null; rating: number; total_sold: number }>;
    },
  });

  const { data: featured } = useQuery({
    queryKey: ["home-featured-products"],
    queryFn: async () => {
      const base = "id, title, slug, price_ngn, discount_price_ngn, primary_image_url, stock, reserved_stock, low_stock_threshold, sold_by_type, vendor_id, is_featured, created_at, vendors(store_name)";
      const { data: feat } = await supabase.from("products").select(base).eq("status", "approved").eq("is_featured", true).order("created_at", { ascending: false }).limit(8);
      const list = feat ?? [];
      if (list.length < 8) {
        const need = 8 - list.length;
        const exclude = list.map((p) => p.id);
        let q = supabase.from("products").select(base).eq("status", "approved").order("created_at", { ascending: false }).limit(need);
        if (exclude.length) q = q.not("id", "in", `(${exclude.join(",")})`);
        const { data: fresh } = await q;
        return [...list, ...(fresh ?? [])];
      }
      return list;
    },
  });

  return (
    <PageShell>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <img src={heroImg} alt="" className="h-full w-full object-cover object-left" />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-background/10 md:via-background/40" />
        </div>
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-16 sm:px-6 md:grid-cols-2 md:py-28">
          <div className="max-w-xl">
            <span className="chip"><Sparkles className="h-3 w-3" /> Nigeria's curated kids marketplace</span>
            <h1 className="mt-5 font-display text-4xl font-bold leading-tight md:text-6xl">
              <span className="text-primary">WELCOME WAGON</span> Kids &amp; more
            </h1>
            <p className="mt-5 max-w-md text-base text-muted-foreground md:text-lg">
              Shop luxury baby, kids fashion, toys and gifts from verified Nigerian vendors — all in one trusted place.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/shop"><Button size="lg" className="rounded-full">Shop now <ArrowRight className="ml-1 h-4 w-4" /></Button></Link>
              <Link to="/verified-vendors"><Button size="lg" variant="outline" className="rounded-full">Meet our vendors</Button></Link>
            </div>
            <div className="mt-10 flex flex-wrap gap-6 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5"><ShieldCheck className="h-4 w-4 text-primary" /> Verified vendors</span>
              <span className="flex items-center gap-1.5"><Truck className="h-4 w-4 text-primary" /> Nationwide delivery</span>
              <span className="flex items-center gap-1.5"><Heart className="h-4 w-4 text-primary" /> Kid-friendly curation</span>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="flex items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-bold md:text-3xl">Shop by category</h2>
            <p className="text-sm text-muted-foreground">Hand-picked corners of the marketplace.</p>
          </div>
          <Link to="/categories" className="text-sm font-medium text-primary hover:underline">See all</Link>
        </div>
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-6">
          {(categories ?? []).map((c) => (
            <Link key={c.id} to="/shop" search={{ category: c.slug } as never} className="soft-card group flex flex-col items-center gap-2 p-4 transition hover:-translate-y-0.5">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-primary">
                <Package className="h-5 w-5" />
              </div>
              <span className="text-center text-sm font-medium">{c.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Verified Vendors */}
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="mb-10">
          <div className="flex items-end justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl font-bold md:text-3xl">Featured products</h2>
              <p className="text-sm text-muted-foreground">Fresh picks from our marketplace.</p>
            </div>
            <Link to="/shop" className="text-sm font-medium text-primary hover:underline">Shop all</Link>
          </div>
          {!featured || featured.length === 0 ? (
            <div className="soft-card mt-6 p-10 text-center text-sm text-muted-foreground">
              Approved products will appear here soon.
            </div>
          ) : (
            <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
              {featured.map((p) => {
                const vendorName = p.sold_by_type === "welcome_wagon"
                  ? "Welcome Wagon"
                  : (p.vendors as { store_name: string } | null)?.store_name ?? "Vendor";
                const available = Math.max(0, (p.stock ?? 0) - (p.reserved_stock ?? 0));
                const lowStock = available > 0 && available <= p.low_stock_threshold;
                const price = p.discount_price_ngn ?? p.price_ngn;
                return (
                  <div key={p.id} className="soft-card group overflow-hidden">
                    <Link to="/product/$slug" params={{ slug: p.slug }} className="block">
                      <div className="relative aspect-square bg-secondary overflow-hidden">
                        <StoredImage bucket="product-media" path={p.primary_image_url} alt={p.title} className="h-full w-full object-cover transition group-hover:scale-105" />
                        {lowStock && <span className="absolute left-2 top-2 rounded-full bg-destructive/90 px-2 py-0.5 text-[10px] font-semibold uppercase text-destructive-foreground">Low stock</span>}
                        {available === 0 && <span className="absolute left-2 top-2 rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold uppercase">Out of stock</span>}
                      </div>
                      <div className="p-3">
                        <h3 className="line-clamp-2 text-sm font-semibold">{p.title}</h3>
                        <p className="mt-1 text-xs text-muted-foreground">Sold by {vendorName}</p>
                        <p className="mt-2 text-base font-bold text-primary">₦{Number(price).toLocaleString("en-NG")}</p>
                      </div>
                    </Link>
                    <div className="px-3 pb-3">
                      <Button
                        size="sm"
                        className="w-full rounded-full"
                        disabled={available === 0}
                        onClick={() => {
                          cart.add({
                            product_id: p.id,
                            title: p.title,
                            slug: p.slug,
                            price_ngn: Number(price),
                            quantity: 1,
                            image: p.primary_image_url,
                            vendor_id: p.vendor_id,
                            vendor_name: vendorName,
                            sold_by_type: p.sold_by_type as "vendor" | "welcome_wagon",
                            stock: available,
                          });
                          toast.success(`Added ${p.title} to cart`);
                        }}
                      >
                        <ShoppingBag className="mr-1 h-3.5 w-3.5" /> Add to cart
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="flex items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-bold md:text-3xl">Verified vendors</h2>
            <p className="text-sm text-muted-foreground">Trusted small businesses across Nigeria.</p>
          </div>
          <Link to="/verified-vendors" className="text-sm font-medium text-primary hover:underline">View all</Link>
        </div>
        {(!vendors || vendors.length === 0) ? (
          <div className="soft-card mt-6 p-10 text-center text-sm text-muted-foreground">
            Approved vendors will appear here as they join. Want to sell with us?{" "}
            <Link to="/auth" className="font-semibold text-primary hover:underline">Create an account →</Link>
          </div>
        ) : (
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
            {vendors.map((v) => (
              <div key={v.id} className="soft-card flex items-center gap-3 p-4">
                <div className="grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-full bg-accent text-primary">
                  {v.logo_url ? (
                    <StoredImage bucket="store-logos" path={v.logo_url} alt={v.store_name} className="h-full w-full object-cover" />
                  ) : (
                    <Sparkles className="h-5 w-5" />
                  )}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{v.store_name}</p>
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Star className="h-3 w-3 fill-amber-400 text-amber-400" /> {Number(v.rating).toFixed(1)} · {v.total_sold} sold
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="brand-gradient relative overflow-hidden rounded-3xl p-10 text-primary-foreground md:p-14">
          <h3 className="font-display text-3xl font-bold md:text-4xl">Sell with Welcome Wagon</h3>
          <p className="mt-2 max-w-xl text-primary-foreground/80">
            Apply to become a verified vendor and reach families across Nigeria. Simple onboarding, no monthly fees.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/auth" search={{ tab: "register" } as never}>
              <Button size="lg" variant="secondary" className="rounded-full">Apply as vendor</Button>
            </Link>
            <Link to="/about">
              <Button size="lg" variant="outline" className="rounded-full border-white/30 bg-transparent text-primary-foreground hover:bg-white/10 hover:text-primary-foreground">
                Learn more
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
