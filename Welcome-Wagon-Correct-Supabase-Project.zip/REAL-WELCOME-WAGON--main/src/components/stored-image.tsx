import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Package } from "lucide-react";

export type StoredBucket = "store-logos" | "product-media" | "payment-proofs" | "site-assets";

function isHttp(s: string) {
  return /^https?:\/\//i.test(s);
}

async function sign(bucket: StoredBucket, path: string): Promise<string | null> {
  if (!path) return null;
  if (isHttp(path)) return path;
  const { data } = await supabase.storage.from(bucket).createSignedUrl(path, 60 * 60);
  return data?.signedUrl ?? null;
}

export function useSignedUrl(bucket: StoredBucket, path: string | null | undefined) {
  return useQuery({
    queryKey: ["signed", bucket, path ?? ""],
    enabled: !!path,
    staleTime: 50 * 60 * 1000,
    queryFn: () => sign(bucket, path as string),
  });
}

export function StoredImage({
  bucket,
  path,
  alt,
  className,
  fallbackClassName,
}: {
  bucket: StoredBucket;
  path: string | null | undefined;
  alt: string;
  className?: string;
  fallbackClassName?: string;
}) {
  const { data } = useSignedUrl(bucket, path);
  if (!path) {
    return (
      <div
        className={
          fallbackClassName ??
          "grid h-full w-full place-items-center bg-secondary text-muted-foreground"
        }
      >
        <Package className="h-8 w-8" />
      </div>
    );
  }
  if (!data) {
    return <div className={className ?? "h-full w-full animate-pulse bg-muted"} aria-label={alt} />;
  }
  return <img src={data} alt={alt} className={className} loading="lazy" />;
}
