import { useEffect, useRef, useState, useCallback } from "react";
import { useServerFn } from "@tanstack/react-start";
import { wwAssistantChat } from "@/lib/ai-assistant.functions";
import wwRobot from "@/assets/ww-robot.png";
import { MessageCircle, X, Minus, Send } from "lucide-react";

type Msg = { role: "user" | "assistant"; content: string };

const POS_KEY = "ww-assistant-pos-v1";
const TIPS = [
  "Need help choosing the right product? I can help you compare products and make better buying decisions.",
  "Looking for something specific? Ask me and I'll help you find it.",
  "Want to know who built this website? Ask me about our developer.",
  "Need help becoming a vendor? I can guide you.",
  "Have questions about your order? I'm here to help.",
];

function loadPos(): { x: number; y: number } | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(POS_KEY);
    if (!raw) return null;
    const p = JSON.parse(raw);
    if (typeof p?.x === "number" && typeof p?.y === "number") return p;
  } catch {
    /* noop */
  }
  return null;
}

export function WWAssistant() {
  const [mounted, setMounted] = useState(false);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [open, setOpen] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [tipIdx, setTipIdx] = useState(0);
  const [showTip, setShowTip] = useState(false);
  const dragRef = useRef<{
    startX: number;
    startY: number;
    origX: number;
    origY: number;
    moved: boolean;
    pointerId: number;
  } | null>(null);
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const draggingRef = useRef(false);
  const chat = useServerFn(wwAssistantChat);

  // Mount + initial pos (bottom-right by default)
  useEffect(() => {
    setMounted(true);
    const saved = loadPos();
    if (saved) {
      setPos(saved);
    } else {
      const w = window.innerWidth;
      const h = window.innerHeight;
      setPos({ x: w - 80, y: h - 100 });
    }
  }, []);

  // Rotating tips when closed/minimized
  useEffect(() => {
    if (open && !minimized) return;
    const cycle = () => {
      setTipIdx((i) => (i + 1) % TIPS.length);
      setShowTip(true);
      setTimeout(() => setShowTip(false), 4500);
    };
    const first = setTimeout(cycle, 3000);
    const iv = setInterval(cycle, 12000);
    return () => {
      clearTimeout(first);
      clearInterval(iv);
    };
  }, [open, minimized]);

  const savePos = (x: number, y: number) => {
    setPos({ x, y });
    try {
      localStorage.setItem(POS_KEY, JSON.stringify({ x, y }));
    } catch {
      /* noop */
    }
  };

  const onPointerDown = (e: React.PointerEvent) => {
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      origX: pos.x,
      origY: pos.y,
      moved: false,
      pointerId: e.pointerId,
    };
    draggingRef.current = false;
    // long-press to enable drag
    longPressTimer.current = setTimeout(() => {
      draggingRef.current = true;
      (e.target as Element).setPointerCapture?.(e.pointerId);
    }, 300);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!dragRef.current) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    if (Math.abs(dx) + Math.abs(dy) > 8) dragRef.current.moved = true;
    if (!draggingRef.current) return;
    const w = window.innerWidth,
      h = window.innerHeight;
    const nx = Math.max(4, Math.min(w - 60, dragRef.current.origX + dx));
    const ny = Math.max(4, Math.min(h - 60, dragRef.current.origY + dy));
    setPos({ x: nx, y: ny });
  };

  const onPointerUp = (e: React.PointerEvent) => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
    const wasDrag = draggingRef.current && dragRef.current?.moved;
    if (wasDrag) {
      savePos(pos.x, pos.y);
    } else {
      // treat as tap
      setOpen(true);
      setMinimized(false);
      setShowTip(false);
    }
    draggingRef.current = false;
    dragRef.current = null;
    (e.target as Element).releasePointerCapture?.(e.pointerId);
  };

  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || busy) return;
    const next: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(next);
    setInput("");
    setBusy(true);
    try {
      const res = await chat({ data: { messages: next } });
      setMessages([...next, { role: "assistant", content: res.reply }]);
    } catch (err) {
      setMessages([
        ...next,
        {
          role: "assistant",
          content: err instanceof Error ? err.message : "Something went wrong.",
        },
      ]);
    } finally {
      setBusy(false);
    }
  }, [input, busy, messages, chat]);

  if (!mounted) return null;

  const showBubble = open && !minimized;

  return (
    <div
      style={{ position: "fixed", left: pos.x, top: pos.y, zIndex: 9999, touchAction: "none" }}
      className="select-none"
    >
      {showBubble && (
        <div
          className="absolute bottom-16 right-0 flex w-[min(92vw,340px)] flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl"
          style={{ height: "min(70vh, 480px)" }}
        >
          <div className="flex items-center justify-between gap-2 border-b border-border bg-primary px-3 py-2 text-primary-foreground">
            <div className="flex items-center gap-2">
              <img
                src={wwRobot}
                alt="WW Assistant robot"
                className="h-8 w-8 rounded-full bg-white/10 p-0.5"
              />
              <div>
                <p className="text-sm font-semibold leading-tight">WW Assistant</p>
                <p className="text-[10px] opacity-80">Shopping · Support · Guide</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                aria-label="Minimize"
                onClick={() => setMinimized(true)}
                className="rounded p-1 hover:bg-black/10"
              >
                <Minus className="h-4 w-4" />
              </button>
              <button
                aria-label="Close"
                onClick={() => setOpen(false)}
                className="rounded p-1 hover:bg-black/10"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
          <div className="flex-1 space-y-2 overflow-y-auto bg-background p-3 text-sm">
            {messages.length === 0 && (
              <div className="rounded-xl bg-secondary p-3 text-xs text-muted-foreground">
                Hi! I'm WW Assistant. Ask me about products, orders, becoming a vendor, or who built
                this site.
              </div>
            )}
            {messages.map((m, i) => (
              <div
                key={i}
                className={m.role === "user" ? "flex justify-end" : "flex justify-start"}
              >
                <div
                  className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"}`}
                >
                  {m.content}
                </div>
              </div>
            ))}
            {busy && <div className="text-xs text-muted-foreground">WW is thinking…</div>}
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send();
            }}
            className="flex items-center gap-2 border-t border-border bg-card p-2"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask me anything…"
              className="h-10 flex-1 rounded-full border border-border bg-background px-3 text-sm outline-none focus:border-primary"
            />
            <button
              type="submit"
              disabled={busy || !input.trim()}
              aria-label="Send"
              className="grid h-10 w-10 place-items-center rounded-full bg-primary text-primary-foreground disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}

      {!showBubble && showTip && (
        <div className="absolute -top-2 right-16 w-64 -translate-y-full rounded-2xl bg-card p-3 text-xs text-foreground shadow-lg ring-1 ring-border">
          {TIPS[tipIdx]}
        </div>
      )}

      <button
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        aria-label="Open WW Assistant"
        className="relative grid h-16 w-16 place-items-center rounded-full bg-gradient-to-br from-primary via-primary to-primary/80 text-primary-foreground shadow-xl ring-2 ring-white/80 transition hover:scale-105"
      >
        {open && minimized ? (
          <MessageCircle className="h-6 w-6" />
        ) : (
          <img
            src={wwRobot}
            alt="WW Assistant robot"
            width={64}
            height={64}
            className="h-14 w-14 rounded-full object-contain drop-shadow"
          />
        )}
      </button>
    </div>
  );
}
