import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Palette, X, Check } from "lucide-react";

type ThemeKey = "brand" | "black" | "white" | "blue" | "pink";
const THEMES: { key: ThemeKey; label: string; swatch: string }[] = [
  { key: "brand", label: "Brand (default)", swatch: "linear-gradient(135deg,#6b3fd0,#e79bb6)" },
  { key: "black", label: "Black", swatch: "#111" },
  { key: "white", label: "White", swatch: "#f5f5f5" },
  { key: "blue", label: "Blue", swatch: "#3b6ee0" },
  { key: "pink", label: "Pink", swatch: "#ec6fa1" },
];
const STORAGE = "ww-theme";
const CLASSES: Record<ThemeKey, string> = {
  brand: "",
  black: "theme-black",
  white: "theme-white",
  blue: "theme-blue",
  pink: "theme-pink",
};

export function applyStoredTheme() {
  try {
    const t = (localStorage.getItem(STORAGE) as ThemeKey | null) ?? "brand";
    setTheme(t);
  } catch {
    /* ignore */
  }
}

function setTheme(t: ThemeKey) {
  const root = document.documentElement;
  Object.values(CLASSES).forEach((c) => c && root.classList.remove(c));
  const cls = CLASSES[t];
  if (cls) root.classList.add(cls);
  try {
    localStorage.setItem(STORAGE, t);
  } catch {
    /* ignore */
  }
}

export function ThemeToggle() {
  const [open, setOpen] = useState(false);
  const [current, setCurrent] = useState<ThemeKey>("brand");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    try {
      const t = (localStorage.getItem(STORAGE) as ThemeKey | null) ?? "brand";
      setCurrent(t);
    } catch {
      /* ignore */
    }
  }, []);

  function pick(t: ThemeKey) {
    setTheme(t);
    setCurrent(t);
    setOpen(false);
  }

  return (
    <div>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="grid h-10 w-10 place-items-center rounded-xl border border-border transition-colors hover:bg-secondary cursor-pointer"
        aria-label="Change theme color"
        title="Change theme color"
      >
        <Palette className="h-4 w-4" />
      </button>

      {open &&
        mounted &&
        createPortal(
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            {/* Backdrop overlay */}
            <div
              aria-hidden="true"
              className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity cursor-pointer"
              onClick={() => setOpen(false)}
            />

            {/* Theme Modal dialog: Centered in the middle on phone, tablet & laptop */}
            <div
              role="dialog"
              aria-modal="true"
              aria-labelledby="theme-modal-title"
              className="relative z-10 w-full max-w-sm rounded-2xl border border-border bg-card p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150"
            >
              <div className="flex items-center justify-between pb-3 border-b border-border/60">
                <div className="flex items-center gap-2">
                  <Palette className="h-5 w-5 text-primary" />
                  <h3
                    id="theme-modal-title"
                    className="font-display font-bold text-base text-foreground"
                  >
                    Choose Color Theme
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors cursor-pointer"
                  aria-label="Close theme modal"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="mt-3 space-y-1.5">
                {THEMES.map((t) => (
                  <button
                    key={t.key}
                    type="button"
                    onClick={() => pick(t.key)}
                    className={`flex w-full items-center gap-3.5 rounded-xl px-3.5 py-3 text-left text-sm transition-all cursor-pointer ${
                      current === t.key
                        ? "bg-primary/10 font-semibold text-primary border border-primary/20 shadow-xs"
                        : "text-foreground hover:bg-secondary border border-transparent"
                    }`}
                  >
                    <span
                      className="h-6 w-6 shrink-0 rounded-full border border-border/80 shadow-xs"
                      style={{ background: t.swatch }}
                    />
                    <span className="flex-1 font-medium">{t.label}</span>
                    {current === t.key && (
                      <span className="grid h-5 w-5 place-items-center rounded-full bg-primary text-primary-foreground text-xs">
                        <Check className="h-3 w-3 stroke-[3]" />
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>,
          document.body,
        )}
    </div>
  );
}
