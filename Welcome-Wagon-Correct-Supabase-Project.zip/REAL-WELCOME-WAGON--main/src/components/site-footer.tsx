import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Mail, MapPin, Phone, Twitter } from "lucide-react";
import brandLogo from "@/assets/brand-logo.png";

const IG = "https://instagram.com/welcomewagonkidsandmore";
const FB = "https://facebook.com/welcomewagonkidsandmore";
const TW = "https://twitter.com/welcomewagonkidsandmore";

export function SiteFooter() {
  return (
    <footer className="mt-20 border-t border-border bg-card/60">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4">
        <div>
          <img src={brandLogo} alt="Welcome Wagon Kids & More" className="h-12 w-auto" />
          <p className="mt-4 max-w-xs text-sm text-muted-foreground">
            Nigeria's luxury kids & family marketplace. Curated by us, sold by verified vendors.
          </p>
        </div>
        <div>
          <h4 className="font-display text-sm font-semibold uppercase tracking-wider text-foreground">
            Company
          </h4>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li>
              <Link to="/about" className="hover:text-primary">
                About Us
              </Link>
            </li>
            <li>
              <Link to="/verified-vendors" className="hover:text-primary">
                Verified Vendors
              </Link>
            </li>
            <li>
              <Link to="/categories" className="hover:text-primary">
                Categories
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-sm font-semibold uppercase tracking-wider text-foreground">
            Support
          </h4>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li>
              <Link to="/support" className="hover:text-primary">
                Help Center
              </Link>
            </li>
            <li>
              <Link to="/track-order" className="hover:text-primary">
                Track Order
              </Link>
            </li>
            <li>
              <Link to="/contact" className="hover:text-primary">
                Contact
              </Link>
            </li>
            <li>
              <Link to="/auth" className="hover:text-primary">
                Login / Register
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="font-display text-sm font-semibold uppercase tracking-wider text-foreground">
            Contact
          </h4>
          <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
            <li className="flex items-start gap-2">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> Shop A2 Hadidi Plaza 60,
              Isa Kaita Road, Kaduna
            </li>
            <li className="flex items-start gap-2">
              <Mail className="mt-0.5 h-4 w-4 shrink-0 text-primary" />{" "}
              welcomewagonkidsandmore1@gmail.com
            </li>
            <li className="flex items-start gap-2">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> 0803 590 9837
            </li>
            <li className="flex items-start gap-2">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> +44 7732 542998
            </li>
            <li className="flex items-start gap-2">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> 0912 780 3484
            </li>
          </ul>
          <div className="mt-4 flex gap-2">
            <a
              className="grid h-9 w-9 place-items-center rounded-full border border-border hover:text-primary"
              href={IG}
              target="_blank"
              rel="noreferrer"
              aria-label="Instagram @welcomewagonkidsandmore"
            >
              <Instagram className="h-4 w-4" />
            </a>
            <a
              className="grid h-9 w-9 place-items-center rounded-full border border-border hover:text-primary"
              href={FB}
              target="_blank"
              rel="noreferrer"
              aria-label="Facebook welcomewagonkidsandmore"
            >
              <Facebook className="h-4 w-4" />
            </a>
            <a
              className="grid h-9 w-9 place-items-center rounded-full border border-border hover:text-primary"
              href={TW}
              target="_blank"
              rel="noreferrer"
              aria-label="Twitter welcomewagonkidsandmore"
            >
              <Twitter className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-5 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p>© {new Date().getFullYear()} Welcome Wagon Kids & More. All rights reserved.</p>
          <div className="flex gap-4">
            <Link to="/support" className="hover:text-primary">
              Terms
            </Link>
            <Link to="/support" className="hover:text-primary">
              Privacy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
