import { Link, useNavigate } from "@tanstack/react-router";
import { Menu, Search, ShoppingBag, User as UserIcon, X } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useCart } from "@/lib/cart-context";
import { Button } from "@/components/ui/button";
import brandLogo from "@/assets/brand-logo.png";
import { cn } from "@/lib/utils";
import { ThemeToggle } from "@/components/theme-toggle";
import { NotificationBell } from "@/components/notification-bell";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/shop", label: "Shop" },
  { to: "/categories", label: "Categories" },
  { to: "/verified-vendors", label: "Verified Vendors" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  const { user, loading, signOut } = useAuth();
  const { count } = useCart();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const navigate = useNavigate();

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    navigate({ to: "/shop", search: { q: q || undefined } as never });
  }

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
        <button
          className="grid h-10 w-10 place-items-center rounded-xl border border-border md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
        <Link to="/" className="flex items-center gap-2">
          <img src={brandLogo} alt="Welcome Wagon Kids & More" className="h-9 w-auto md:h-11" />
          <span className="sr-only">Welcome Wagon Kids & More</span>
        </Link>

        <form onSubmit={submitSearch} className="ml-2 hidden flex-1 md:flex">
          <div className="relative w-full max-w-xl">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search products, brands, vendors…"
              className="h-11 w-full rounded-full border border-border bg-card pl-10 pr-4 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
            />
          </div>
        </form>

        <nav className="ml-auto hidden items-center gap-1 lg:flex">
          {NAV.slice(1, 4).map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="rounded-full px-3 py-2 text-sm font-medium text-foreground/70 transition hover:bg-secondary hover:text-foreground"
              activeProps={{ className: "text-primary bg-primary/10" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2 lg:ml-2">
          <ThemeToggle />
          {user && <NotificationBell />}
          <Link
            to="/cart"
            className="relative grid h-10 w-10 place-items-center rounded-xl border border-border"
            aria-label="Cart"
          >
            <ShoppingBag className="h-4 w-4" />
            {count > 0 && (
              <span className="absolute -right-1 -top-1 grid h-5 min-w-[20px] place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                {count}
              </span>
            )}
          </Link>
          {loading ? null : user ? (
            <Link to="/dashboard">
              <Button size="sm" className="rounded-full">
                <UserIcon className="mr-1 h-4 w-4" /> Account
              </Button>
            </Link>
          ) : (
            <>
              <Link
                to="/auth"
                className="hidden text-sm font-medium text-foreground/80 hover:text-primary sm:inline"
              >
                Login
              </Link>
              <Link to="/auth" search={{ tab: "register" } as never}>
                <Button size="sm" className="rounded-full">
                  Register
                </Button>
              </Link>
            </>
          )}
        </div>
      </div>

      {open && (
        <div className="border-t border-border bg-background md:hidden">
          <form onSubmit={submitSearch} className="p-4">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search"
                className="h-11 w-full rounded-full border border-border bg-card pl-10 pr-4 text-sm outline-none"
              />
            </div>
          </form>
          <nav className="grid gap-1 px-3 pb-4">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setOpen(false)}
                className={cn("rounded-xl px-4 py-3 text-sm font-medium text-foreground/80")}
                activeProps={{ className: "bg-primary/10 text-primary" }}
              >
                {n.label}
              </Link>
            ))}
            <Link
              to="/support"
              onClick={() => setOpen(false)}
              className="rounded-xl px-4 py-3 text-sm font-medium"
            >
              Support
            </Link>
            <Link
              to="/track-order"
              onClick={() => setOpen(false)}
              className="rounded-xl px-4 py-3 text-sm font-medium text-foreground/80"
            >
              Track Order
            </Link>

            {user ? (
              <div className="mt-2 border-t border-border pt-2 grid gap-1">
                <Link
                  to="/dashboard"
                  onClick={() => setOpen(false)}
                  className="rounded-xl px-4 py-3 text-sm font-medium text-foreground/80"
                >
                  Dashboard
                </Link>
                <Link
                  to="/settings"
                  onClick={() => setOpen(false)}
                  className="rounded-xl px-4 py-3 text-sm font-medium text-foreground/80"
                >
                  Account Settings
                </Link>
                <button
                  type="button"
                  onClick={async () => {
                    setOpen(false);
                    await signOut();
                    navigate({ to: "/" });
                  }}
                  className="rounded-xl px-4 py-3 text-left text-sm font-medium text-destructive hover:bg-destructive/10 cursor-pointer"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <div className="mt-2 border-t border-border pt-2 grid grid-cols-2 gap-2">
                <Link
                  to="/auth"
                  onClick={() => setOpen(false)}
                  className="rounded-xl border border-border px-4 py-2.5 text-center text-sm font-medium"
                >
                  Login
                </Link>
                <Link
                  to="/auth"
                  search={{ tab: "register" } as never}
                  onClick={() => setOpen(false)}
                  className="rounded-xl bg-primary px-4 py-2.5 text-center text-sm font-medium text-primary-foreground"
                >
                  Register
                </Link>
              </div>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
